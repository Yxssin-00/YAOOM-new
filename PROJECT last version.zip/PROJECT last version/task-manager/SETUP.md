# 🚀 TaskMate Setup Guide

## 📁 Project Overview

TaskMate is now organized as a unified project with three main components:

```
task-manager/
├── frontend/    # HTML5, CSS3, Bootstrap 5, jQuery application
├── backend/     # Node.js + Express.js REST API
├── database/    # PostgreSQL setup and schemas
└── package.json # Root project configuration
```

## ⚡ Quick Setup Options

### Option 1: Frontend Only (Instant Start)
Perfect for development and testing with local storage:

```bash
cd task-manager/frontend
# Open index.html in your browser
start index.html  # Windows
open index.html   # macOS
```

### Option 2: Full Stack Setup (Production Ready)

#### Prerequisites
- Node.js 14+ 
- npm 6+
- PostgreSQL 12+ (for database)

#### 1. Install Dependencies
```bash
cd task-manager
npm run setup
```

#### 2. Database Setup
```bash
cd database
# Follow database/README.md for detailed setup
```

#### 3. Backend Configuration
```bash
cd backend
cp .env.example .env
# Edit .env with your database credentials
```

#### 4. Start Development
```bash
# Terminal 1: Start backend
cd backend
npm run dev

# Terminal 2: Open frontend
cd frontend
start index.html
```

## 🔧 Available Scripts

From the root `task-manager/` directory:

```bash
npm run setup           # Install all dependencies
npm run install-backend # Install backend dependencies only
npm run install-database # Install database dependencies only
npm start              # Start backend in production mode
npm run dev            # Start backend in development mode
```

## 🌐 Access Points

- **Frontend Application**: `frontend/index.html`
- **Profile Page**: `frontend/profile.html`
- **API Server**: `http://localhost:5000` (when backend is running)
- **API Documentation**: `http://localhost:5000/api` (when backend is running)

## 📂 Component Details

### Frontend (`frontend/`)
- **Technology**: HTML5, CSS3, Bootstrap 5, jQuery
- **Features**: Dark mode, responsive design, local storage
- **Entry Point**: `index.html`
- **No build process required** - runs directly in browser

### Backend (`backend/`)
- **Technology**: Node.js, Express.js, JWT authentication
- **Database**: PostgreSQL with pg driver
- **Port**: 5000 (configurable via PORT env var)
- **API Routes**: `/api/auth`, `/api/user`, `/api/task`

### Database (`database/`)
- **Technology**: PostgreSQL
- **Schema**: SQL scripts in `sql/` directory
- **ORM Option**: Prisma schema available in `prisma/`
- **Setup Instructions**: See `database/README.md`

## 🔄 Development Workflow

### Frontend Development
1. Navigate to `frontend/` directory
2. Edit HTML, CSS, or JS files
3. Refresh browser to see changes
4. No build step required

### Backend Development
1. Start backend with `npm run dev` (auto-restarts on changes)
2. Test API endpoints with Postman or curl
3. Database changes require migration scripts

### Full Stack Development
1. Start backend server
2. Open frontend in browser
3. Frontend communicates with backend via API calls
4. Real-time data persistence

## 🚀 Deployment Options

### Frontend Only
- Deploy `frontend/` folder to any static hosting
- GitHub Pages, Netlify, Vercel, etc.
- No server requirements

### Full Stack
- Deploy backend to Heroku, Railway, or DigitalOcean
- Deploy frontend separately or serve from backend
- Configure PostgreSQL database
- Set environment variables

## 📚 Additional Resources

- **Frontend Documentation**: `frontend/README.md` (if exists)
- **Backend API Documentation**: `backend/README.md` (if exists)  
- **Database Setup**: `database/README.md`
- **Main Documentation**: `README.md`

## 🆘 Troubleshooting

### Common Issues

1. **Backend won't start**
   - Check if Node.js is installed: `node --version`
   - Install dependencies: `npm install`
   - Check database connection in `.env`

2. **Frontend API calls fail**
   - Ensure backend is running on port 5000
   - Check CORS configuration
   - Verify API endpoints

3. **Database connection issues**
   - Ensure PostgreSQL is running
   - Check database credentials in `.env`
   - Run database migrations

### Getting Help
- Check component-specific README files
- Review error logs in terminal
- Ensure all prerequisites are installed

---

**🎉 You're all set! Start building amazing task management experiences with TaskMate!** 