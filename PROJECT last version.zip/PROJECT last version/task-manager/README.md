# 📋 TaskMate - Modern Task Management System

![TaskMate Banner](https://img.shields.io/badge/TaskMate-Task%20Management-blue?style=for-the-badge&logo=checkmark)

A comprehensive task management application with a modern frontend, robust backend API, and PostgreSQL database. TaskMate offers a complete solution for personal and team task management with advanced features like real-time notifications, calendar views, and admin controls.

## 🏗️ **Project Structure**

```
task-manager/
├── frontend/           # HTML5, CSS3, Bootstrap 5, jQuery frontend
│   ├── index.html     # Main application page
│   ├── profile.html   # User profile page
│   ├── css/           # Stylesheets with dark mode support
│   ├── js/            # JavaScript modules and components
│   └── favicon.svg    # Application icon
├── backend/           # Node.js + Express.js API server
│   ├── app.js         # Main application entry point
│   ├── controllers/   # Request handlers
│   ├── routes/        # API route definitions
│   ├── models/        # Database models
│   ├── middlewares/   # Custom middleware functions
│   ├── config/        # Database and app configuration
│   └── utils/         # Utility functions
├── database/          # PostgreSQL database setup
│   ├── sql/           # SQL schema files
│   ├── prisma/        # Prisma ORM schema (optional)
│   └── README.md      # Database setup instructions
├── package.json       # Root project configuration
├── README.md          # Project documentation
└── .gitignore         # Git ignore rules
```

## ✨ Features

### 🔐 **Authentication System**
- **User Registration & Login** - Secure user management
- **Session Persistence** - Stay logged in across browser sessions
- **Admin Panel Access** - Role-based access control
- **Password Reset** - Forgot password functionality

### 📋 **Task Management**
- **CRUD Operations** - Create, read, update, delete tasks
- **Task Status Tracking** - Pending, In Progress, Completed
- **Priority Levels** - High, Medium, Low with visual indicators
- **Due Date Management** - Set and track deadlines
- **Task Tags** - Organize with custom tags
- **Task Descriptions** - Detailed task information

### 🔍 **Advanced Filtering & Search**
- **Multi-criteria Filtering** - Status, priority, due date, tags
- **Real-time Search** - Instant task search
- **Quick Filters** - One-click filtering options
- **Sort Options** - By date, priority, title, status

### 💬 **Collaboration Features**
- **Task Sharing** - Share tasks with team members
- **Comments System** - Add comments and mentions
- **User Mentions** - @mention functionality
- **Shared Task Views** - See tasks shared with you

### 🔔 **Smart Notifications**
- **Due Date Alerts** - Upcoming deadline reminders
- **Overdue Notifications** - Past due task alerts
- **Comment Notifications** - New comment alerts
- **Dismissible Alerts** - Mark notifications as read

### 📅 **Calendar Integration**
- **Calendar View** - Visual task scheduling
- **Monthly Navigation** - Browse different months
- **Task Display** - See tasks on their due dates
- **Priority Indicators** - Color-coded task priorities

### 👤 **Profile Management**
- **User Profiles** - Manage personal information
- **Avatar Support** - Profile picture placeholders
- **Settings Management** - Customize preferences
- **Account Security** - Change passwords securely

### 🛡️ **Admin Panel**
- **User Management** - Admin user controls
- **System Statistics** - Dashboard metrics
- **Role Management** - Assign admin privileges
- **Data Overview** - System-wide task insights

### 🌙 **Modern UI/UX**
- **Dark Mode Support** - Toggle between light and dark themes
- **Responsive Design** - Works on all devices
- **Bootstrap 5** - Modern, clean interface
- **Font Awesome Icons** - Beautiful iconography
- **Mobile Optimized** - Touch-friendly design

### 💾 **Offline Capability**
- **LocalStorage Integration** - Works offline
- **Data Persistence** - Automatic data saving
- **Mock Data Generation** - Demo content for testing
- **Graceful Degradation** - Handles API downtime

## 🚀 Live Demo

Experience TaskMate in action: [https://omar-agag.github.io/TaskMate](https://omar-agag.github.io/TaskMate)

## 🛠️ Technology Stack

| Technology | Version | Purpose |
|------------|---------|---------|
| **HTML5** | Latest | Semantic markup and structure |
| **CSS3** | Latest | Custom styling and animations |
| **Bootstrap** | 5.3.0 | Responsive UI framework |
| **jQuery** | 3.7.1 | DOM manipulation and AJAX |
| **Font Awesome** | 6.4.0 | Icons and visual elements |

### Why This Stack?
- ✅ **No Build Process** - Simple deployment
- ✅ **Universal Compatibility** - Works everywhere
- ✅ **Lightweight** - Fast loading times
- ✅ **Easy Maintenance** - Simple codebase
- ✅ **SEO Friendly** - Server-side rendering ready

## 📁 Project Structure

```
TaskMate/
├── project_frontend (2)/          # Main application directory
│   ├── index.html                 # Main application page
│   ├── profile.html               # User profile page
│   ├── favicon.svg                # Application icon
│   ├── package.json              # Project configuration
│   ├── css/
│   │   └── style.css             # Custom styles and dark mode
│   └── js/                       # JavaScript modules
│       ├── main.js               # Core application logic
│       ├── task-display.js       # Task management functionality
│       ├── task-filters.js       # Filtering and search
│       ├── task-comments.js      # Comments system
│       ├── admin.js              # Admin panel features
│       ├── calendar.js           # Calendar view
│       └── profile.js            # Profile management
├── README.md                     # Project documentation
└── .gitignore                    # Git ignore rules
```

## 🚀 Quick Start

### 1. Clone the Repository
```bash
git clone https://github.com/Omar-agag/TaskMate.git
cd TaskMate
```

### 2. Open in Browser
Simply open `project_frontend (2)/index.html` in your web browser!

### 3. Optional: Use Development Server
```bash
cd "project_frontend (2)"
npm install
npm start
```
Then visit: http://localhost:8084

## 🎯 Usage Guide

### Quick Start

#### **Option 1: Frontend Only (Development)**
1. Navigate to the `frontend/` directory
2. Open `index.html` in your browser
3. Start using the task manager (data stored locally)

#### **Option 2: Full Stack Setup**
1. **Install Dependencies:**
   ```bash
   cd task-manager
   npm run setup
   ```

2. **Database Setup:**
   ```bash
   cd database
   # Follow database/README.md for PostgreSQL setup
   ```

3. **Start Backend:**
   ```bash
   cd backend
   npm run dev
   ```

4. **Access Application:**
   - Frontend: Open `frontend/index.html` in browser
   - API: http://localhost:3000 (if backend is running)

### First Time Setup
1. **Create Account** - Register a new user account
2. **Login** - Sign in with your credentials  
3. **Start Managing Tasks** - Create your first task!

### Creating Tasks
1. Click **"Add New Task"** button
2. Fill in task details:
   - **Title** - Task name
   - **Description** - Detailed information
   - **Priority** - High, Medium, or Low
   - **Due Date** - When it's due
   - **Tags** - Organize with labels
3. Click **"Create Task"** to save

### Using Filters
- **Quick Filters** - Click preset filter buttons
- **Advanced Search** - Use the search bar
- **Multi-Filter** - Combine multiple criteria
- **Sort Options** - Change sort order

### Dark Mode
- **Toggle Switch** - Use the moon icon in navbar
- **Persistent** - Setting saved across sessions
- **Responsive** - Works on all pages

### Admin Features
- **Login as Admin** - Use admin credentials
- **User Management** - View and manage users
- **System Overview** - Check application statistics

## 🔧 Configuration

### Default Settings
```javascript
// Default user roles
roles: ['user', 'admin']

// Task priorities
priorities: ['low', 'medium', 'high']

// Task statuses
statuses: ['pending', 'in-progress', 'completed']

// Default tags
tags: ['work', 'personal', 'urgent', 'meeting']
```

### Customization
- **Themes** - Modify `css/style.css` for custom themes
- **Colors** - Update CSS variables for brand colors
- **Features** - Enable/disable features in JavaScript files

## 📱 Browser Support

| Browser | Version | Status |
|---------|---------|--------|
| Chrome | 90+ | ✅ Fully Supported |
| Firefox | 88+ | ✅ Fully Supported |
| Safari | 14+ | ✅ Fully Supported |
| Edge | 90+ | ✅ Fully Supported |
| Opera | 76+ | ✅ Fully Supported |

## 🚀 Deployment

### GitHub Pages
1. Push code to GitHub repository
2. Enable GitHub Pages in repository settings
3. Select source branch (main)
4. Access via: `https://yourusername.github.io/TaskMate`

### Static Hosting
Works with any static hosting service:
- **Netlify** - Drag and drop deployment
- **Vercel** - Git-based deployment
- **AWS S3** - Bucket hosting
- **Apache/Nginx** - Traditional web servers

### Local Development
```bash
# Using Python (if installed)
python -m http.server 8000

# Using Node.js
npx http-server

# Using PHP (if installed)
php -S localhost:8000
```

## 🧪 Testing

### Manual Testing Checklist
- ✅ User registration and login
- ✅ Task CRUD operations
- ✅ Filtering and search functionality
- ✅ Dark mode toggle
- ✅ Responsive design on mobile
- ✅ Notification system
- ✅ Calendar view navigation
- ✅ Admin panel access
- ✅ Offline functionality

### Browser Testing
Test across different browsers and devices to ensure compatibility.

## 🤝 Contributing

We welcome contributions! Here's how to get started:

### 1. Fork the Repository
```bash
git clone https://github.com/yourusername/TaskMate.git
```

### 2. Create Feature Branch
```bash
git checkout -b feature/your-feature-name
```

### 3. Make Changes
- Follow existing code style
- Test your changes thoroughly
- Update documentation if needed

### 4. Submit Pull Request
- Describe your changes clearly
- Include screenshots if UI changes
- Reference any related issues

### Development Guidelines
- **Code Style** - Follow existing patterns
- **Comments** - Document complex logic
- **Testing** - Test all features before submitting
- **Responsive** - Ensure mobile compatibility

## 📞 Support & Contact

### Getting Help
- **Issues** - Report bugs on [GitHub Issues](https://github.com/Omar-agag/TaskMate/issues)
- **Discussions** - Ask questions in [GitHub Discussions](https://github.com/Omar-agag/TaskMate/discussions)
- **Email** - Contact the maintainer directly

### Feature Requests
Have an idea for TaskMate? We'd love to hear it!
1. Check existing issues first
2. Create a new feature request
3. Describe the use case clearly
4. Explain the expected behavior

## 📊 Project Stats

![GitHub stars](https://img.shields.io/github/stars/Omar-agag/TaskMate)
![GitHub forks](https://img.shields.io/github/forks/Omar-agag/TaskMate)
![GitHub issues](https://img.shields.io/github/issues/Omar-agag/TaskMate)
![GitHub license](https://img.shields.io/github/license/Omar-agag/TaskMate)

## 📝 License

This project is licensed under the **MIT License** - see the [LICENSE](LICENSE) file for details.

```
MIT License

Copyright (c) 2025 Omar Agag

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.
```

## 🎉 Acknowledgments

- **Bootstrap Team** - For the amazing UI framework
- **jQuery Team** - For the powerful JavaScript library  
- **Font Awesome** - For the beautiful icons
- **GitHub** - For hosting and collaboration tools
- **Open Source Community** - For inspiration and support

## 🔮 Roadmap

### Upcoming Features
- [ ] **Real-time Collaboration** - Live updates between users
- [ ] **File Attachments** - Attach files to tasks
- [ ] **Time Tracking** - Track time spent on tasks
- [ ] **Reports & Analytics** - Productivity insights
- [ ] **Mobile App** - Native mobile applications
- [ ] **API Integration** - REST API for external integrations
- [ ] **Email Notifications** - Email alerts for important updates
- [ ] **Team Workspaces** - Organize teams and projects

### Version History
- **v1.0.0** - Initial release with core features
- **v1.1.0** - Dark mode and UI improvements
- **v1.2.0** - Notification system and calendar view
- **v1.3.0** - Admin panel and user management

---

<div align="center">

**⭐ Star this repository if you find it helpful!**

[Report Bug](https://github.com/Omar-agag/TaskMate/issues) • [Request Feature](https://github.com/Omar-agag/TaskMate/issues) • [Documentation](https://github.com/Omar-agag/TaskMate/wiki)

Made with ❤️ by [Omar Agag](https://github.com/Omar-agag)

</div> 