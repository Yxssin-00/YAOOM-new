const jwt = require('jsonwebtoken');

// Use same fallback JWT secret as middleware
const JWT_SECRET = process.env.JWT_SECRET || 'taskmate-demo-secret-key-2025';

const generateToken = (user) => {
  return jwt.sign(
    { id: user.id, email: user.email, role: user.role },
    JWT_SECRET,
    { expiresIn: '1d' }
  );
};

module.exports = generateToken;