const { Pool } = require('pg');

// Database configuration with fallback options
const dbConfig = {
    host: process.env.DB_HOST || 'localhost',
    port: process.env.DB_PORT || 5432,
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || '', // Try empty password first, common default
    database: process.env.DB_NAME || 'postgres', // Use default postgres database
    // Add connection options for better reliability
    max: 20,
    idleTimeoutMillis: 30000,
    connectionTimeoutMillis: 2000,
};

// Create the pool connection
let pool;

async function initializeDatabase() {
    try {
        console.log('🔧 Attempting database connection...');
        
        // First try with empty password (common PostgreSQL default)
        pool = new Pool(dbConfig);
        
        const client = await pool.connect();
        console.log('✅ Database connected successfully');
        
        // Test a simple query
        const result = await client.query('SELECT NOW() as current_time, version() as db_version');
        console.log('📅 Database time:', result.rows[0].current_time);
        console.log('🔧 Database version:', result.rows[0].db_version.substring(0, 50) + '...');
        
        // Check if our target database exists
        const dbCheckResult = await client.query(
            "SELECT 1 FROM pg_database WHERE datname = $1", 
            [process.env.DB_NAME || 'new3.4']
        );
        
        if (dbCheckResult.rows.length === 0) {
            console.log('📋 Target database not found, using default postgres database');
        } else {
            console.log('📋 Target database found and accessible');
        }
        
        client.release();
        return true;
        
    } catch (error) {
        console.log('❌ First connection attempt failed, trying alternative configurations...');
        
        // Try with the original password
        const altConfig = { ...dbConfig, password: '113355' };
        
        try {
            pool = new Pool(altConfig);
            const client = await pool.connect();
            console.log('✅ Database connected with alternative configuration');
            
            const result = await client.query('SELECT NOW() as current_time');
            console.log('📅 Database time:', result.rows[0].current_time);
            client.release();
            return true;
            
        } catch (altError) {
            console.log('❌ Alternative connection also failed, trying to create database setup...');
            
            // Try connecting to default postgres database to create our database
            const setupConfig = {
                ...dbConfig,
                database: 'postgres',
                password: process.env.DB_PASSWORD || ''
            };
            
            try {
                pool = new Pool(setupConfig);
                const client = await pool.connect();
                console.log('✅ Connected to default database for setup');
                
                // Try to create the target database
                const targetDb = process.env.DB_NAME || 'new3.4';
                try {
                    await client.query(`CREATE DATABASE "${targetDb}"`);
                    console.log(`✅ Created database: ${targetDb}`);
                } catch (createError) {
                    if (createError.code === '42P04') {
                        console.log(`📋 Database ${targetDb} already exists`);
                    } else {
                        console.log(`⚠️ Could not create database: ${createError.message}`);
                    }
                }
                
                client.release();
                
                // Now try connecting to our target database
                const finalConfig = { ...dbConfig, database: targetDb };
                pool = new Pool(finalConfig);
                const finalClient = await pool.connect();
                console.log(`✅ Successfully connected to ${targetDb} database`);
                finalClient.release();
                return true;
                
            } catch (setupError) {
                console.error('❌ Database setup failed:', setupError.message);
                return false;
            }
        }
    }
}

// Initialize database connection
let dbInitialized = false;
initializeDatabase().then(success => {
    dbInitialized = success;
    if (!success) {
        console.log('⚠️ Database initialization failed - API will run in offline mode');
        console.log('🔧 To fix database connection:');
        console.log('   1. Ensure PostgreSQL is installed and running');
        console.log('   2. Create a user "postgres" with appropriate password');
        console.log('   3. Or update database credentials in backend/config/db.js');
    }
}).catch(error => {
    console.error('❌ Database initialization error:', error.message);
    dbInitialized = false;
});

// Create a mock pool for offline mode
const mockPool = {
    query: async () => {
        throw new Error('Database not available - running in offline mode');
    },
    connect: async () => {
        throw new Error('Database not available - running in offline mode');
    }
};

// Export the pool with fallback
module.exports = pool || mockPool;