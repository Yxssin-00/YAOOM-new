const taskModel = require('../models/taskModel');

// Mock tasks for offline mode
const DEMO_TASKS = [
    {
        id: 1,
        title: 'Complete Project Review',
        description: 'Review the project documentation and provide feedback',
        status: 'pending',
        priority: 'high',
        due_date: new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString(), // 2 hours from now
        created_at: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(), // 1 day ago
        updated_at: new Date().toISOString(),
        user_id: 1,
        tags: ['work', 'urgent']
    },
    {
        id: 2,
        title: 'Update Documentation',
        description: 'Update the API documentation with new endpoints',
        status: 'in-progress',
        priority: 'medium',
        due_date: new Date(Date.now() + 48 * 60 * 60 * 1000).toISOString(), // 2 days from now
        created_at: new Date(Date.now() - 12 * 60 * 60 * 1000).toISOString(), // 12 hours ago
        updated_at: new Date().toISOString(),
        user_id: 1,
        tags: ['documentation']
    },
    {
        id: 3,
        title: 'Plan Team Meeting',
        description: 'Schedule and plan the next team meeting',
        status: 'completed',
        priority: 'low',
        due_date: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(), // 1 day ago
        created_at: new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString(), // 2 days ago
        updated_at: new Date().toISOString(),
        user_id: 1,
        tags: ['meeting', 'planning']
    }
];

const createTask = async (req, res) => {
  const { title, description, due_date, priority, tags } = req.body;
  try {
    const task = await taskModel.createTask(
      req.user.id,
      title,
      description,
      due_date,
      priority
    );
    res.status(201).json(task);
  } catch (err) {
    console.error('Database create task failed, using offline mode:', err.message);
    
    // Fallback to mock response for offline mode
    const newTask = {
      id: Date.now(), // Simple ID generation
      title,
      description,
      status: 'pending',
      priority: priority || 'medium',
      due_date,
      created_at: new Date().toISOString(),
      updated_at: new Date().toISOString(),
      user_id: req.user.id,
      tags: tags || []
    };
    
    res.status(201).json({
      ...newTask,
      message: 'Task created in offline mode',
      offline_mode: true
    });
  }
};

const getMyTasks = async (req, res) => {
  try {
    const tasks = await taskModel.getTasksByUser(req.user.id);
    res.json(tasks);
  } catch (err) {
    console.error('Database get tasks failed, using offline mode:', err.message);
    
    // Fallback to demo tasks for offline mode
    res.json({
      tasks: DEMO_TASKS,
      count: DEMO_TASKS.length,
      message: 'Using demo tasks - database offline',
      offline_mode: true
    });
  }
};

const updateTask = async (req, res) => {
  const { title, description, due_date, priority, status, tags } = req.body;
  const taskId = req.params.id;
  try {
    const task = await taskModel.getTaskById(taskId);
    if (!task || task.user_id !== req.user.id)
      return res.status(403).json({ message: 'Unauthorized' });

    const updated = await taskModel.updateTask(
      taskId,
      title,
      description,
      due_date,
      priority
    );
    res.json(updated);
  } catch (err) {
    console.error('Database update task failed, using offline mode:', err.message);
    
    // Fallback to mock response for offline mode
    const updatedTask = {
      id: parseInt(taskId),
      title: title || 'Updated Task',
      description: description || 'Task updated in offline mode',
      status: status || 'pending',
      priority: priority || 'medium',
      due_date,
      updated_at: new Date().toISOString(),
      user_id: req.user.id,
      tags: tags || []
    };
    
    res.json({
      ...updatedTask,
      message: 'Task updated in offline mode',
      offline_mode: true
    });
  }
};

const deleteTask = async (req, res) => {
  const taskId = req.params.id;
  try {
    const task = await taskModel.getTaskById(taskId);
    if (!task || task.user_id !== req.user.id)
      return res.status(403).json({ message: 'Unauthorized' });

    await taskModel.deleteTask(taskId);
    res.json({ message: 'Task deleted successfully' });
  } catch (err) {
    console.error('Database delete task failed, using offline mode:', err.message);
    
    // Fallback to mock response for offline mode
    res.json({ 
      message: 'Task deleted successfully (offline mode)',
      taskId: parseInt(taskId),
      offline_mode: true
    });
  }
};

module.exports = {
  createTask,
  getMyTasks,
  updateTask,
  deleteTask,
};