const bcrypt = require('bcryptjs');
const generateToken = require('../utils/generateToken');
const { createUser, findUserByEmail } = require('../models/userModel');

// Generate fresh hashed password for demo users
const createDemoPassword = async () => {
  return await bcrypt.hash('password', 10);
};

// Offline mode demo users (passwords will be initialized on first use)
let DEMO_USERS = null;

const initializeDemoUsers = async () => {
  if (DEMO_USERS) return DEMO_USERS;
  
  const hashedPassword = await createDemoPassword();
  DEMO_USERS = [
    {
      id: 1,
      username: 'John Doe',
      email: 'john@example.com',
      password: hashedPassword,
      role: 'user'
    },
    {
      id: 2,
      username: 'Admin User',
      email: 'admin@example.com',
      password: hashedPassword,
      role: 'admin'
    }
  ];
  
  console.log('✅ Demo users initialized for offline mode');
  return DEMO_USERS;
};

const register = async (req, res) => {
  const { username, email, password } = req.body;
  try {
    // Try database first
    const existingUser = await findUserByEmail(email);
    if (existingUser) {
      return res.status(400).json({ message: 'Email already registered' });
    }

    const hashedPassword = await bcrypt.hash(password, 10);
    const user = await createUser(username, email, hashedPassword);
    const token = generateToken(user);

    res.status(201).json({ user, token });
  } catch (err) {
    // Fallback to offline mode
    console.log('Database unavailable, using offline mode for registration');
    
    // Initialize demo users
    const demoUsers = await initializeDemoUsers();
    
    // Check if email exists in demo users
    const existingDemoUser = demoUsers.find(u => u.email === email);
    if (existingDemoUser) {
      return res.status(400).json({ message: 'Email already registered (demo mode)' });
    }

    // Create demo user
    const hashedPassword = await bcrypt.hash(password, 10);
    const newUser = {
      id: Date.now(),
      username,
      email,
      password: hashedPassword,
      role: 'user'
    };
    
    const token = generateToken(newUser);
    res.status(201).json({ 
      user: { id: newUser.id, username: newUser.username, email: newUser.email, role: newUser.role },
      token,
      mode: 'offline'
    });
  }
};

const login = async (req, res) => {
  const { email, password } = req.body;
  
  console.log(`🔑 Login attempt for: ${email}`);
  
  try {
    // Try database first
    const user = await findUserByEmail(email);
    if (!user) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    const isPasswordCorrect = await bcrypt.compare(password, user.password);
    if (!isPasswordCorrect) {
      return res.status(401).json({ message: 'Invalid credentials' });
    }

    const token = generateToken(user);
    res.json({ user, token });
  } catch (err) {
    // Fallback to offline mode with demo users
    console.log('🔄 Database unavailable, using offline mode for login');
    
    // Initialize demo users
    const demoUsers = await initializeDemoUsers();
    
    const demoUser = demoUsers.find(u => u.email === email);
    if (!demoUser) {
      console.log(`❌ Demo user not found for email: ${email}`);
      return res.status(401).json({ message: 'Invalid credentials (demo mode)' });
    }

    console.log(`✅ Demo user found: ${demoUser.username}`);
    
    const isPasswordCorrect = await bcrypt.compare(password, demoUser.password);
    if (!isPasswordCorrect) {
      console.log('❌ Password verification failed for demo user');
      return res.status(401).json({ message: 'Invalid credentials (demo mode)' });
    }

    console.log('✅ Password verified successfully for demo user');
    
    const token = generateToken(demoUser);
    res.json({ 
      user: { id: demoUser.id, username: demoUser.username, email: demoUser.email, role: demoUser.role },
      token,
      mode: 'offline'
    });
  }
};

module.exports = { register, login };