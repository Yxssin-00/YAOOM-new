const express = require('express');
const cors = require('cors');
require('dotenv').config();
const pool = require('./config/db');

const app = express();

// CORS configuration
app.use(cors({
    origin: [
        'http://localhost:3000', 
        'http://127.0.0.1:3000', 
        'http://localhost:8080', 
        'http://127.0.0.1:8080',
        'http://localhost:8084',  // Add frontend port
        'http://127.0.0.1:8084',  // Add frontend port with IP
        'http://localhost:5500',  // Live Server default
        'http://127.0.0.1:5500',  // Live Server default with IP
        'file://',                // Allow file:// protocol for local files
        null                      // Allow null origin for local files
    ],
    credentials: true,
    methods: ['GET', 'POST', 'PUT', 'DELETE', 'OPTIONS'],
    allowedHeaders: ['Content-Type', 'Authorization', 'X-Requested-With'],
    preflightContinue: false,
    optionsSuccessStatus: 204
}));

app.use(express.json());

const authRoutes = require('./routes/authRoutes');
const userRoutes = require('./routes/userRoutes');
const taskRoutes = require('./routes/taskRoutes');
const notificationRoutes = require('./routes/notificationRoutes');

// Health check endpoint
app.get('/api/health', async (req, res) => {
    try {
        // Always return success for API status
        const healthData = {
            status: 'OK',
            message: 'TaskMate API is healthy',
            timestamp: new Date().toISOString(),
            api: 'Connected',
            version: '1.0.0'
        };

        // Try to test database connection
        try {
            const result = await pool.query('SELECT NOW() as current_time, version() as db_version');
            healthData.database = 'Connected';
            healthData.database_time = result.rows[0].current_time;
            healthData.database_version = result.rows[0].db_version;
        } catch (dbError) {
            // Database error doesn't make API unhealthy
            healthData.database = 'Offline';
            healthData.database_error = dbError.message;
            healthData.fallback_mode = 'localStorage';
        }

        res.status(200).json(healthData);
    } catch (error) {
        console.error('Health check failed:', error);
        res.status(500).json({ 
            status: 'ERROR',
            message: 'API health check failed',
            error: error.message
        });
    }
});

app.use('/api/auth', authRoutes);
app.use('/api/user', userRoutes);
app.use('/api/task', taskRoutes);
app.use('/api/notifications', notificationRoutes);

app.get('/', (req, res) => {
    res.json({
        message: 'TaskMate API is running',
        version: '1.0.0',
        status: 'Online',
        endpoints: {
            health: '/api/health',
            auth: '/api/auth/* (register, login, verify, logout)',
            users: '/api/user/*',
            tasks: '/api/task/*',
            notifications: '/api/notifications/* (/, /due-soon)'
        },
        features: {
            offline_mode: 'Enabled when database is unavailable',
            demo_data: 'Available for testing',
            cors: 'Configured for multiple origins'
        }
    });
});

const PORT = process.env.PORT || 3000;

app.listen(PORT, () => {
    console.log(`🚀 TaskMate API Server is running on http://localhost:${PORT}`);
    console.log(`📊 Health check available at: http://localhost:${PORT}/api/health`);
    console.log(`🔧 Environment: ${process.env.NODE_ENV || 'development'}`);
});

module.exports = app;