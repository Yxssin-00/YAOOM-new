const express = require('express');
const router = express.Router();
const { authenticateToken } = require('../middlewares/authMiddleware');

// Get all notifications for user
router.get('/', authenticateToken, async (req, res) => {
    try {
        // Mock notifications for demo/offline mode
        const mockNotifications = [
            {
                id: 1,
                title: 'Task Due Soon',
                message: 'Your task "Complete project review" is due in 2 hours',
                type: 'due-date',
                priority: 'urgent',
                timestamp: new Date(Date.now() - 30 * 60 * 1000).toISOString(), // 30 minutes ago
                taskId: 1
            },
            {
                id: 2,
                title: 'New Comment',
                message: 'John Doe commented on your task',
                type: 'comment',
                priority: 'normal',
                timestamp: new Date(Date.now() - 60 * 60 * 1000).toISOString(), // 1 hour ago
                taskId: 2
            }
        ];

        res.json(mockNotifications);
    } catch (error) {
        console.error('Error fetching notifications:', error);
        res.status(500).json({ 
            error: 'Failed to fetch notifications',
            message: error.message 
        });
    }
});

// Get due soon notifications
router.get('/due-soon', authenticateToken, async (req, res) => {
    try {
        // Mock due soon notifications
        const dueSoonNotifications = [
            {
                id: 1,
                title: 'Task Due Soon',
                message: 'Your task "Complete project review" is due in 2 hours',
                type: 'due-date',
                priority: 'urgent',
                timestamp: new Date().toISOString(),
                taskId: 1,
                dueDate: new Date(Date.now() + 2 * 60 * 60 * 1000).toISOString() // 2 hours from now
            },
            {
                id: 3,
                title: 'Task Overdue',
                message: 'Your task "Update documentation" is overdue by 1 day',
                type: 'overdue',
                priority: 'critical',
                timestamp: new Date().toISOString(),
                taskId: 3,
                dueDate: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString() // 1 day ago
            }
        ];

        res.json(dueSoonNotifications);
    } catch (error) {
        console.error('Error fetching due soon notifications:', error);
        res.status(500).json({ 
            error: 'Failed to fetch due soon notifications',
            message: error.message 
        });
    }
});

// Mark notification as read/dismissed
router.put('/:id/dismiss', authenticateToken, async (req, res) => {
    try {
        const notificationId = req.params.id;
        
        // In a real implementation, you would update the database
        // For now, just return success
        res.json({
            success: true,
            message: `Notification ${notificationId} dismissed`
        });
    } catch (error) {
        console.error('Error dismissing notification:', error);
        res.status(500).json({ 
            error: 'Failed to dismiss notification',
            message: error.message 
        });
    }
});

module.exports = router; 