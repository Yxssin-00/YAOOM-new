const express = require('express');
const router = express.Router();
const { register, login } = require('../controllers/authController');
const { authenticateToken } = require('../middlewares/authMiddleware');

router.post('/register', register);
router.post('/login', login);

// Token verification endpoint
router.get('/verify', authenticateToken, (req, res) => {
    // If we reach here, the token is valid (middleware passed)
    res.json({
        valid: true,
        user: req.user,
        message: 'Token is valid'
    });
});

// Logout endpoint (client-side mainly, but useful for cleanup)
router.post('/logout', authenticateToken, (req, res) => {
    // In a full implementation, you might blacklist the token
    res.json({
        success: true,
        message: 'Logged out successfully'
    });
});

module.exports = router;