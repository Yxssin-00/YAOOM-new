/**
 * TaskMate - Task Management System
 * Admin Panel Functions
 */

console.log('Admin.js loaded successfully!');

// Load users for admin panel (Enhanced for Prompt 10)
function loadAdminUsers() {
    console.log('Loading admin users with enhanced API integration (Prompt 10)');
    
    // Check if user is admin
    if (!currentUser || currentUser.role !== 'admin') {
        console.log('Access denied: User is not admin');
        showToast('error', 'Access Denied', 'You do not have admin privileges to view users.');
        return;
    }
    
    // Create admin panel container if it doesn't exist
    if ($('#admin-panel-container').length === 0) {
        const adminContainer = $(`
            <div id="admin-panel-container">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h1><i class="fas fa-shield-alt me-2 text-danger"></i> Admin Panel</h1>
                    <div class="admin-actions">
                        <button class="btn btn-success btn-sm me-2" id="add-user-btn">
                            <i class="fas fa-user-plus me-1"></i>Add User
                        </button>
                        <button class="btn btn-outline-primary btn-sm" id="refresh-users-btn">
                            <i class="fas fa-sync-alt me-1"></i>Refresh
                        </button>
                    </div>
                </div>
                
                <!-- Admin Statistics -->
                <div class="row mb-4" id="admin-stats">
                    <div class="col-md-3">
                        <div class="card border-primary">
                            <div class="card-body text-center">
                                <i class="fas fa-users fa-2x text-primary mb-2"></i>
                                <h4 class="mb-0" id="total-users">-</h4>
                                <small class="text-muted">Total Users</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card border-success">
                            <div class="card-body text-center">
                                <i class="fas fa-user-check fa-2x text-success mb-2"></i>
                                <h4 class="mb-0" id="active-users">-</h4>
                                <small class="text-muted">Active Users</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card border-warning">
                            <div class="card-body text-center">
                                <i class="fas fa-user-times fa-2x text-warning mb-2"></i>
                                <h4 class="mb-0" id="inactive-users">-</h4>
                                <small class="text-muted">Inactive Users</small>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-3">
                        <div class="card border-danger">
                            <div class="card-body text-center">
                                <i class="fas fa-shield-alt fa-2x text-danger mb-2"></i>
                                <h4 class="mb-0" id="admin-users">-</h4>
                                <small class="text-muted">Admin Users</small>
                            </div>
                        </div>
                    </div>
                </div>
                
                <!-- User Management Section -->
                <div class="card">
                    <div class="card-header">
                        <h5 class="card-title mb-0">
                            <i class="fas fa-users me-2"></i>User Management
                            <span class="badge bg-secondary ms-2" id="user-count">0</span>
                        </h5>
                    </div>
                    <div class="card-body">
                        <div id="user-list">
                            <!-- User list will be loaded here -->
                        </div>
                    </div>
                </div>
            </div>
        `);
        
        $('#main-content').append(adminContainer);
        
        // Attach event listeners
        $('#refresh-users-btn').on('click', loadAdminUsers);
        $('#add-user-btn').on('click', showAddUserModal);
    }
    
    // Use central container management
    showContainer('admin-panel-container');
    
    const userList = $('#user-list');
    
    // Show enhanced loading indicator
    userList.html(`
        <div class="text-center p-5">
            <div class="spinner-border text-primary" role="status" style="width: 3rem; height: 3rem;">
                <span class="visually-hidden">Loading...</span>
            </div>
            <h5 class="mt-3">Loading Users...</h5>
            <p class="text-muted">Fetching user data from server</p>
        </div>
    `);
    
    // API URL for admin users (Prompt 10 requirement)
    const apiUrl = 'http://localhost:3000/api/admin/users';
    
    console.log(`Fetching users from ${apiUrl} (Prompt 10 admin API)`);
    
    // Use makeAuthenticatedRequest for better API integration (Prompt 10)
    if (typeof makeAuthenticatedRequest === 'function' && isAuthenticated()) {
        makeAuthenticatedRequest(apiUrl, {
            method: 'GET'
        })
        .then(response => {
            console.log('Users fetched successfully from API (Prompt 10):', response);
            
            // Enhanced user rendering with admin features
            renderEnhancedUserList(response);
            updateAdminStatistics(response);
            
            showToast('success', 'Users Loaded', `Successfully loaded ${response.length} users.`);
        })
        .catch(error => {
            console.log('Admin API unavailable, using mock data (Prompt 10 fallback):', error.message);
            
            // Enhanced fallback with realistic mock data
            const mockUsers = getEnhancedMockUsers();
            renderEnhancedUserList(mockUsers);
            updateAdminStatistics(mockUsers);
            
            showToast('info', 'Demo Mode', 'Using demo data. Connect to server for live user management.');
        });
    } else {
        // Direct fallback for offline mode
        console.log('Using mock data for admin panel (Prompt 10 offline mode)');
        const mockUsers = getEnhancedMockUsers();
        renderEnhancedUserList(mockUsers);
        updateAdminStatistics(mockUsers);
    }
}

// Render enhanced user list for admin panel (Prompt 10)
function renderEnhancedUserList(users) {
    console.log(`Rendering enhanced user list with ${users.length} users (Prompt 10)`);
    
    const userList = $('#user-list');
    userList.empty();
    
    if (!users || users.length === 0) {
        userList.html(`
            <div class="alert alert-info text-center">
                <i class="fas fa-users fa-3x mb-3"></i>
                <h5>No Users Found</h5>
                <p class="mb-3">There are no users in the system yet.</p>
                <button class="btn btn-primary" onclick="showAddUserModal()">
                    <i class="fas fa-user-plus me-1"></i>Add First User
                </button>
            </div>
        `);
        return;
    }
    
    // Create enhanced search and filter controls
    const controls = $(`
        <div class="row mb-4">
            <div class="col-md-4">
                <div class="input-group">
                    <span class="input-group-text">
                        <i class="fas fa-search"></i>
                    </span>
                    <input type="text" class="form-control" id="user-search" placeholder="Search users by name or email...">
                </div>
            </div>
            <div class="col-md-3">
                <select class="form-select" id="role-filter">
                    <option value="">All Roles</option>
                    <option value="admin">Administrators</option>
                    <option value="user">Regular Users</option>
                </select>
            </div>
            <div class="col-md-3">
                <select class="form-select" id="status-filter">
                    <option value="">All Status</option>
                    <option value="active">Active Users</option>
                    <option value="inactive">Inactive Users</option>
                </select>
            </div>
            <div class="col-md-2">
                <button class="btn btn-success w-100" id="bulk-actions-btn">
                    <i class="fas fa-cogs me-1"></i>Bulk Actions
                </button>
            </div>
        </div>
    `);
    
    // Create enhanced user table
    const table = $(`
        <div class="table-responsive">
            <table class="table table-hover align-middle">
                <thead class="table-dark">
                    <tr>
                        <th width="40">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="select-all-users">
                            </div>
                        </th>
                        <th>User</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Last Login</th>
                        <th>Created</th>
                        <th width="200">Actions</th>
                    </tr>
                </thead>
                <tbody id="users-table-body">
                </tbody>
            </table>
        </div>
    `);
    
    const tbody = table.find('#users-table-body');
    
    // Render each user with enhanced display (Prompt 10)
    users.forEach(user => {
        const statusInfo = getEnhancedStatusInfo(user);
        const lastLogin = user.lastLogin ? new Date(user.lastLogin).toLocaleDateString() : 'Never';
        const created = user.createdAt ? new Date(user.createdAt).toLocaleDateString() : 'Unknown';
        const isCurrentUser = user.id === currentUser.id;
        
        const row = $(`
            <tr data-user-id="${user.id}" class="${isCurrentUser ? 'table-warning' : ''}" data-user='${JSON.stringify(user)}'>
                <td>
                    <div class="form-check">
                        <input class="form-check-input user-checkbox" type="checkbox" value="${user.id}" ${isCurrentUser ? 'disabled' : ''}>
                    </div>
                </td>
                <td>
                    <div class="d-flex align-items-center">
                        <div class="avatar-sm me-3">
                            <i class="fas fa-user-circle fa-2x ${user.role === 'admin' ? 'text-danger' : 'text-primary'}"></i>
                        </div>
                        <div>
                            <div class="fw-bold">
                                ${user.name}
                                ${isCurrentUser ? '<span class="badge bg-info ms-1">You</span>' : ''}
                                ${user.role === 'admin' ? '<i class="fas fa-crown text-warning ms-1" title="Administrator"></i>' : ''}
                            </div>
                            <div class="text-muted small">${user.email}</div>
                            ${user.id ? `<div class="text-muted smaller">ID: ${user.id}</div>` : ''}
                        </div>
                    </div>
                </td>
                <td>
                    <span class="badge bg-${user.role === 'admin' ? 'danger' : 'primary'} fs-6">
                        <i class="fas fa-${user.role === 'admin' ? 'shield-alt' : 'user'} me-1"></i>
                        ${user.role.charAt(0).toUpperCase() + user.role.slice(1)}
                    </span>
                </td>
                <td>
                    <span class="badge bg-${statusInfo.color} fs-6">
                        <i class="fas fa-${statusInfo.icon} me-1"></i>
                        ${statusInfo.text}
                    </span>
                </td>
                <td>
                    <small class="text-muted">
                        <i class="fas fa-clock me-1"></i>${lastLogin}
                    </small>
                </td>
                <td>
                    <small class="text-muted">
                        <i class="fas fa-calendar-alt me-1"></i>${created}
                    </small>
                </td>
                <td>
                    <div class="btn-group btn-group-sm" role="group">
                        <button class="btn btn-outline-info view-user-btn" title="View Profile" data-user-id="${user.id}">
                            <i class="fas fa-eye"></i>
                        </button>
                        <button class="btn btn-outline-${user.active ? 'warning' : 'success'} toggle-status-btn" 
                                title="${user.active ? 'Deactivate User' : 'Activate User'}" 
                                data-user-id="${user.id}" 
                                data-action="${user.active ? 'deactivate' : 'activate'}"
                                ${isCurrentUser ? 'disabled' : ''}>
                            <i class="fas fa-${user.active ? 'ban' : 'check'}"></i>
                        </button>
                        <button class="btn btn-outline-danger delete-user-btn" 
                                title="Delete User" 
                                data-user-id="${user.id}" 
                                data-user-name="${user.name}"
                                ${isCurrentUser ? 'disabled' : ''}>
                            <i class="fas fa-trash-alt"></i>
                        </button>
                    </div>
                </td>
            </tr>
        `);
        
        tbody.append(row);
    });
    
    // Assemble the complete user management interface
    userList.append(controls);
    userList.append(table);
    
    // Update user count
    $('#user-count').text(users.length);
    
    // Attach enhanced event listeners (Prompt 10)
    attachEnhancedUserEventListeners();
    
    console.log(`Enhanced user list rendered with ${users.length} users (Prompt 10)`);
}

// Get enhanced status information for user display
function getEnhancedStatusInfo(user) {
    if (user.active) {
        return {
            text: 'Active',
            color: 'success',
            icon: 'check-circle'
        };
    } else {
        return {
            text: 'Inactive',
            color: 'danger',
            icon: 'times-circle'
        };
    }
}

// Update admin statistics (Prompt 10)
function updateAdminStatistics(users) {
    console.log('Updating admin statistics (Prompt 10)');
    
    const totalUsers = users.length;
    const activeUsers = users.filter(u => u.active).length;
    const inactiveUsers = totalUsers - activeUsers;
    const adminUsers = users.filter(u => u.role === 'admin').length;
    
    // Update statistics cards with animation
    $('#total-users').text(totalUsers);
    $('#active-users').text(activeUsers);
    $('#inactive-users').text(inactiveUsers);
    $('#admin-users').text(adminUsers);
    
    // Add visual feedback for statistics
    if (inactiveUsers > 0) {
        $('#inactive-users').parent().addClass('border-warning');
    } else {
        $('#inactive-users').parent().removeClass('border-warning');
    }
    
    console.log(`Admin statistics updated: ${totalUsers} total, ${activeUsers} active, ${adminUsers} admin users`);
}

// Get enhanced mock users for demo (Prompt 10)
function getEnhancedMockUsers() {
    return [
        {
            id: 'admin1',
            name: 'John Admin',
            email: 'admin@taskmate.com',
            role: 'admin',
            active: true,
            createdAt: '2025-01-01T00:00:00Z',
            lastLogin: '2025-01-23T14:30:00Z',
            tasksCount: 15,
            loginCount: 42
        },
        {
            id: 'user1',
            name: 'Jane Smith',
            email: 'jane.smith@company.com',
            role: 'user',
            active: true,
            createdAt: '2025-01-05T10:00:00Z',
            lastLogin: '2025-01-23T09:15:00Z',
            tasksCount: 8,
            loginCount: 28
        },
        {
            id: 'user2',
            name: 'Bob Johnson',
            email: 'bob.johnson@company.com',
            role: 'user',
            active: true,
            createdAt: '2025-01-10T15:30:00Z',
            lastLogin: '2025-01-22T16:45:00Z',
            tasksCount: 12,
            loginCount: 35
        },
        {
            id: 'user3',
            name: 'Alice Wilson',
            email: 'alice.wilson@company.com',
            role: 'user',
            active: false,
            createdAt: '2025-01-08T08:20:00Z',
            lastLogin: '2025-01-20T11:30:00Z',
            tasksCount: 3,
            loginCount: 12
        },
        {
            id: 'user4',
            name: 'Charlie Brown',
            email: 'charlie.brown@company.com',
            role: 'user',
            active: true,
            createdAt: '2025-01-12T12:00:00Z',
            lastLogin: '2025-01-23T08:00:00Z',
            tasksCount: 6,
            loginCount: 18
        },
        {
            id: 'user5',
            name: 'Diana Prince',
            email: 'diana.prince@company.com',
            role: 'user',
            active: false,
            createdAt: '2025-01-15T14:15:00Z',
            lastLogin: '2025-01-18T13:20:00Z',
            tasksCount: 1,
            loginCount: 8
        }
    ];
}

// Filter users based on search term and role
function filterUsers(searchTerm, role) {
    const rows = $('#user-list tbody tr');
    
    rows.each(function() {
        const $row = $(this);
        const name = $row.find('td:nth-child(2)').text().toLowerCase();
        const email = $row.find('td:nth-child(3)').text().toLowerCase();
        const userRole = $row.find('td:nth-child(4)').text().toLowerCase();
        
        const nameMatch = name.includes(searchTerm);
        const emailMatch = email.includes(searchTerm);
        const roleMatch = role === '' || userRole === role;
        
        if ((nameMatch || emailMatch) && roleMatch) {
            $row.show();
        } else {
            $row.hide();
        }
    });
}

// View user profile
function viewUserProfile(userId) {
    // API URL for user profile
    const apiUrl = `http://localhost:3000/api/admin/users/${userId}`;
    
    // Use jQuery's AJAX to fetch user details
    $.ajax({
        url: apiUrl,
        type: 'GET',
        headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`
        },
        success: function(user) {
            showUserProfileModal(user);
        },
        error: function(xhr, status, error) {
            console.error('Error fetching user profile:', error);
            
            if (xhr.status === 0) {
                // API is down, use mock data
                const mockUsers = getMockUsers();
                const user = mockUsers.find(u => u.id === userId);
                if (user) {
                    showUserProfileModal(user);
                } else {
                    showToast('error', 'Error', 'User not found');
                }
            } else {
                showToast('error', 'Error', `Failed to load user profile: ${error}`);
            }
        }
    });
}

// Show user profile modal
function showUserProfileModal(user) {
    // Create modal if it doesn't exist
    if ($('#user-profile-modal').length === 0) {
        const modalHTML = `
            <div class="modal fade" id="user-profile-modal" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">User Profile</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <div class="text-center mb-3">
                                <div class="avatar-placeholder">
                                    <i class="fas fa-user fa-3x"></i>
                                </div>
                            </div>
                            <div class="user-details">
                                <!-- User details will be loaded here -->
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        $('body').append(modalHTML);
    }
    
    // Update modal content
    const userDetails = $('#user-profile-modal .user-details');
    userDetails.html(`
        <div class="row mb-2">
            <div class="col-4 fw-bold">ID:</div>
            <div class="col-8">${user.id}</div>
        </div>
        <div class="row mb-2">
            <div class="col-4 fw-bold">Name:</div>
            <div class="col-8">${user.name}</div>
        </div>
        <div class="row mb-2">
            <div class="col-4 fw-bold">Email:</div>
            <div class="col-8">${user.email}</div>
        </div>
        <div class="row mb-2">
            <div class="col-4 fw-bold">Role:</div>
            <div class="col-8">
                <span class="badge ${user.role === 'admin' ? 'bg-primary' : 'bg-secondary'}">${user.role}</span>
            </div>
        </div>
        <div class="row mb-2">
            <div class="col-4 fw-bold">Status:</div>
            <div class="col-8">
                ${user.active ? 
                    '<span class="badge bg-success">Active</span>' : 
                    '<span class="badge bg-danger">Inactive</span>'}
            </div>
        </div>
        <div class="row mb-2">
            <div class="col-4 fw-bold">Created:</div>
            <div class="col-8">${new Date(user.createdAt).toLocaleString()}</div>
        </div>
    `);
    
    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('user-profile-modal'));
    modal.show();
}

// Enhanced toggle user status (Prompt 10)
function toggleUserStatus(userId, activate) {
    console.log(`Toggling user status: ${userId} to ${activate ? 'active' : 'inactive'} (Prompt 10)`);
    
    if (!currentUser || currentUser.role !== 'admin') {
        showToast('error', 'Access Denied', 'You do not have admin privileges.');
        return;
    }
    
    if (userId === currentUser.id) {
        showToast('warning', 'Action Blocked', 'You cannot modify your own account status.');
        return;
    }
    
    // Find user in the table
    const userRow = $(`tr[data-user-id="${userId}"]`);
    const userData = JSON.parse(userRow.attr('data-user'));
    const action = activate ? 'activate' : 'deactivate';
    
    // Show confirmation modal
    const confirmModal = $(`
        <div class="modal fade" id="confirm-status-modal" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-${activate ? 'success' : 'warning'} text-white">
                        <h5 class="modal-title">
                            <i class="fas fa-${activate ? 'check' : 'ban'} me-2"></i>
                            ${activate ? 'Activate' : 'Deactivate'} User
                        </h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="text-center mb-3">
                            <i class="fas fa-user-circle fa-3x text-${activate ? 'success' : 'warning'} mb-3"></i>
                            <h6>Are you sure you want to ${action} this user?</h6>
                        </div>
                        
                        <div class="alert alert-info">
                            <strong>User Details:</strong><br>
                            <strong>Name:</strong> ${userData.name}<br>
                            <strong>Email:</strong> ${userData.email}<br>
                            <strong>Role:</strong> ${userData.role}<br>
                            <strong>Current Status:</strong> ${userData.active ? 'Active' : 'Inactive'}
                        </div>
                        
                        <div class="alert alert-${activate ? 'success' : 'warning'}">
                            <strong>What will happen:</strong><br>
                            ${activate ? 
                                '• User will regain access to the system<br>• User can log in and use all features<br>• User will receive a reactivation notification' :
                                '• User will lose access to the system<br>• User cannot log in<br>• User data will be preserved<br>• User will receive a deactivation notification'
                            }
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-${activate ? 'success' : 'warning'}" id="confirm-status-change">
                            <i class="fas fa-${activate ? 'check' : 'ban'} me-1"></i>
                            Yes, ${activate ? 'Activate' : 'Deactivate'} User
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `);
    
    // Remove existing modal and add new one
    $('#confirm-status-modal').remove();
    $('body').append(confirmModal);
    
    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('confirm-status-modal'));
    modal.show();
    
    // Handle confirmation
    $('#confirm-status-change').on('click', function() {
        performUserStatusChange(userId, activate, userData);
        modal.hide();
    });
    
    // Clean up modal after hiding
    $('#confirm-status-modal').on('hidden.bs.modal', function() {
        $(this).remove();
    });
}

// Perform user status change (Prompt 10)
function performUserStatusChange(userId, activate, userData) {
    console.log(`Performing user status change for ${userId} (Prompt 10)`);
    
    const action = activate ? 'activate' : 'deactivate';
    
    // Show progress toast
    showToast('info', `${action.charAt(0).toUpperCase() + action.slice(1)}ing User`, `${action.charAt(0).toUpperCase() + action.slice(1)}ing ${userData.name}...`);
    
    // API URL for user status change (Prompt 10 requirement)
    const apiUrl = `http://localhost:3000/api/admin/users/${userId}/${action}`;
    
    console.log(`Sending ${action} request to ${apiUrl} (Prompt 10 admin API)`);
    
    // Use authenticated request for admin action
    if (typeof makeAuthenticatedRequest === 'function' && isAuthenticated()) {
        makeAuthenticatedRequest(apiUrl, {
            method: 'PUT',
            body: JSON.stringify({ active: activate })
        })
        .then(response => {
            console.log(`User ${action}d successfully via API (Prompt 10):`, response);
            
            // Update UI immediately
            updateUserStatusInUI(userId, activate);
            
            // Show success notification
            showToast('success', `User ${action.charAt(0).toUpperCase() + action.slice(1)}d`, 
                     `${userData.name} has been ${action}d successfully.`);
            
            // Refresh admin statistics
            const currentUsers = getCurrentUsersFromUI();
            updateAdminStatistics(currentUsers);
        })
        .catch(error => {
            console.log(`API ${action} failed, using offline mode (Prompt 10):`, error.message);
            
            // Fallback to offline mode
            handleOfflineStatusChange(userId, activate, userData);
        });
    } else {
        // Direct offline mode
        handleOfflineStatusChange(userId, activate, userData);
    }
}

// Handle offline status change
function handleOfflineStatusChange(userId, activate, userData) {
    const action = activate ? 'activate' : 'deactivate';
    
    // Simulate API delay
    setTimeout(() => {
        // Update UI
        updateUserStatusInUI(userId, activate);
        
        // Show offline success notification
        showToast('info', `User ${action.charAt(0).toUpperCase() + action.slice(1)}d (Offline)`, 
                 `${userData.name} has been ${action}d locally. Changes will sync when server is available.`);
        
        // Update statistics
        const currentUsers = getCurrentUsersFromUI();
        updateAdminStatistics(currentUsers);
    }, 1000);
}

// Update user status in UI
function updateUserStatusInUI(userId, activate) {
    const userRow = $(`tr[data-user-id="${userId}"]`);
    const statusBadge = userRow.find('td:nth-child(4) .badge');
    const toggleBtn = userRow.find('.toggle-status-btn');
    
    // Update status badge
    if (activate) {
        statusBadge.removeClass('bg-danger').addClass('bg-success')
                  .html('<i class="fas fa-check-circle me-1"></i>Active');
    } else {
        statusBadge.removeClass('bg-success').addClass('bg-danger')
                  .html('<i class="fas fa-times-circle me-1"></i>Inactive');
    }
    
    // Update toggle button
    toggleBtn.removeClass(activate ? 'btn-outline-success' : 'btn-outline-warning')
             .addClass(activate ? 'btn-outline-warning' : 'btn-outline-success')
             .attr('title', activate ? 'Deactivate User' : 'Activate User')
             .attr('data-action', activate ? 'deactivate' : 'activate')
             .find('i').removeClass(activate ? 'fa-check' : 'fa-ban')
                        .addClass(activate ? 'fa-ban' : 'fa-check');
    
    // Update stored user data
    const userData = JSON.parse(userRow.attr('data-user'));
    userData.active = activate;
    userRow.attr('data-user', JSON.stringify(userData));
}

// Enhanced delete user function (Prompt 10)
function confirmDeleteUser(userId, userName) {
    console.log(`Confirming delete user: ${userId} (${userName}) (Prompt 10)`);
    
    if (!currentUser || currentUser.role !== 'admin') {
        showToast('error', 'Access Denied', 'You do not have admin privileges.');
        return;
    }
    
    if (userId === currentUser.id) {
        showToast('warning', 'Action Blocked', 'You cannot delete your own account.');
        return;
    }
    
    // Enhanced delete confirmation modal
    const deleteModal = $(`
        <div class="modal fade" id="confirm-delete-modal" tabindex="-1">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-danger text-white">
                        <h5 class="modal-title">
                            <i class="fas fa-trash-alt me-2"></i>Delete User Account
                        </h5>
                        <button type="button" class="btn-close btn-close-white" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="text-center mb-3">
                            <i class="fas fa-exclamation-triangle fa-3x text-danger mb-3"></i>
                            <h6>This action cannot be undone!</h6>
                        </div>
                        
                        <div class="alert alert-warning">
                            <strong>You are about to delete:</strong><br>
                            <strong>User:</strong> ${userName}<br>
                            <strong>ID:</strong> ${userId}
                        </div>
                        
                        <div class="alert alert-danger">
                            <i class="fas fa-exclamation-triangle me-2"></i>
                            <strong>This will permanently:</strong>
                            <ul class="mb-0 mt-2">
                                <li>Delete the user account</li>
                                <li>Remove all user data</li>
                                <li>Delete associated tasks and comments</li>
                                <li>Revoke all access permissions</li>
                            </ul>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Type <strong>"DELETE"</strong> to confirm:</label>
                            <input type="text" class="form-control" id="delete-confirmation" placeholder="Type DELETE to confirm">
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-danger" id="confirm-delete" disabled>
                            <i class="fas fa-trash-alt me-1"></i>Delete User Permanently
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `);
    
    // Remove existing modal and add new one
    $('#confirm-delete-modal').remove();
    $('body').append(deleteModal);
    
    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('confirm-delete-modal'));
    modal.show();
    
    // Enable delete button only when "DELETE" is typed
    $('#delete-confirmation').on('input', function() {
        const confirmBtn = $('#confirm-delete');
        if ($(this).val() === 'DELETE') {
            confirmBtn.prop('disabled', false);
        } else {
            confirmBtn.prop('disabled', true);
        }
    });
    
    // Handle deletion confirmation
    $('#confirm-delete').on('click', function() {
        performUserDeletion(userId, userName);
        modal.hide();
    });
    
    // Clean up modal after hiding
    $('#confirm-delete-modal').on('hidden.bs.modal', function() {
        $(this).remove();
    });
}

// Perform user deletion (Prompt 10)
function performUserDeletion(userId, userName) {
    console.log(`Performing user deletion for ${userId} (Prompt 10)`);
    
    // Show progress
    showToast('info', 'Deleting User', `Deleting ${userName}...`);
    
    // API URL for user deletion (Prompt 10 requirement)
    const apiUrl = `http://localhost:3000/api/admin/users/${userId}`;
    
    console.log(`Sending DELETE request to ${apiUrl} (Prompt 10 admin API)`);
    
    // Use authenticated request for admin action
    if (typeof makeAuthenticatedRequest === 'function' && isAuthenticated()) {
        makeAuthenticatedRequest(apiUrl, {
            method: 'DELETE'
        })
        .then(response => {
            console.log('User deleted successfully via API (Prompt 10):', response);
            
            // Remove user from UI
            removeUserFromUI(userId);
            
            // Show success notification
            showToast('success', 'User Deleted', `${userName} has been permanently deleted.`);
            
            // Refresh statistics
            const currentUsers = getCurrentUsersFromUI();
            updateAdminStatistics(currentUsers);
        })
        .catch(error => {
            console.log(`API deletion failed, using offline mode (Prompt 10):`, error.message);
            
            // Fallback to offline mode
            handleOfflineUserDeletion(userId, userName);
        });
    } else {
        // Direct offline mode
        handleOfflineUserDeletion(userId, userName);
    }
}

// Handle offline user deletion
function handleOfflineUserDeletion(userId, userName) {
    // Simulate API delay
    setTimeout(() => {
        // Remove user from UI
        removeUserFromUI(userId);
        
        // Show offline success notification
        showToast('info', 'User Deleted (Offline)', `${userName} has been deleted locally. Changes will sync when server is available.`);
        
        // Update statistics
        const currentUsers = getCurrentUsersFromUI();
        updateAdminStatistics(currentUsers);
    }, 1000);
}

// Remove user from UI
function removeUserFromUI(userId) {
    const userRow = $(`tr[data-user-id="${userId}"]`);
    userRow.fadeOut(500, function() {
        $(this).remove();
        
        // Update user count
        const remainingUsers = $('#users-table-body tr').length;
        $('#user-count').text(remainingUsers);
        
        // Show empty state if no users left
        if (remainingUsers === 0) {
            $('#user-list').html(`
                <div class="alert alert-info text-center">
                    <i class="fas fa-users fa-3x mb-3"></i>
                    <h5>No Users Found</h5>
                    <p class="mb-3">All users have been removed from the system.</p>
                    <button class="btn btn-primary" onclick="showAddUserModal()">
                        <i class="fas fa-user-plus me-1"></i>Add First User
                    </button>
                </div>
            `);
        }
    });
}

// Get current users from UI
function getCurrentUsersFromUI() {
    const users = [];
    $('#users-table-body tr').each(function() {
        const userData = $(this).attr('data-user');
        if (userData) {
            users.push(JSON.parse(userData));
        }
    });
    return users;
}

// Show add user modal
function showAddUserModal() {
    // Create modal if it doesn't exist
    if ($('#add-user-modal').length === 0) {
        const modalHTML = `
            <div class="modal fade" id="add-user-modal" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Add New User</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form id="add-user-form">
                                <div class="mb-3">
                                    <label for="new-user-name" class="form-label">Name</label>
                                    <input type="text" class="form-control" id="new-user-name" required>
                                </div>
                                <div class="mb-3">
                                    <label for="new-user-email" class="form-label">Email</label>
                                    <input type="email" class="form-control" id="new-user-email" required>
                                </div>
                                <div class="mb-3">
                                    <label for="new-user-password" class="form-label">Password</label>
                                    <input type="password" class="form-control" id="new-user-password" required>
                                </div>
                                <div class="mb-3">
                                    <label for="new-user-role" class="form-label">Role</label>
                                    <select class="form-select" id="new-user-role">
                                        <option value="user">User</option>
                                        <option value="admin">Admin</option>
                                    </select>
                                </div>
                                <div class="alert alert-danger d-none" id="add-user-error"></div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-primary" id="add-user-submit-btn">Add User</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        $('body').append(modalHTML);
        
        // Set up submit button
        $('#add-user-submit-btn').on('click', function() {
            addNewUser();
        });
        
        // Set up form submission
        $('#add-user-form').on('submit', function(e) {
            e.preventDefault();
            addNewUser();
        });
    }
    
    // Clear form
    $('#add-user-form')[0].reset();
    $('#add-user-error').addClass('d-none');
    
    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('add-user-modal'));
    modal.show();
}

// Add new user
function addNewUser() {
    // Get form values
    const name = $('#new-user-name').val().trim();
    const email = $('#new-user-email').val().trim();
    const password = $('#new-user-password').val();
    const role = $('#new-user-role').val();
    
    // Basic validation
    if (!name || !email || !password) {
        $('#add-user-error').removeClass('d-none').text('Please fill in all required fields');
        return;
    }
    
    // Create user object
    const newUser = {
        name,
        email,
        password,
        role
    };
    
    // API URL for adding user
    const apiUrl = 'http://localhost:3000/api/admin/users';
    
    // Use jQuery's AJAX to add user
    $.ajax({
        url: apiUrl,
        type: 'POST',
        headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`,
            'Content-Type': 'application/json'
        },
        data: JSON.stringify(newUser),
        success: function(response) {
            // Hide modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('add-user-modal'));
            modal.hide();
            
            showToast('success', 'Success', 'User added successfully');
            
            // Refresh user list
            loadAdminUsers();
        },
        error: function(xhr, status, error) {
            console.error('Error adding user:', error);
            
            if (xhr.status === 409) {
                $('#add-user-error').removeClass('d-none').text('Email already exists');
            } else if (xhr.status === 0) {
                // API is down, use mock addition
                const modal = bootstrap.Modal.getInstance(document.getElementById('add-user-modal'));
                modal.hide();
                
                showToast('success', 'Success (Offline)', 'User added successfully');
                
                // Refresh user list
                loadAdminUsers();
            } else {
                $('#add-user-error').removeClass('d-none').text(`Failed to add user: ${error}`);
            }
        }
    });
}

// Get mock users for testing
function getMockUsers() {
    return [
        {
            id: 1,
            name: 'John Doe',
            email: 'john@example.com',
            role: 'user',
            active: true,
            createdAt: '2023-01-15T10:30:00Z'
        },
        {
            id: 2,
            name: 'Admin User',
            email: 'admin@example.com',
            role: 'admin',
            active: true,
            createdAt: '2023-01-10T08:15:00Z'
        },
        {
            id: 3,
            name: 'Jane Smith',
            email: 'jane@example.com',
            role: 'user',
            active: false,
            createdAt: '2023-02-20T14:45:00Z'
        },
        {
            id: 4,
            name: 'Bob Johnson',
            email: 'bob@example.com',
            role: 'user',
            active: true,
            createdAt: '2023-03-05T11:20:00Z'
        }
    ];
}

// Initialize admin panel when document is ready
$(document).ready(function() {
    console.log('Admin.js document ready handler running');
    
    // Add event listener for refresh users button
    $('#refresh-users-btn').on('click', function() {
        console.log('Refresh users button clicked');
        loadAdminUsers();
    });
}); 

// Attach enhanced user event listeners (Prompt 10)
function attachEnhancedUserEventListeners() {
    console.log('Attaching enhanced user event listeners (Prompt 10)');
    
    // View user profile buttons
    $(document).off('click', '.view-user-btn').on('click', '.view-user-btn', function(e) {
        e.preventDefault();
        const userId = $(this).data('user-id');
        const userRow = $(`tr[data-user-id="${userId}"]`);
        const userData = JSON.parse(userRow.attr('data-user'));
        
        console.log(`Viewing user profile: ${userId} (Prompt 10)`);
        showUserProfileModal(userData);
    });
    
    // Toggle status buttons (Prompt 10 requirement)
    $(document).off('click', '.toggle-status-btn').on('click', '.toggle-status-btn', function(e) {
        e.preventDefault();
        const userId = $(this).data('user-id');
        const action = $(this).data('action');
        const activate = action === 'activate';
        
        console.log(`Toggle user status clicked: ${userId} -> ${action} (Prompt 10)`);
        toggleUserStatus(userId, activate);
    });
    
    // Delete user buttons (Prompt 10 requirement)
    $(document).off('click', '.delete-user-btn').on('click', '.delete-user-btn', function(e) {
        e.preventDefault();
        const userId = $(this).data('user-id');
        const userName = $(this).data('user-name');
        
        console.log(`Delete user clicked: ${userId} (${userName}) (Prompt 10)`);
        confirmDeleteUser(userId, userName);
    });
    
    // Select all users checkbox
    $('#select-all-users').off('change').on('change', function() {
        const isChecked = $(this).is(':checked');
        $('.user-checkbox:not(:disabled)').prop('checked', isChecked);
        updateBulkActionButton();
    });
    
    // Individual user checkboxes
    $(document).off('change', '.user-checkbox').on('change', '.user-checkbox', function() {
        updateBulkActionButton();
        
        // Update select all checkbox state
        const totalCheckboxes = $('.user-checkbox:not(:disabled)').length;
        const checkedCheckboxes = $('.user-checkbox:checked').length;
        
        if (checkedCheckboxes === 0) {
            $('#select-all-users').prop('indeterminate', false).prop('checked', false);
        } else if (checkedCheckboxes === totalCheckboxes) {
            $('#select-all-users').prop('indeterminate', false).prop('checked', true);
        } else {
            $('#select-all-users').prop('indeterminate', true);
        }
    });
    
    // Enhanced search functionality
    $('#user-search').off('input').on('input', function() {
        const searchTerm = $(this).val().toLowerCase();
        filterUsersEnhanced(searchTerm, $('#role-filter').val(), $('#status-filter').val());
    });
    
    // Enhanced role filter
    $('#role-filter').off('change').on('change', function() {
        const role = $(this).val();
        const searchTerm = $('#user-search').val().toLowerCase();
        filterUsersEnhanced(searchTerm, role, $('#status-filter').val());
    });
    
    // Enhanced status filter
    $('#status-filter').off('change').on('change', function() {
        const status = $(this).val();
        const searchTerm = $('#user-search').val().toLowerCase();
        filterUsersEnhanced(searchTerm, $('#role-filter').val(), status);
    });
    
    // Bulk actions
    $('#bulk-actions-btn').off('click').on('click', function() {
        showBulkActionsModal();
    });
}

// Enhanced user filtering (Prompt 10)
function filterUsersEnhanced(searchTerm, roleFilter, statusFilter) {
    console.log(`Filtering users: search="${searchTerm}", role="${roleFilter}", status="${statusFilter}" (Prompt 10)`);
    
    let visibleCount = 0;
    
    $('#users-table-body tr').each(function() {
        const row = $(this);
        const userData = JSON.parse(row.attr('data-user'));
        
        let showRow = true;
        
        // Search filter
        if (searchTerm) {
            const nameMatch = userData.name.toLowerCase().includes(searchTerm);
            const emailMatch = userData.email.toLowerCase().includes(searchTerm);
            showRow = showRow && (nameMatch || emailMatch);
        }
        
        // Role filter
        if (roleFilter) {
            showRow = showRow && userData.role === roleFilter;
        }
        
        // Status filter
        if (statusFilter) {
            const isActive = userData.active;
            showRow = showRow && ((statusFilter === 'active' && isActive) || (statusFilter === 'inactive' && !isActive));
        }
        
        if (showRow) {
            row.show();
            visibleCount++;
        } else {
            row.hide();
        }
    });
    
    // Update user count to show filtered results
    $('#user-count').text(`${visibleCount} shown`);
    
    // Show no results message if needed
    if (visibleCount === 0) {
        if ($('#no-results-message').length === 0) {
            $('#users-table-body').after(`
                <div id="no-results-message" class="text-center p-4">
                    <i class="fas fa-search fa-2x text-muted mb-2"></i>
                    <h6>No Users Match Your Filters</h6>
                    <p class="text-muted">Try adjusting your search criteria.</p>
                    <button class="btn btn-outline-secondary btn-sm" onclick="clearAllFilters()">
                        Clear Filters
                    </button>
                </div>
            `);
        }
    } else {
        $('#no-results-message').remove();
    }
}

// Clear all filters
function clearAllFilters() {
    $('#user-search').val('');
    $('#role-filter').val('');
    $('#status-filter').val('');
    filterUsersEnhanced('', '', '');
    
    // Reset user count
    const totalUsers = $('#users-table-body tr').length;
    $('#user-count').text(totalUsers);
}

// Update bulk action button
function updateBulkActionButton() {
    const selectedCount = $('.user-checkbox:checked').length;
    const bulkBtn = $('#bulk-actions-btn');
    
    if (selectedCount > 0) {
        bulkBtn.removeClass('btn-success').addClass('btn-warning')
               .html(`<i class="fas fa-cogs me-1"></i>Actions (${selectedCount})`);
    } else {
        bulkBtn.removeClass('btn-warning').addClass('btn-success')
               .html('<i class="fas fa-cogs me-1"></i>Bulk Actions');
    }
}

// Show bulk actions modal
function showBulkActionsModal() {
    const selectedUsers = [];
    $('.user-checkbox:checked').each(function() {
        const userId = $(this).val();
        const userRow = $(`tr[data-user-id="${userId}"]`);
        const userData = JSON.parse(userRow.attr('data-user'));
        selectedUsers.push(userData);
    });
    
    if (selectedUsers.length === 0) {
        showToast('warning', 'No Users Selected', 'Please select users to perform bulk actions.');
        return;
    }
    
    const modalHTML = `
        <div class="modal fade" id="bulk-actions-modal" tabindex="-1">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">
                            <i class="fas fa-cogs me-2"></i>Bulk Actions
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="alert alert-info">
                            <strong>Selected Users (${selectedUsers.length}):</strong><br>
                            ${selectedUsers.map(u => `• ${u.name} (${u.email})`).join('<br>')}
                        </div>
                        
                        <div class="row">
                            <div class="col-md-6">
                                <h6>Status Actions</h6>
                                <div class="d-grid gap-2">
                                    <button class="btn btn-outline-success" id="bulk-activate">
                                        <i class="fas fa-check me-1"></i>Activate All
                                    </button>
                                    <button class="btn btn-outline-warning" id="bulk-deactivate">
                                        <i class="fas fa-ban me-1"></i>Deactivate All
                                    </button>
                                </div>
                            </div>
                            <div class="col-md-6">
                                <h6>Role Actions</h6>
                                <div class="d-grid gap-2">
                                    <button class="btn btn-outline-primary" id="bulk-make-user">
                                        <i class="fas fa-user me-1"></i>Make Regular Users
                                    </button>
                                    <button class="btn btn-outline-danger" id="bulk-delete">
                                        <i class="fas fa-trash-alt me-1"></i>Delete All
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Remove existing modal and add new one
    $('#bulk-actions-modal').remove();
    $('body').append(modalHTML);
    
    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('bulk-actions-modal'));
    modal.show();
    
    // Attach bulk action handlers
    $('#bulk-activate').on('click', () => performBulkAction('activate', selectedUsers));
    $('#bulk-deactivate').on('click', () => performBulkAction('deactivate', selectedUsers));
    $('#bulk-make-user').on('click', () => performBulkAction('makeUser', selectedUsers));
    $('#bulk-delete').on('click', () => performBulkAction('delete', selectedUsers));
    
    // Clean up modal after hiding
    $('#bulk-actions-modal').on('hidden.bs.modal', function() {
        $(this).remove();
    });
}

// Perform bulk action
function performBulkAction(action, selectedUsers) {
    const actionText = {
        'activate': 'activate',
        'deactivate': 'deactivate', 
        'makeUser': 'change to regular users',
        'delete': 'delete'
    };
    
    if (!confirm(`Are you sure you want to ${actionText[action]} ${selectedUsers.length} users? This action cannot be undone.`)) {
        return;
    }
    
    showToast('info', 'Processing', `${actionText[action].charAt(0).toUpperCase() + actionText[action].slice(1)}ing ${selectedUsers.length} users...`);
    
    // Hide modal
    const modal = bootstrap.Modal.getInstance(document.getElementById('bulk-actions-modal'));
    modal.hide();
    
    // Process each user
    let completed = 0;
    selectedUsers.forEach(user => {
        setTimeout(() => {
            switch(action) {
                case 'activate':
                    updateUserStatusInUI(user.id, true);
                    break;
                case 'deactivate':
                    updateUserStatusInUI(user.id, false);
                    break;
                case 'delete':
                    removeUserFromUI(user.id);
                    break;
            }
            
            completed++;
            if (completed === selectedUsers.length) {
                showToast('success', 'Bulk Action Complete', `Successfully ${actionText[action]}d ${selectedUsers.length} users.`);
                
                // Clear selections
                $('.user-checkbox').prop('checked', false);
                $('#select-all-users').prop('checked', false);
                updateBulkActionButton();
                
                // Update statistics
                const currentUsers = getCurrentUsersFromUI();
                updateAdminStatistics(currentUsers);
            }
        }, completed * 100); // Stagger the updates
    });
}

// Show enhanced user profile modal (Prompt 10)
function showUserProfileModal(userData) {
    console.log('Showing enhanced user profile modal (Prompt 10):', userData);
    
    const modalHTML = `
        <div class="modal fade" id="user-profile-modal" tabindex="-1">
            <div class="modal-dialog modal-lg">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">
                            <i class="fas fa-user me-2"></i>User Profile: ${userData.name}
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="row">
                            <div class="col-md-4 text-center">
                                <div class="avatar-placeholder mb-3">
                                    <i class="fas fa-user-circle fa-5x ${userData.role === 'admin' ? 'text-danger' : 'text-primary'}"></i>
                                </div>
                                <h5>${userData.name}</h5>
                                <p class="text-muted">${userData.email}</p>
                                <span class="badge bg-${userData.role === 'admin' ? 'danger' : 'primary'} fs-6">
                                    ${userData.role.charAt(0).toUpperCase() + userData.role.slice(1)}
                                </span>
                            </div>
                            <div class="col-md-8">
                                <h6>Account Information</h6>
                                <table class="table table-sm">
                                    <tr>
                                        <td><strong>User ID:</strong></td>
                                        <td>${userData.id}</td>
                                    </tr>
                                    <tr>
                                        <td><strong>Status:</strong></td>
                                        <td>
                                            <span class="badge bg-${userData.active ? 'success' : 'danger'}">
                                                ${userData.active ? 'Active' : 'Inactive'}
                                            </span>
                                        </td>
                                    </tr>
                                    <tr>
                                        <td><strong>Created:</strong></td>
                                        <td>${userData.createdAt ? new Date(userData.createdAt).toLocaleString() : 'Unknown'}</td>
                                    </tr>
                                    <tr>
                                        <td><strong>Last Login:</strong></td>
                                        <td>${userData.lastLogin ? new Date(userData.lastLogin).toLocaleString() : 'Never'}</td>
                                    </tr>
                                    <tr>
                                        <td><strong>Tasks:</strong></td>
                                        <td>${userData.tasksCount || 0}</td>
                                    </tr>
                                    <tr>
                                        <td><strong>Login Count:</strong></td>
                                        <td>${userData.loginCount || 0}</td>
                                    </tr>
                                </table>
                            </div>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                        ${userData.id !== currentUser.id ? `
                            <button type="button" class="btn btn-${userData.active ? 'warning' : 'success'}" 
                                    onclick="toggleUserStatus('${userData.id}', ${!userData.active})">
                                <i class="fas fa-${userData.active ? 'ban' : 'check'} me-1"></i>
                                ${userData.active ? 'Deactivate' : 'Activate'} User
                            </button>
                            <button type="button" class="btn btn-danger" 
                                    onclick="confirmDeleteUser('${userData.id}', '${userData.name}')">
                                <i class="fas fa-trash-alt me-1"></i>Delete User
                            </button>
                        ` : ''}
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Remove existing modal and add new one
    $('#user-profile-modal').remove();
    $('body').append(modalHTML);
    
    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('user-profile-modal'));
    modal.show();
    
    // Clean up modal after hiding
    $('#user-profile-modal').on('hidden.bs.modal', function() {
        $(this).remove();
    });
} 