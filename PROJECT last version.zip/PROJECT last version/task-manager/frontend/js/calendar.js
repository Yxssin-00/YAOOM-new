/**
 * TaskMate - Task Management System
 * Calendar Functions
 */

console.log('Calendar.js loaded successfully!');

// Show calendar view
function showCalendar() {
    console.log('Showing calendar view');
    
    // Update active navigation
    $('.nav-link, .list-group-item').removeClass('active');
    $('#calendar-link, #sidebar-calendar').addClass('active');
    
    // Add event listeners for navigation buttons if not already added
    if (!$('#prev-month-btn').data('events-attached')) {
        $('#prev-month-btn').on('click', function() {
            currentMonth--;
            if (currentMonth < 0) {
                currentMonth = 11;
                currentYear--;
            }
            renderCalendar(currentYear, currentMonth);
        }).data('events-attached', true);
        
        $('#current-month-btn').on('click', function() {
            const today = new Date();
            currentMonth = today.getMonth();
            currentYear = today.getFullYear();
            renderCalendar(currentYear, currentMonth);
        }).data('events-attached', true);
        
        $('#next-month-btn').on('click', function() {
            currentMonth++;
            if (currentMonth > 11) {
                currentMonth = 0;
                currentYear++;
            }
            renderCalendar(currentYear, currentMonth);
        }).data('events-attached', true);
    }
    
    // Use central container management
    showContainer('calendar-container');
    
    // Initialize calendar with current month
    const today = new Date();
    currentMonth = today.getMonth();
    currentYear = today.getFullYear();
    renderCalendar(currentYear, currentMonth);
}

// Global variables for calendar
let currentMonth, currentYear;

// Render calendar for specified month and year
function renderCalendar(year, month) {
    // Update header
    const monthNames = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
    $('#calendar-month-year').text(`${monthNames[month]} ${year}`);
    
    // Get first day of month and number of days
    const firstDay = new Date(year, month, 1).getDay();
    const daysInMonth = new Date(year, month + 1, 0).getDate();
    const today = new Date();
    
    // Create calendar grid
    const calendarBody = $('#calendar-body');
    calendarBody.empty();
    
    // Create table with proper classes for dark mode
    const table = $('<table class="calendar-table"></table>');
    
    // Create header row with day names
    const dayNames = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    const headerRow = $('<tr class="calendar-header"></tr>');
    dayNames.forEach(day => {
        headerRow.append(`<th class="calendar-header-cell">${day}</th>`);
    });
    table.append(headerRow);
    
    // Create calendar cells
    let date = 1;
    for (let i = 0; i < 6; i++) {
        // Create week row
        const row = $('<tr class="calendar-week"></tr>');
        let j = 0; // Declare j outside the inner loop
        
        // Create day cells
        for (j = 0; j < 7; j++) {
            if (i === 0 && j < firstDay) {
                // Empty cells before first day - previous month
                const prevMonth = month === 0 ? 11 : month - 1;
                const prevYear = month === 0 ? year - 1 : year;
                const prevMonthDays = new Date(prevYear, prevMonth + 1, 0).getDate();
                const prevDate = prevMonthDays - (firstDay - j - 1);
                
                row.append(`<td class="calendar-cell empty other-month">
                    <div class="calendar-date">${prevDate}</div>
                    <div class="calendar-events"></div>
                </td>`);
            } else if (date > daysInMonth) {
                // Empty cells after last day - next month
                const nextDate = date - daysInMonth;
                
                row.append(`<td class="calendar-cell empty other-month">
                    <div class="calendar-date">${nextDate}</div>
                    <div class="calendar-events"></div>
                </td>`);
                date++;
            } else {
                // Regular day cell
                const cellDate = new Date(year, month, date);
                const isToday = isSameDate(cellDate, today);
                const isWeekend = j === 0 || j === 6; // Sunday or Saturday
                
                let cellClasses = ['calendar-cell'];
                if (isToday) cellClasses.push('today');
                if (isWeekend) cellClasses.push('weekend');
                
                // Create cell with date and proper styling
                const cellDateString = `${year}-${String(month + 1).padStart(2, '0')}-${String(date).padStart(2, '0')}`;
                const cell = $(`<td class="${cellClasses.join(' ')}" data-date="${cellDateString}">
                    <div class="calendar-date">${date}</div>
                    <div class="calendar-events" data-date="${cellDateString}"></div>
                </td>`);
                
                // Add click handler to show tasks for this date
                cell.on('click', function() {
                    showTasksForDate(cellDateString);
                });
                
                row.append(cell);
                date++;
            }
        }
        
        table.append(row);
        
        // Stop if we've used all days and filled the row
        if (date > daysInMonth && j === 6) {
            break;
        }
    }
    
    // Add table to calendar
    calendarBody.append(table);
    
    // Load tasks for this month
    loadTasksForCalendar(year, month);
}

// Check if two dates are the same (ignoring time)
function isSameDate(date1, date2) {
    return date1.getDate() === date2.getDate() &&
           date1.getMonth() === date2.getMonth() &&
           date1.getFullYear() === date2.getFullYear();
}

// Load tasks for calendar
function loadTasksForCalendar(year, month) {
    // Get all tasks
    fetchTasks().then(tasks => {
        // Clear existing events
        $('.calendar-events').empty();
        
        // Filter tasks for current month
        const monthStart = new Date(year, month, 1);
        const monthEnd = new Date(year, month + 1, 0);
        
        const monthTasks = tasks.filter(task => {
            const dueDate = new Date(task.dueDate);
            return dueDate >= monthStart && dueDate <= monthEnd;
        });
        
        // Group tasks by date and show count
        const tasksByDate = {};
        monthTasks.forEach(task => {
            const dueDate = new Date(task.dueDate);
            const dateString = `${year}-${String(month + 1).padStart(2, '0')}-${String(dueDate.getDate()).padStart(2, '0')}`;
            
            if (!tasksByDate[dateString]) {
                tasksByDate[dateString] = [];
            }
            tasksByDate[dateString].push(task);
        });
        
        // Add task count badges to calendar
        Object.keys(tasksByDate).forEach(dateString => {
            const eventContainer = $(`.calendar-events[data-date="${dateString}"]`);
            const tasks = tasksByDate[dateString];
            
            if (eventContainer.length && tasks.length > 0) {
                // Count tasks by status
                const pendingCount = tasks.filter(t => t.status === 'pending').length;
                const inProgressCount = tasks.filter(t => t.status === 'in-progress').length;
                const completedCount = tasks.filter(t => t.status === 'completed').length;
                
                // Create task count badge
                const taskCountBadge = $(`
                    <div class="task-count-badge" title="${tasks.length} task(s) on this day">
                        <span class="total-count">${tasks.length}</span>
                        ${pendingCount > 0 ? `<span class="status-dot pending" title="${pendingCount} pending"></span>` : ''}
                        ${inProgressCount > 0 ? `<span class="status-dot in-progress" title="${inProgressCount} in progress"></span>` : ''}
                        ${completedCount > 0 ? `<span class="status-dot completed" title="${completedCount} completed"></span>` : ''}
                    </div>
                `);
                
                eventContainer.append(taskCountBadge);
            }
        });
    });
}

// Show tasks for a specific date
function showTasksForDate(dateString) {
    fetchTasks().then(tasks => {
        // Filter tasks for the selected date
        const dateTasks = tasks.filter(task => {
            const taskDate = new Date(task.dueDate);
            const taskDateString = `${taskDate.getFullYear()}-${String(taskDate.getMonth() + 1).padStart(2, '0')}-${String(taskDate.getDate()).padStart(2, '0')}`;
            return taskDateString === dateString;
        });
        
        // Format the date for display
        const [year, month, day] = dateString.split('-');
        const displayDate = new Date(year, month - 1, day).toLocaleDateString('en-US', {
            weekday: 'long',
            year: 'numeric',
            month: 'long',
            day: 'numeric'
        });
        
        // Create modal content
        let modalContent = `
            <div class="modal fade" id="date-tasks-modal" tabindex="-1">
                <div class="modal-dialog modal-lg">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">
                                <i class="fas fa-calendar-day me-2"></i>
                                Tasks for ${displayDate}
                            </h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                        </div>
                        <div class="modal-body">
        `;
        
        if (dateTasks.length === 0) {
            modalContent += `
                <div class="text-center py-4">
                    <i class="fas fa-calendar-check fa-3x text-muted mb-3"></i>
                    <h6>No tasks scheduled for this day</h6>
                    <p class="text-muted">Would you like to create a new task for ${displayDate}?</p>
                    <button class="btn btn-primary" onclick="openAddTaskModal('${dateString}')">
                        <i class="fas fa-plus me-1"></i> Add Task
                    </button>
                </div>
            `;
        } else {
            modalContent += '<div class="row g-3">';
            dateTasks.forEach(task => {
                const priorityClass = `priority-${task.priority}`;
                const statusClass = `status-${task.status}`;
                const priorityIcon = task.priority === 'high' ? 'fa-exclamation-triangle' : 
                                  task.priority === 'medium' ? 'fa-minus-circle' : 'fa-circle';
                const statusIcon = task.status === 'completed' ? 'fa-check-circle' :
                                 task.status === 'in-progress' ? 'fa-spinner' : 'fa-clock';
                
                modalContent += `
                    <div class="col-12">
                        <div class="card task-card ${priorityClass} ${statusClass}">
                            <div class="card-body">
                                <div class="d-flex justify-content-between align-items-start">
                                    <div>
                                        <h6 class="card-title">${task.title}</h6>
                                        <p class="card-text small text-muted">${task.description || 'No description'}</p>
                                        <div class="d-flex gap-2">
                                            <span class="badge bg-${task.priority === 'high' ? 'danger' : task.priority === 'medium' ? 'warning' : 'secondary'}">
                                                <i class="fas ${priorityIcon} me-1"></i>${task.priority}
                                            </span>
                                            <span class="badge bg-${task.status === 'completed' ? 'success' : task.status === 'in-progress' ? 'primary' : 'secondary'}">
                                                <i class="fas ${statusIcon} me-1"></i>${task.status}
                                            </span>
                                        </div>
                                    </div>
                                    <div class="dropdown">
                                        <button class="btn btn-sm btn-outline-secondary dropdown-toggle" data-bs-toggle="dropdown">
                                            <i class="fas fa-ellipsis-v"></i>
                                        </button>
                                        <ul class="dropdown-menu">
                                            <li><a class="dropdown-item" href="#" onclick="openEditTaskModal(${task.id})">
                                                <i class="fas fa-edit me-2"></i>Edit
                                            </a></li>
                                            <li><a class="dropdown-item" href="#" onclick="deleteTask(${task.id})">
                                                <i class="fas fa-trash me-2"></i>Delete
                                            </a></li>
                                        </ul>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                `;
            });
            modalContent += '</div>';
        }
        
        modalContent += `
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                            <button type="button" class="btn btn-primary" onclick="openAddTaskModal('${dateString}')">
                                <i class="fas fa-plus me-1"></i> Add New Task
                            </button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        // Remove existing modal if any
        $('#date-tasks-modal').remove();
        
        // Add modal to page and show it
        $('body').append(modalContent);
        $('#date-tasks-modal').modal('show');
    });
}

// Function to open add task modal with pre-filled date
function openAddTaskModal(dateString) {
    $('#date-tasks-modal').modal('hide');
    showAddTaskModal();
    
    // Pre-fill the due date if the form exists
    setTimeout(() => {
        if ($('#task-due-date').length) {
            $('#task-due-date').val(dateString);
        }
    }, 300);
}

// Initialize calendar when document is ready
$(document).ready(function() {
    console.log('Calendar.js document ready handler running');
}); 