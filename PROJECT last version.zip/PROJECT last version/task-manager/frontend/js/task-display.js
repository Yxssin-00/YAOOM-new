/**
 * TaskMate - Task Management System
 * Task Display and Manipulation Functions
 */

// Global chart instance
let taskStatusChart = null;

// Show dashboard page
function showDashboard() {
    if (!currentUser) return;
    
    // Update active navigation
    $('.nav-link, .list-group-item').removeClass('active');
    $('#dashboard-link, #sidebar-dashboard').addClass('active');
    
    // Use central container management
    showContainer('dashboard-container');
    
    // Load dashboard data
    loadDashboardData();
}

// Load dashboard data (Enhanced for Prompt 4)
function loadDashboardData() {
    console.log('Loading dashboard data with enhanced task display...');
    
    // Check if user is admin and show admin dashboard
    if (currentUser && currentUser.role === 'admin') {
        loadAdminDashboard();
        return;
    }
    
    // Regular user dashboard
    // Fetch tasks from API with enhanced display
    fetchTasks().then((taskData) => {
        console.log(`Dashboard loaded ${taskData.length} tasks from API`);
        
        // Enhanced task status analysis
        const taskStats = analyzeTaskStats(taskData);
        
        // Update dashboard statistics with better UI
        updateDashboardStats(taskStats);
        
        // Create/Update the pie chart with task statistics
        createTaskStatusChart(taskStats);
        
        // Display recent tasks with enhanced visual indicators
        const recentTasks = [...taskData].sort((a, b) => {
            return new Date(b.createdAt || b.id) - new Date(a.createdAt || a.id);
        }).slice(0, 5);
        
        renderRecentTasks(recentTasks);
        
        // Add dashboard status summary
        renderDashboardStatusSummary(taskStats);
    }).catch(error => {
        console.log('Dashboard data loading failed, showing offline state');
        
        // Fallback to empty state with better user experience
        const emptyStats = {
            total: 0,
            pending: 0,
            inProgress: 0,
            completed: 0,
            overdue: 0
        };
        
        updateDashboardStats(emptyStats);
        createTaskStatusChart(emptyStats);
        renderRecentTasks([]);
    });
}

// Load admin-specific dashboard
function loadAdminDashboard() {
    console.log('Loading admin dashboard with system overview...');
    
    // Update dashboard title for admin
    $('#dashboard-container h1').html(`
        <i class="fas fa-shield-alt me-2 text-danger"></i>Admin Dashboard
        <small class="text-muted ms-2">System Overview & Management</small>
    `);
    
    // Load both user tasks and system stats
    fetchTasks().then((taskData) => {
        // Get admin-specific statistics
        const adminStats = analyzeAdminStats(taskData);
        
        // Update statistics cards with admin data
        updateAdminDashboardStats(adminStats);
        
        // Create admin-specific pie chart
        createAdminStatusChart(adminStats);
        
        // Show admin insights instead of regular insights
        updateAdminInsights(adminStats);
        
        // Show recent system activity
        renderAdminRecentActivity();
        
    }).catch(error => {
        console.log('Admin dashboard loading failed, showing fallback');
        showAdminDashboardFallback();
    });
}

// Analyze admin-specific statistics
function analyzeAdminStats(taskData) {
    const totalUsers = 5; // This would come from API in real scenario
    const activeUsers = 3;
    
    return {
        // Regular task stats
        total: taskData.length,
        pending: taskData.filter(task => task.status === 'pending').length,
        inProgress: taskData.filter(task => task.status === 'in-progress').length,
        completed: taskData.filter(task => task.status === 'completed').length,
        
        // Admin-specific stats
        totalUsers: totalUsers,
        activeUsers: activeUsers,
        sharedTasks: taskData.filter(task => task.shared).length,
        overdueSystemTasks: taskData.filter(task => {
            if (!task.dueDate) return false;
            return new Date(task.dueDate) < new Date() && task.status !== 'completed';
        }).length
    };
}

// Update admin dashboard statistics
function updateAdminDashboardStats(stats) {
    $('#total-tasks-count').text(stats.total);
    $('#in-progress-count').text(stats.inProgress);
    $('#completed-count').text(stats.completed);
    
    // Update card titles for admin context
    $('#total-tasks-count').siblings('.card-title').html(`
        <i class="fas fa-tasks me-1"></i>System Tasks
    `);
    $('#in-progress-count').siblings('.card-title').html(`
        <i class="fas fa-spinner me-1"></i>Active Tasks
    `);
    $('#completed-count').siblings('.card-title').html(`
        <i class="fas fa-check-circle me-1"></i>Completed
    `);
}

// Create admin-specific pie chart
function createAdminStatusChart(stats) {
    console.log('Creating admin status chart with data:', stats);
    
    const ctx = document.getElementById('taskStatusChart');
    if (!ctx) return;
    
    // Destroy existing chart
    if (taskStatusChart) {
        taskStatusChart.destroy();
    }
    
    // Admin chart data - includes system overview
    const chartData = {
        labels: ['Pending Tasks', 'Active Tasks', 'Completed Tasks', 'Shared Tasks'],
        datasets: [{
            data: [stats.pending, stats.inProgress, stats.completed, stats.sharedTasks],
            backgroundColor: [
                '#ffc107', // Pending - Warning yellow
                '#0d6efd', // In Progress - Primary blue  
                '#198754', // Completed - Success green
                '#6f42c1'  // Shared - Purple
            ],
            borderColor: [
                '#ffb000',
                '#0b5ed7',
                '#157347',
                '#5a32a3'
            ],
            borderWidth: 2,
            hoverOffset: 15
        }]
    };
    
    const config = {
        type: 'pie',
        data: chartData,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 20,
                        usePointStyle: true,
                        font: { size: 11 }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = total > 0 ? Math.round((context.parsed / total) * 100) : 0;
                            return `${context.label}: ${context.parsed} (${percentage}%)`;
                        }
                    }
                }
            },
            animation: {
                duration: 1200
            }
        }
    };
    
    taskStatusChart = new Chart(ctx, config);
    console.log('Admin chart created successfully');
}

// Update admin insights panel
function updateAdminInsights(stats) {
    const insightsContainer = $('#task-insights');
    
    const userProductivity = stats.totalUsers > 0 ? Math.round((stats.activeUsers / stats.totalUsers) * 100) : 0;
    const taskCompletionRate = stats.total > 0 ? Math.round((stats.completed / stats.total) * 100) : 0;
    
    insightsContainer.html(`
        <div class="insights-content" style="height: 300px; display: flex; flex-direction: column; justify-content: space-between;">
            <!-- Admin Status -->
            <div class="text-center mb-3">
                <i class="fas fa-shield-alt fa-2x text-danger mb-2"></i>
                <p class="mb-0 fw-medium text-danger">System Administrator</p>
                <small class="text-muted">Full system access & control</small>
            </div>
            
            <!-- System Alerts -->
            ${stats.overdueSystemTasks > 0 ? `
            <div class="alert alert-warning border-warning py-2 mb-2">
                <small><i class="fas fa-exclamation-triangle me-1"></i>
                ${stats.overdueSystemTasks} overdue system task${stats.overdueSystemTasks > 1 ? 's' : ''} need attention!
                </small>
            </div>` : ''}
            
            <!-- System Stats -->
            <div class="row text-center mb-3">
                <div class="col-6">
                    <div class="p-2 border rounded bg-light">
                        <div class="fw-bold text-info">${stats.totalUsers}</div>
                        <small class="text-muted">Total Users</small>
                    </div>
                </div>
                <div class="col-6">
                    <div class="p-2 border rounded bg-light">
                        <div class="fw-bold text-success">${userProductivity}%</div>
                        <small class="text-muted">Active Users</small>
                    </div>
                </div>
            </div>
            
            <div class="row text-center mb-3">
                <div class="col-6">
                    <div class="p-2 border rounded bg-light">
                        <div class="fw-bold text-primary">${stats.sharedTasks}</div>
                        <small class="text-muted">Shared Tasks</small>
                    </div>
                </div>
                <div class="col-6">
                    <div class="p-2 border rounded bg-light">
                        <div class="fw-bold text-warning">${taskCompletionRate}%</div>
                        <small class="text-muted">Completion</small>
                    </div>
                </div>
            </div>
            
            <!-- Admin Quick Actions -->
            <div class="d-grid gap-2 mt-auto">
                <button class="btn btn-outline-danger btn-sm" onclick="showAdminPanel()">
                    <i class="fas fa-users-cog me-1"></i>Manage Users
                </button>
                <button class="btn btn-outline-info btn-sm" onclick="showSharedTasks()">
                    <i class="fas fa-share-alt me-1"></i>View Shared Tasks
                </button>
                <button class="btn btn-outline-success btn-sm" onclick="$('#new-task-btn').click()">
                    <i class="fas fa-plus me-1"></i>Create System Task
                </button>
            </div>
        </div>
    `);
}

// Render admin recent activity
function renderAdminRecentActivity() {
    const container = $('#recent-tasks-container');
    
    container.html(`
        <div class="row">
            <div class="col-md-6">
                <h5 class="mb-3"><i class="fas fa-clock me-2"></i>Recent System Activity</h5>
                <div class="admin-activity-feed">
                    <div class="activity-item mb-2 p-2 border-start border-info border-3 ps-3">
                        <small class="text-muted">2 minutes ago</small>
                        <div>New user registered: <strong>jane@company.com</strong></div>
                    </div>
                    <div class="activity-item mb-2 p-2 border-start border-success border-3 ps-3">
                        <small class="text-muted">15 minutes ago</small>
                        <div>Task completed by <strong>John Doe</strong></div>
                    </div>
                    <div class="activity-item mb-2 p-2 border-start border-warning border-3 ps-3">
                        <small class="text-muted">1 hour ago</small>
                        <div>System backup completed successfully</div>
                    </div>
                    <div class="activity-item mb-2 p-2 border-start border-primary border-3 ps-3">
                        <small class="text-muted">3 hours ago</small>
                        <div>Admin settings updated</div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <h5 class="mb-3"><i class="fas fa-chart-line me-2"></i>System Health</h5>
                <div class="system-health">
                    <div class="health-item mb-3">
                        <div class="d-flex justify-content-between align-items-center">
                            <span>Database Connection</span>
                            <span class="badge bg-success">Online</span>
                        </div>
                        <div class="progress mt-1" style="height: 4px;">
                            <div class="progress-bar bg-success" style="width: 98%"></div>
                        </div>
                    </div>
                    <div class="health-item mb-3">
                        <div class="d-flex justify-content-between align-items-center">
                            <span>API Response Time</span>
                            <span class="badge bg-success">45ms</span>
                        </div>
                        <div class="progress mt-1" style="height: 4px;">
                            <div class="progress-bar bg-success" style="width: 92%"></div>
                        </div>
                    </div>
                    <div class="health-item mb-3">
                        <div class="d-flex justify-content-between align-items-center">
                            <span>Server Load</span>
                            <span class="badge bg-warning">Medium</span>
                        </div>
                        <div class="progress mt-1" style="height: 4px;">
                            <div class="progress-bar bg-warning" style="width: 65%"></div>
                        </div>
                    </div>
                    <div class="health-item mb-3">
                        <div class="d-flex justify-content-between align-items-center">
                            <span>Storage Usage</span>
                            <span class="badge bg-info">23%</span>
                        </div>
                        <div class="progress mt-1" style="height: 4px;">
                            <div class="progress-bar bg-info" style="width: 23%"></div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `);
}

// Fallback for admin dashboard
function showAdminDashboardFallback() {
    const emptyStats = { total: 0, pending: 0, inProgress: 0, completed: 0, totalUsers: 0, activeUsers: 0, sharedTasks: 0, overdueSystemTasks: 0 };
    updateAdminDashboardStats(emptyStats);
    createAdminStatusChart(emptyStats);
    updateAdminInsights(emptyStats);
    renderAdminRecentActivity();
}

// Render recent tasks in dashboard (Enhanced for Prompt 4)
function renderRecentTasks(recentTasks) {
    const container = $('#recent-tasks-container');
    container.empty();
    
    if (recentTasks.length === 0) {
        container.html(`
            <div class="text-center p-4">
                <i class="fas fa-tasks fa-2x text-muted mb-3"></i>
                <p class="text-muted">No recent tasks found. Create a new task to get started!</p>
                <button class="btn btn-primary btn-sm" onclick="showNewTaskModal()">
                    <i class="fas fa-plus me-1"></i> Create Task
                </button>
            </div>
        `);
        return;
    }
    
    console.log(`Rendering ${recentTasks.length} recent tasks with enhanced display`);
    
    // Add header with task count and status indicators
    container.append(`
        <div class="d-flex justify-content-between align-items-center mb-3">
            <h6 class="text-muted mb-0">
                <i class="fas fa-clock me-1"></i>
                Recent Tasks (${recentTasks.length})
            </h6>
            <small class="text-muted">
                <i class="fas fa-eye me-1"></i> Dashboard View
            </small>
        </div>
    `);
    
    // Render each task with enhanced display
    recentTasks.forEach((task, index) => {
        container.append(createDashboardTaskCard(task, index));
    });
    
    // Add navigation notice with enhanced styling
    container.append(`
        <div class="alert alert-light border mt-3">
            <div class="d-flex align-items-center">
                <i class="fas fa-info-circle text-info me-2"></i>
                <small class="mb-0">
                    This is a dashboard preview. 
                    <a href="#" class="alert-link fw-bold" id="goto-my-tasks">
                        <i class="fas fa-arrow-right me-1"></i>View All Tasks
                    </a>
                </small>
            </div>
        </div>
    `);
    
    // Add event listener for the "View All Tasks" link
    $('#goto-my-tasks').on('click', function(e) {
        e.preventDefault();
        showMyTasksWithFilters();
    });
}

// ===== PIE CHART FUNCTIONALITY =====

// Create task status pie chart
function createTaskStatusChart(taskStats) {
    console.log('Creating task status pie chart with data:', taskStats);
    
    const ctx = document.getElementById('taskStatusChart');
    if (!ctx) {
        console.error('Chart canvas not found');
        return;
    }
    
    // Destroy existing chart if it exists
    if (taskStatusChart) {
        taskStatusChart.destroy();
    }
    
    // Prepare chart data
    const chartData = {
        labels: ['Pending', 'In Progress', 'Completed'],
        datasets: [{
            data: [taskStats.pending, taskStats.inProgress, taskStats.completed],
            backgroundColor: [
                '#ffc107', // Pending - Warning yellow
                '#0d6efd', // In Progress - Primary blue  
                '#198754'  // Completed - Success green
            ],
            borderColor: [
                '#ffb000',
                '#0b5ed7',
                '#157347'
            ],
            borderWidth: 2,
            hoverOffset: 10
        }]
    };
    
    // Chart configuration
    const config = {
        type: 'pie',
        data: chartData,
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    position: 'bottom',
                    labels: {
                        padding: 20,
                        usePointStyle: true,
                        font: {
                            size: 12
                        }
                    }
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            const total = context.dataset.data.reduce((a, b) => a + b, 0);
                            const percentage = total > 0 ? Math.round((context.parsed / total) * 100) : 0;
                            return `${context.label}: ${context.parsed} (${percentage}%)`;
                        }
                    }
                }
            },
            animation: {
                animateRotate: true,
                animateScale: true,
                duration: 1000
            }
        }
    };
    
    // Create the chart
    taskStatusChart = new Chart(ctx, config);
    console.log('Task status pie chart created successfully');
    
    // Update insights panel
    updateTaskInsights(taskStats);
}

// Update task insights panel
function updateTaskInsights(taskStats) {
    const total = taskStats.total;
    const insightsContainer = $('#task-insights');
    
    if (total === 0) {
        insightsContainer.html(`
            <div class="d-flex justify-content-center align-items-center" style="height: 300px;">
                <div class="text-center">
                    <i class="fas fa-tasks fa-3x text-muted mb-3"></i>
                    <h5 class="text-muted">No Tasks Yet</h5>
                    <p class="text-muted">Create your first task to see insights here.</p>
                    <button class="btn btn-primary btn-sm" onclick="$('#new-task-btn').click()">
                        <i class="fas fa-plus me-1"></i>Create Task
                    </button>
                </div>
            </div>
        `);
        return;
    }
    
    // Calculate percentages
    const pendingPercent = Math.round((taskStats.pending / total) * 100);
    const inProgressPercent = Math.round((taskStats.inProgress / total) * 100);
    const completedPercent = Math.round((taskStats.completed / total) * 100);
    
    // Determine productivity insights
    let productivityMessage = '';
    let productivityIcon = '';
    let productivityClass = '';
    
    if (completedPercent >= 60) {
        productivityMessage = 'Excellent productivity! Keep up the great work.';
        productivityIcon = 'fa-trophy';
        productivityClass = 'text-success';
    } else if (completedPercent >= 40) {
        productivityMessage = 'Good progress! You\'re on the right track.';
        productivityIcon = 'fa-thumbs-up';
        productivityClass = 'text-info';
    } else if (inProgressPercent > pendingPercent) {
        productivityMessage = 'Making progress! Focus on completing active tasks.';
        productivityIcon = 'fa-rocket';
        productivityClass = 'text-warning';
    } else {
        productivityMessage = 'Time to get started! Begin tackling your pending tasks.';
        productivityIcon = 'fa-play-circle';
        productivityClass = 'text-primary';
    }
    
    // Determine most urgent status
    let urgentStatus = '';
    if (taskStats.pending > 0) {
        urgentStatus = `<div class="alert alert-warning border-warning py-2 mb-2">
            <small><i class="fas fa-exclamation-triangle me-1"></i>
            ${taskStats.pending} task${taskStats.pending > 1 ? 's' : ''} pending - time to start!
            </small>
        </div>`;
    } else if (taskStats.inProgress > 0) {
        urgentStatus = `<div class="alert alert-info border-info py-2 mb-2">
            <small><i class="fas fa-clock me-1"></i>
            ${taskStats.inProgress} task${taskStats.inProgress > 1 ? 's' : ''} in progress - keep going!
            </small>
        </div>`;
    }
    
    insightsContainer.html(`
        <div class="insights-content" style="height: 300px; display: flex; flex-direction: column; justify-content: space-between;">
            <!-- Productivity Status -->
            <div class="text-center mb-3">
                <i class="fas ${productivityIcon} fa-2x ${productivityClass} mb-2"></i>
                <p class="mb-0 fw-medium ${productivityClass}">${productivityMessage}</p>
            </div>
            
            ${urgentStatus}
            
            <!-- Status Breakdown -->
            <div class="row text-center mb-3">
                <div class="col-4">
                    <div class="p-2 border rounded bg-light">
                        <div class="fw-bold text-warning">${pendingPercent}%</div>
                        <small class="text-muted">Pending</small>
                    </div>
                </div>
                <div class="col-4">
                    <div class="p-2 border rounded bg-light">
                        <div class="fw-bold text-primary">${inProgressPercent}%</div>
                        <small class="text-muted">Active</small>
                    </div>
                </div>
                <div class="col-4">
                    <div class="p-2 border rounded bg-light">
                        <div class="fw-bold text-success">${completedPercent}%</div>
                        <small class="text-muted">Done</small>
                    </div>
                </div>
            </div>
            
            <!-- Quick Actions -->
            <div class="d-grid gap-2 mt-auto">
                ${taskStats.pending > 0 ? `
                <button class="btn btn-outline-primary btn-sm" onclick="showMyTasksWithFilters(); applyStatusFilter('pending')">
                    <i class="fas fa-play me-1"></i>Start Pending Tasks
                </button>` : ''}
                ${taskStats.inProgress > 0 ? `
                <button class="btn btn-outline-info btn-sm" onclick="showMyTasksWithFilters(); applyStatusFilter('in-progress')">
                    <i class="fas fa-tasks me-1"></i>Continue Active Tasks
                </button>` : ''}
                <button class="btn btn-outline-success btn-sm" onclick="$('#new-task-btn').click()">
                    <i class="fas fa-plus me-1"></i>Add New Task
                </button>
            </div>
        </div>
    `);
}

// Update chart with new data
function updateTaskStatusChart(taskStats) {
    if (!taskStatusChart) {
        createTaskStatusChart(taskStats);
        return;
    }
    
    // Update chart data
    taskStatusChart.data.datasets[0].data = [
        taskStats.pending, 
        taskStats.inProgress, 
        taskStats.completed
    ];
    
    // Animate the update
    taskStatusChart.update('show');
    
    // Update insights
    updateTaskInsights(taskStats);
    
    console.log('Chart updated with new task statistics');
}

// Helper function to apply status filter (to be implemented in task-filters.js)
function applyStatusFilter(status) {
    console.log(`Applying status filter: ${status}`);
    // This will trigger the filter in the task list
    setTimeout(() => {
        $(`input[name="status"][value="${status}"]`).prop('checked', true).trigger('change');
    }, 100);
}

// Show My Tasks page
function showMyTasks() {
    if (!currentUser) return;
    
    // Update active navigation
    $('.nav-link, .list-group-item').removeClass('active');
    $('#my-tasks-link, #sidebar-my-tasks').addClass('active');
    
    // Use central container management
    showContainer('task-list-container');
    
    // Update heading
    $('#task-list-container h1').text('My Tasks');
    
    // Fetch and display tasks
    fetchTasks().then(() => {
        // FIXED: Filter to show only tasks created by the current user
        const myTasks = tasks.filter(task => task.userId === currentUser.id);
        console.log(`Showing ${myTasks.length} tasks created by user ${currentUser.id}`);
        renderTasks(myTasks);
    }).catch(error => {
        console.log('Tasks loading failed, showing empty state');
        renderTasks([]);
    });
}

// Show Shared Tasks page (Enhanced for Prompt 6)
function showSharedTasks() {
    console.log('Displaying enhanced shared tasks view (Prompt 6)');
    
    if (!currentUser) return;
    
    // Update active navigation
    $('.nav-link, .list-group-item').removeClass('active');
    $('#shared-tasks-link, #sidebar-shared-tasks').addClass('active');
    
    // Use central container management
    showContainer('task-list-container');
    
    // Update heading with enhanced information
    $('#task-list-container h1').html(`
        <i class="fas fa-users me-2"></i>Shared Tasks
        <small class="text-muted ms-2">Tasks you've shared or that have been shared with you</small>
    `);
    
    // Fetch and display tasks
    fetchTasks().then(() => {
        // FIXED: Proper filtering logic for shared tasks
        
        // Tasks I've shared with others (my tasks that I've shared)
        const mySharedTasks = tasks.filter(task => {
            return task.userId === currentUser.id && // Created by me
                   task.shared === true && // Is shared
                   task.sharedWith && // Has sharedWith array
                   task.sharedWith.length > 0; // Has at least one person shared with
        });
        
        // Tasks that others have shared with me (not created by me, but I'm in sharedWith)
        const receivedSharedTasks = tasks.filter(task => {
            return task.userId !== currentUser.id && // NOT created by me
                   task.shared === true && // Is shared
                   task.sharedWith && // Has sharedWith array
                   task.sharedWith.includes(currentUser.email); // I'm in the shared list
        });
        
        console.log(`CORRECTED FILTERING:`);
        console.log(`- My tasks shared with others: ${mySharedTasks.length}`);
        console.log(`- Tasks shared with me: ${receivedSharedTasks.length}`);
        console.log(`- Current user: ${currentUser.email} (ID: ${currentUser.id})`);
        
        // Log details for debugging
        mySharedTasks.forEach(task => {
            console.log(`  My shared task: "${task.title}" shared with [${task.sharedWith.join(', ')}]`);
        });
        
        receivedSharedTasks.forEach(task => {
            console.log(`  Task shared with me: "${task.title}" by ${task.sharedBy || 'unknown'}`);
        });
        
        if (mySharedTasks.length === 0 && receivedSharedTasks.length === 0) {
            renderEmptySharedTasksState();
        } else {
            renderSharedTasksWithCategories(mySharedTasks, receivedSharedTasks);
        }
    }).catch(error => {
        console.log('Shared tasks loading failed, showing empty state');
        renderEmptySharedTasksState();
    });
}

// Fetch tasks from API
function fetchTasks() {
    const apiUrl = getApiUrl(API_CONFIG.ENDPOINTS.TASKS);
    
    // Only try authenticated request if we have a valid token
    if (isAuthenticated()) {
        console.log('Attempting authenticated API request for tasks');
        return makeAuthenticatedRequest(apiUrl, {
            method: 'GET'
        })
        .then(response => {
            console.log('Tasks loaded from API successfully');
            tasks = response;
            return tasks;
        })
        .catch(error => {
            console.log('Authenticated API request failed, falling back to offline mode:', error.message);
            return loadOfflineTasks();
        });
    } else {
        console.log('No authentication available, using offline mode for tasks');
        return Promise.resolve(loadOfflineTasks());
    }
}

// Save tasks to user-specific localStorage
function saveTasksToStorage() {
    if (!currentUser || !currentUser.id) {
        console.log('No current user, cannot save tasks');
        return;
    }
    
    const userTasksKey = `tasks_user_${currentUser.id}`;
    localStorage.setItem(userTasksKey, JSON.stringify(tasks));
    console.log(`Saved ${tasks.length} tasks for user ${currentUser.id}`);
}

// Load tasks from localStorage or generate sample data (USER-SPECIFIC)
function loadOfflineTasks() {
    if (!currentUser || !currentUser.id) {
        console.log('No current user, returning empty tasks array');
        return [];
    }
    
    const userTasksKey = `tasks_user_${currentUser.id}`;
    const storedTasks = localStorage.getItem(userTasksKey);
    
    if (storedTasks) {
        try {
            tasks = JSON.parse(storedTasks);
            console.log(`Loaded ${tasks.length} tasks for user ${currentUser.id} from localStorage`);
        } catch (e) {
            console.log('Error parsing stored tasks, starting with empty array');
            tasks = [];
            localStorage.setItem(userTasksKey, JSON.stringify(tasks));
        }
    } else {
        console.log(`No stored tasks found for user ${currentUser.id}, starting with empty array`);
        tasks = [];
        localStorage.setItem(userTasksKey, JSON.stringify(tasks));
    }
    return tasks;
}

// Generate sample tasks
function getSampleTasks() {
    const now = new Date();
    const tomorrow = new Date(now);
    tomorrow.setDate(now.getDate() + 1);
    const nextWeek = new Date(now);
    nextWeek.setDate(now.getDate() + 7);
    const lastWeek = new Date(now);
    lastWeek.setDate(now.getDate() - 7);
    
    return [
        {
            id: '1',
            title: 'Complete Project Proposal',
            description: 'Write and submit the project proposal for the new client',
            status: 'in-progress',
            dueDate: tomorrow.toISOString().split('T')[0],
            userId: currentUser.id,
            priority: 'high',
            shared: true,
            sharedWith: ['alice@company.com', 'bob@company.com'],
            sharedPermissions: {
                'alice@company.com': 'edit',
                'bob@company.com': 'view'
            },
            tagIds: [1, 4],
            createdAt: now.toISOString()
        },
        {
            id: '2',
            title: 'Review Pull Requests',
            description: 'Review and merge pending pull requests from the team',
            status: 'pending',
            dueDate: nextWeek.toISOString().split('T')[0],
            userId: currentUser.id,
            priority: 'medium',
            shared: true,
            sharedWith: ['charlie@company.com'],
            sharedPermissions: {
                'charlie@company.com': 'manage'
            },
            tagIds: [1],
            createdAt: now.toISOString()
        },
        {
            id: '3',
            title: 'Update Documentation',
            description: 'Update the API documentation with new endpoints',
            status: 'completed',
            dueDate: now.toISOString().split('T')[0],
            userId: currentUser.id,
            priority: 'low',
            shared: false,
            tagIds: [1, 4],
            createdAt: now.toISOString()
        },
        {
            id: '4',
            title: 'Team Meeting Preparation',
            description: 'Prepare agenda and materials for the weekly team meeting',
            status: 'pending',
            dueDate: tomorrow.toISOString().split('T')[0],
            userId: 'user_2',
            priority: 'medium',
            shared: true,
            sharedBy: 'manager@company.com',
            sharedWith: [currentUser.email],
            sharedPermissions: {
                [currentUser.email]: 'edit'
            },
            tagIds: [2],
            createdAt: lastWeek.toISOString()
        },
        {
            id: '5',
            title: 'Client Presentation Review',
            description: 'Review and provide feedback on the client presentation slides',
            status: 'in-progress',
            dueDate: nextWeek.toISOString().split('T')[0],
            userId: 'user_3',
            priority: 'high',
            shared: true,
            sharedBy: 'alice@company.com',
            sharedWith: [currentUser.email, 'bob@company.com'],
            sharedPermissions: {
                [currentUser.email]: 'edit',
                'bob@company.com': 'view'
            },
            tagIds: [2, 3],
            createdAt: lastWeek.toISOString()
        }
    ];
}

// Helper function to reset tasks for testing (can be called from console)
function resetTasksForTesting() {
    console.log('Resetting tasks with new sharing structure...');
    localStorage.removeItem('tasks');
    tasks = getSampleTasks();
    saveTasksToStorage();
    console.log('Tasks reset complete. Refresh your view to see changes.');
    
    // Refresh current view
    if ($('#task-list-container').is(':visible')) {
        if ($('#shared-tasks-link').hasClass('active')) {
            showSharedTasks();
        } else {
            showMyTasks();
        }
    } else if ($('#dashboard-container').is(':visible')) {
        loadDashboardData();
    }
}

// Test function to debug share functionality (can be called from console)
function testShareModal(taskId = '1') {
    console.log('Testing share modal for task:', taskId);
    
    if (typeof openShareTaskModal === 'function') {
        console.log('openShareTaskModal function exists');
        try {
            openShareTaskModal(taskId);
            console.log('Share modal should have opened');
        } catch (error) {
            console.error('Error in openShareTaskModal:', error);
        }
    } else {
        console.error('openShareTaskModal function not found');
    }
}

// Test function for pie chart (can be called from console)
function testPieChart() {
    console.log('Testing pie chart with sample data...');
    
    const testStats = {
        total: 10,
        pending: 3,
        inProgress: 4,
        completed: 3
    };
    
    createTaskStatusChart(testStats);
    console.log('Test pie chart created with data:', testStats);
}

// Function to update chart when tasks change (can be called from other functions)
function refreshChartIfVisible() {
    if ($('#dashboard-container').is(':visible') && $('#taskStatusChart').length > 0) {
        const taskStats = analyzeTaskStats(tasks);
        updateTaskStatusChart(taskStats);
        console.log('Chart refreshed with current task data');
    }
}

// Render tasks in the task list (Enhanced for Prompt 4)
function renderTasks(taskList) {
    const container = $('#task-list');
    container.empty();
    
    if (taskList.length === 0) {
        container.html(`
            <div class="text-center p-5">
                <i class="fas fa-tasks fa-3x text-muted mb-3"></i>
                <p class="text-muted">No tasks found. Create a new task to get started!</p>
                <button class="btn btn-primary" id="create-first-task">
                    <i class="fas fa-plus me-1"></i> Create Your First Task
                </button>
            </div>
        `);
        
        // Add event listener for the create task button
        container.find('#create-first-task').on('click', function() {
            showNewTaskModal();
        });
        return;
    }
    
    console.log(`Rendering ${taskList.length} tasks with enhanced display`);
    
    // Group tasks by status for better organization
    const groupedTasks = {
        pending: [],
        'in-progress': [],
        completed: []
    };
    
    taskList.forEach(task => {
        if (groupedTasks[task.status]) {
            groupedTasks[task.status].push(task);
        } else {
            groupedTasks.pending.push(task); // Default to pending if unknown status
        }
    });
    
    // Render tasks in organized sections
    Object.keys(groupedTasks).forEach(status => {
        if (groupedTasks[status].length > 0) {
            const statusIcon = getStatusIcon(status);
            const statusTitle = getStatusTitle(status);
            const statusColor = getStatusColor(status);
            
            container.append(`
                <div class="task-status-section mb-4">
                    <h6 class="task-status-header ${statusColor}">
                        <i class="${statusIcon} me-2"></i>
                        ${statusTitle} (${groupedTasks[status].length})
                    </h6>
                    <div class="task-status-group" data-status="${status}"></div>
                </div>
            `);
            
            const statusContainer = container.find(`.task-status-group[data-status="${status}"]`);
            groupedTasks[status].forEach(task => {
                statusContainer.append(createTaskCard(task));
            });
        }
    });
}

// Helper functions for status display (Prompt 4 enhancements)
function getStatusIcon(status) {
    const statusIcons = {
        'pending': 'fas fa-clock',
        'in-progress': 'fas fa-spinner',
        'completed': 'fas fa-check-circle'
    };
    return statusIcons[status] || 'fas fa-question-circle';
}

function getStatusTitle(status) {
    const statusTitles = {
        'pending': 'Pending Tasks',
        'in-progress': 'In Progress',
        'completed': 'Completed Tasks'
    };
    return statusTitles[status] || 'Unknown Status';
}

function getStatusColor(status) {
    const statusColors = {
        'pending': 'text-warning',
        'in-progress': 'text-primary', 
        'completed': 'text-success'
    };
    return statusColors[status] || 'text-secondary';
}

function getPriorityInfo(priority) {
    const priorityMap = {
        'high': {
            text: 'High Priority',
            class: 'bg-danger',
            icon: 'fas fa-exclamation-circle'
        },
        'medium': {
            text: 'Medium Priority', 
            class: 'bg-warning',
            icon: 'fas fa-minus-circle'
        },
        'low': {
            text: 'Low Priority',
            class: 'bg-secondary',
            icon: 'fas fa-circle'
        }
    };
    return priorityMap[priority] || priorityMap['medium'];
}

// Enhanced helper functions for Prompt 5
function showLoadingState(message = 'Loading...') {
    // Show loading overlay or toast
    showToast('info', 'Processing', message);
    
    // Disable form buttons to prevent double submission
    $('button[type="submit"], .btn-primary').prop('disabled', true).addClass('loading');
}

function hideLoadingState() {
    // Hide loading indicators and re-enable buttons
    $('button[type="submit"], .btn-primary').prop('disabled', false).removeClass('loading');
}

// Refresh task list without page reload (Prompt 5 requirement)
function refreshTaskListWithoutReload() {
    console.log('Refreshing task list without page reload using jQuery...');
    
    // Determine current view and refresh accordingly
    if ($('#task-list-container').is(':visible')) {
        // Currently viewing My Tasks or Task List
        console.log('Refreshing My Tasks view');
        
        // Re-fetch tasks and update display
        fetchTasks().then(() => {
            // Check which specific view is active
            if ($('#my-tasks-link').hasClass('active') || $('#sidebar-my-tasks').hasClass('active')) {
                showMyTasksWithFilters();
            } else if ($('#shared-tasks-link').hasClass('active') || $('#sidebar-shared-tasks').hasClass('active')) {
                showSharedTasksWithFilters();
            } else {
                // Default to My Tasks
                showMyTasksWithFilters();
            }
        }).catch(error => {
            console.error('Failed to refresh task list:', error);
            showToast('error', 'Refresh Failed', 'Failed to refresh task list');
        });
        
    } else if ($('#dashboard-container').is(':visible')) {
        // Currently viewing Dashboard
        console.log('Refreshing Dashboard view');
        loadDashboardData();
        
    } else {
        // Unknown view, try to refresh the most likely container
        console.log('Refreshing default task view');
        if ($('#task-list').length > 0) {
            fetchTasks().then(() => {
                renderTasks(tasks);
            });
        }
    }
}

// Enhanced dashboard helper functions (Prompt 4)
function analyzeTaskStats(taskList) {
    const stats = {
        total: taskList.length,
        pending: taskList.filter(task => task.status === 'pending').length,
        inProgress: taskList.filter(task => task.status === 'in-progress').length,
        completed: taskList.filter(task => task.status === 'completed').length,
        overdue: taskList.filter(task => {
            const dueDate = new Date(task.dueDate);
            return dueDate < new Date() && task.status !== 'completed';
        }).length,
        shared: taskList.filter(task => task.shared).length,
        highPriority: taskList.filter(task => task.priority === 'high').length
    };
    
    stats.completionRate = stats.total > 0 ? Math.round((stats.completed / stats.total) * 100) : 0;
    
    return stats;
}

function updateDashboardStats(stats) {
    // Update existing counters
    $('#total-tasks-count').text(stats.total);
    $('#in-progress-count').text(stats.inProgress);
    $('#completed-count').text(stats.completed);
    
    // Update additional stats if elements exist
    $('#pending-count').text(stats.pending);
    $('#overdue-count').text(stats.overdue);
    $('#shared-count').text(stats.shared);
    $('#completion-rate').text(stats.completionRate + '%');
}

function renderDashboardStatusSummary(stats) {
    const summaryContainer = $('#dashboard-status-summary');
    if (summaryContainer.length === 0) return;
    
    const statusItems = [
        {
            icon: 'fas fa-clock',
            color: 'text-warning',
            count: stats.pending,
            label: 'Pending',
            bgClass: 'bg-warning'
        },
        {
            icon: 'fas fa-spinner',
            color: 'text-primary', 
            count: stats.inProgress,
            label: 'In Progress',
            bgClass: 'bg-primary'
        },
        {
            icon: 'fas fa-check-circle',
            color: 'text-success',
            count: stats.completed,
            label: 'Completed',
            bgClass: 'bg-success'
        },
        {
            icon: 'fas fa-exclamation-triangle',
            color: 'text-danger',
            count: stats.overdue,
            label: 'Overdue',
            bgClass: 'bg-danger'
        }
    ];
    
    const summaryHTML = statusItems.map(item => `
        <div class="col-md-3 mb-3">
            <div class="card border-0 ${item.bgClass} bg-opacity-10">
                <div class="card-body text-center">
                    <i class="${item.icon} fa-2x ${item.color} mb-2"></i>
                    <h4 class="card-title ${item.color}">${item.count}</h4>
                    <p class="card-text text-muted">${item.label}</p>
                </div>
            </div>
        </div>
    `).join('');
    
    summaryContainer.html(`<div class="row">${summaryHTML}</div>`);
}

// Create dashboard task card (Prompt 4 - compact view for dashboard)
function createDashboardTaskCard(task, index) {
    const statusIcon = getStatusIcon(task.status);
    const statusColor = getStatusColor(task.status);
    const priorityInfo = getPriorityInfo(task.priority);
    
    // Format date
    const dueDate = new Date(task.dueDate);
    const isOverdue = dueDate < new Date() && task.status !== 'completed';
    const dueDateClass = isOverdue ? 'text-danger' : 'text-muted';
    const formattedDate = dueDate.toLocaleDateString();
    
    return $(`
        <div class="card mb-2 border-start border-3 border-${task.status === 'completed' ? 'success' : task.status === 'in-progress' ? 'primary' : 'warning'}" data-task-id="${task.id}">
            <div class="card-body py-2 px-3">
                <div class="d-flex justify-content-between align-items-center">
                    <div class="flex-grow-1">
                        <div class="d-flex align-items-center mb-2">
                            <i class="${statusIcon} ${statusColor}"></i>
                            <span class="fw-medium ${task.status === 'completed' ? 'text-decoration-line-through text-muted' : ''}">${task.title}</span>
                            ${task.shared ? '<i class="fas fa-users text-info ms-1" title="Shared"></i>' : ''}
                        </div>
                        <div class="d-flex align-items-center gap-2 mt-1">
                            <span class="badge ${priorityInfo.class} badge-sm">${priorityInfo.text}</span>
                            <small class="${dueDateClass}">
                                <i class="fas fa-calendar me-1"></i>${formattedDate}
                                ${isOverdue ? ' (Overdue)' : ''}
                            </small>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    `);
}

// Create a task card (Enhanced for Prompt 4)
function createTaskCard(task) {
    // Enhanced status display with icons and colors
    const statusIcon = getStatusIcon(task.status);
    const statusColor = getStatusColor(task.status);
    const statusText = task.status === 'in-progress' ? 'In Progress' : 
                      task.status.charAt(0).toUpperCase() + task.status.slice(1);
    
    // Enhanced priority display with colors
    const priorityInfo = getPriorityInfo(task.priority);
    
    // Format date with better styling
    const dueDate = new Date(task.dueDate);
    const formattedDate = dueDate.toLocaleDateString();
    const isOverdue = dueDate < new Date() && task.status !== 'completed';
    const dueDateClass = isOverdue ? 'text-danger fw-bold' : 'text-muted';
    const dueDateIcon = isOverdue ? 'fas fa-exclamation-triangle' : 'fas fa-calendar';
    
    // Enhanced shared status with detailed information (Prompt 6)
    let sharedBadge = '';
    if (task.shared && task.sharedWith && task.sharedWith.length > 0) {
        const sharedCount = task.sharedWith.length;
        const sharedUsers = task.sharedWith.slice(0, 2).join(', ');
        const moreUsers = sharedCount > 2 ? ` and ${sharedCount - 2} more` : '';
        
        sharedBadge = `
            <span class="badge bg-info ms-2" 
                  title="Shared with: ${task.sharedWith.join(', ')}" 
                  data-bs-toggle="tooltip" 
                  data-bs-placement="top">
                <i class="fas fa-users me-1"></i> 
                Shared (${sharedCount})
            </span>`;
    } else if (task.shared) {
        sharedBadge = `
            <span class="badge bg-info ms-2" title="This task is shared">
                <i class="fas fa-users me-1"></i> Shared
            </span>`;
    }
    
    // Completion status indicator
    const completionIndicator = task.status === 'completed' ? 
        `<div class="completion-overlay">
            <i class="fas fa-check-circle text-success fa-2x"></i>
        </div>` : '';
    
    // Create enhanced HTML with better icons and styling
    const card = $(`
        <div class="card mb-3 task-card priority-${task.priority} status-${task.status}" data-task-id="${task.id}">
            ${completionIndicator}
            <div class="card-body position-relative">
                <div class="d-flex justify-content-between align-items-start mb-3">
                    <div class="flex-grow-1">
                        <div class="d-flex align-items-center mb-2">
                            <i class="${statusIcon} me-2 ${statusColor}"></i>
                            <h5 class="card-title mb-0 ${task.status === 'completed' ? 'text-decoration-line-through text-muted' : ''}">${task.title}</h5>
                            ${sharedBadge}
                        </div>
                        <div class="d-flex align-items-center gap-2">
                            <span class="badge ${priorityInfo.class}">
                                <i class="${priorityInfo.icon} me-1"></i>${priorityInfo.text}
                            </span>
                            <span class="badge bg-light text-dark">
                                <i class="${statusIcon} me-1"></i>${statusText}
                            </span>
                        </div>
                    </div>
                </div>
                <p class="card-text">${task.description || 'No description provided.'}</p>
                <div class="task-tags mb-3">
                    ${renderTagBadges(task.tagIds)}
                </div>
                
                <!-- Enhanced Task Comments Section (Prompt 7) -->
                <div class="task-comments mb-3 d-none">
                    <div class="comments-header d-flex justify-content-between align-items-center mb-2">
                        <h6 class="mb-0">
                            <i class="fas fa-comments me-1 text-primary"></i> 
                            Comments
                            <span class="comment-count badge bg-secondary ms-1" style="display: none;">0</span>
                        </h6>
                        ${task.shared ? `
                        <small class="text-info">
                            <i class="fas fa-users me-1"></i>Shared task comments
                        </small>` : ''}
                    </div>
                    
                    <div class="comments-container">
                        <div class="comments-list max-height-200 overflow-auto border rounded p-2 mb-2 bg-light">
                            <!-- Comments will be loaded here -->
                        </div>
                        
                        <div class="add-comment-form">
                            <div class="input-group">
                                <span class="input-group-text">
                                    <i class="fas fa-user text-primary"></i>
                                </span>
                                <input type="text" 
                                       class="form-control comment-input" 
                                       placeholder="${task.shared ? 'Add a comment to this shared task...' : 'Add a comment...'}"
                                       maxlength="500">
                                <button class="btn btn-primary add-comment-btn" type="button">
                                    <i class="fas fa-paper-plane me-1"></i>Post
                                </button>
                            </div>
                            <div class="form-text mt-1">
                                <small class="text-muted">
                                    <i class="fas fa-info-circle me-1"></i>
                                    ${task.shared ? 'Comments are visible to all users this task is shared with.' : 'Add your thoughts or updates about this task.'}
                                </small>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <small class="${dueDateClass}">
                        <i class="${dueDateIcon} me-1"></i>
                        Due: ${formattedDate}
                        ${isOverdue ? ' (Overdue)' : ''}
                    </small>
                    <div class="btn-group">
                        <button class="btn btn-sm btn-outline-secondary comment-btn me-1" title="Comments">
                            <i class="fas fa-comment"></i>
                        </button>
                        <button class="btn btn-sm btn-outline-info share-task-btn me-1" title="Share Task" data-task-id="${task.id}">
                            <i class="fas fa-share-alt"></i>
                        </button>
                        <div class="dropdown d-inline-block me-1">
                            <button class="btn btn-sm btn-outline-secondary dropdown-toggle" type="button" data-bs-toggle="dropdown">
                                Status
                            </button>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item status-change" href="#" data-status="pending">Pending</a></li>
                                <li><a class="dropdown-item status-change" href="#" data-status="in-progress">In Progress</a></li>
                                <li><a class="dropdown-item status-change" href="#" data-status="completed">Completed</a></li>
                            </ul>
                        </div>
                        <button class="btn btn-sm btn-outline-primary edit-task me-1">Edit</button>
                        <button class="btn btn-sm btn-outline-danger delete-task">Delete</button>
                    </div>
                </div>
            </div>
        </div>
    `);
    
    // Enhanced comment button handler (Prompt 7)
    card.find('.comment-btn').on('click', function() {
        console.log(`Comment button clicked for task ${task.id} (Prompt 7)`);
        toggleCommentSection(card, task.id);
        
        // Show helpful message for shared tasks
        if (task.shared) {
            setTimeout(() => {
                showToast('info', 'Shared Task Comments', 'Comments on this shared task are visible to all collaborators.');
            }, 500);
        }
    });
    
    // Enhanced add comment button handler (Prompt 7)
    card.find('.add-comment-btn').on('click', function() {
        const commentText = card.find('.comment-input').val().trim();
        
        console.log(`Add comment button clicked for task ${task.id} (Prompt 7)`);
        
        if (!commentText) {
            // Enhanced validation with visual feedback
            const input = card.find('.comment-input');
            input.addClass('is-invalid');
            setTimeout(() => input.removeClass('is-invalid'), 2000);
            
            showToast('warning', 'Comment Required', 'Please enter a comment before posting.');
            return;
        }
        
        if (commentText.length > 500) {
            showToast('error', 'Comment Too Long', 'Comments must be 500 characters or less.');
            return;
        }
        
        addComment(task.id, commentText, card);
    });
    
    // Enhanced comment input handler with better UX (Prompt 7)
    card.find('.comment-input').on('keypress', function(e) {
        if (e.which === 13 && !e.shiftKey) { // Enter key (Shift+Enter for new line)
            e.preventDefault();
            const commentText = $(this).val().trim();
            
            if (!commentText) {
                showToast('warning', 'Comment Required', 'Please enter a comment before posting.');
                return;
            }
            
            if (commentText.length > 500) {
                showToast('error', 'Comment Too Long', 'Comments must be 500 characters or less.');
                return;
            }
            
            addComment(task.id, commentText, card);
        }
    });
    
    // Add character counter for comment input (Prompt 7 enhancement)
    card.find('.comment-input').on('input', function() {
        const input = $(this);
        const text = input.val();
        const length = text.length;
        const maxLength = 500;
        
        // Update placeholder with character count
        if (length > 0) {
            const remaining = maxLength - length;
            const formText = card.find('.form-text small');
            
            if (remaining < 50) {
                formText.removeClass('text-muted').addClass('text-warning');
                formText.html(`<i class="fas fa-exclamation-triangle me-1"></i>${remaining} characters remaining`);
            } else {
                formText.removeClass('text-warning').addClass('text-muted');
                formText.html(`<i class="fas fa-info-circle me-1"></i>${task.shared ? 'Comments are visible to all users this task is shared with.' : 'Add your thoughts or updates about this task.'}`);
            }
            
            if (remaining < 0) {
                input.addClass('is-invalid');
                formText.removeClass('text-warning').addClass('text-danger');
                formText.html(`<i class="fas fa-times-circle me-1"></i>Comment too long by ${Math.abs(remaining)} characters`);
            } else {
                input.removeClass('is-invalid');
            }
        }
    });
    
    return card;
}

// Create a read-only task card for dashboard
function createReadOnlyTaskCard(task) {
    // Get status class and text
    const statusClass = `status-${task.status}`;
    const statusText = task.status === 'in-progress' ? 'In Progress' : 
                      task.status.charAt(0).toUpperCase() + task.status.slice(1);
    
    // Format date
    const dueDate = new Date(task.dueDate).toLocaleDateString();
    
    // Create HTML
    return $(`
        <div class="card mb-3 task-card priority-${task.priority}">
            <div class="card-body">
                <div class="d-flex justify-content-between align-items-start mb-3">
                    <h5 class="card-title">${task.title}</h5>
                    <span class="badge ${statusClass}">${statusText}</span>
                </div>
                <p class="card-text">${task.description || 'No description provided.'}</p>
                <div class="task-tags mb-3">
                    ${renderTagBadges(task.tagIds)}
                </div>
                <div class="d-flex justify-content-between align-items-center mt-3">
                    <small class="text-muted">Due: ${dueDate}</small>
                </div>
            </div>
        </div>
    `);
}

// Render tag badges
function renderTagBadges(tagIds) {
    if (!tagIds || tagIds.length === 0) return '';
    
    return tagIds.map(tagId => {
        const tag = tags.find(t => t.id === tagId);
        if (!tag) return '';
        
        return `<span class="badge rounded-pill me-1" style="background-color: ${tag.color}">${tag.name}</span>`;
    }).join('');
}

// Show new task modal
function showNewTaskModal() {
    // Clear form
    $('#create-task-form')[0].reset();
    $('#task-id').val('');
    
    // Set default date
    const today = new Date();
    const formattedDate = today.toISOString().split('T')[0]; // YYYY-MM-DD format
    $('#task-due-date').val(formattedDate);
    
    // Initialize tags
    initializeTaskTags();
    
    // Update modal title
    $('#task-modal-title').text('Create New Task');
    
    // Show modal
    const taskModal = new bootstrap.Modal(document.getElementById('task-modal'));
    taskModal.show();
}

// Initialize task tags interface
function initializeTaskTags(selectedTagIds = []) {
    const tagsContainer = $('#task-tags-container');
    tagsContainer.empty();
    
    tags.forEach(tag => {
        const isSelected = selectedTagIds.includes(tag.id);
        const tagButton = $(`
            <button type="button" class="btn btn-sm tag-btn ${isSelected ? 'selected' : ''}" 
                    data-tag-id="${tag.id}" 
                    style="background-color: ${isSelected ? tag.color : 'transparent'}; 
                           color: ${isSelected ? 'white' : tag.color}; 
                           border: 1px solid ${tag.color};">
                ${tag.name}
            </button>
        `);
        
        // Add click handler
        tagButton.on('click', function() {
            const btn = $(this);
            const tagId = parseInt(btn.data('tag-id'));
            const tag = tags.find(t => t.id === tagId);
            
            if (btn.hasClass('selected')) {
                // Deselect
                btn.removeClass('selected');
                btn.css({
                    'background-color': 'transparent',
                    'color': tag.color
                });
            } else {
                // Select
                btn.addClass('selected');
                btn.css({
                    'background-color': tag.color,
                    'color': 'white'
                });
            }
        });
        
        tagsContainer.append(tagButton);
    });
}

// Open edit task modal
function openEditTaskModal(taskId) {
    // Find task
    const task = tasks.find(t => t.id === taskId);
    
    if (!task) {
        showToast('error', 'Error', 'Task not found');
        return;
    }
    
    // Set form values in the edit task modal
    $('#edit-task-id').val(task.id);
    $('#edit-task-title').val(task.title);
    $('#edit-task-description').val(task.description || '');
    $('#edit-task-due-date').val(task.dueDate);
    $('#edit-task-priority').val(task.priority);
    $('#edit-task-status').val(task.status);
    
    // Initialize tags with current task's tags
    initializeEditTaskTags(task.tagIds || []);
    
    // Show edit modal
    const editModal = new bootstrap.Modal(document.getElementById('edit-task-modal'));
    editModal.show();
}

// Initialize edit task tags interface
function initializeEditTaskTags(selectedTagIds = []) {
    const tagsContainer = $('#edit-task-tags-container');
    tagsContainer.empty();
    
    tags.forEach(tag => {
        const isSelected = selectedTagIds.includes(tag.id);
        const tagButton = $(`
            <button type="button" class="btn btn-sm tag-btn ${isSelected ? 'selected' : ''}" 
                    data-tag-id="${tag.id}" 
                    style="background-color: ${isSelected ? tag.color : 'transparent'}; 
                           color: ${isSelected ? 'white' : tag.color}; 
                           border: 1px solid ${tag.color};">
                ${tag.name}
            </button>
        `);
        
        // Add click handler
        tagButton.on('click', function() {
            const btn = $(this);
            const tagId = parseInt(btn.data('tag-id'));
            const tag = tags.find(t => t.id === tagId);
            
            if (btn.hasClass('selected')) {
                // Deselect
                btn.removeClass('selected');
                btn.css({
                    'background-color': 'transparent',
                    'color': tag.color
                });
            } else {
                // Select
                btn.addClass('selected');
                btn.css({
                    'background-color': tag.color,
                    'color': 'white'
                });
            }
        });
        
        tagsContainer.append(tagButton);
    });
}

// Open delete confirmation modal (Enhanced for Prompt 5)
function openDeleteConfirmation(taskId) {
    if (!taskId) {
        showToast('error', 'Error', 'No task ID provided for deletion');
        return;
    }
    
    currentTaskId = taskId;
    
    // Find task to show details in confirmation
    const taskToDelete = tasks.find(t => t.id == taskId);
    if (taskToDelete) {
        // Update modal content with task details
        $('#delete-task-title').text(taskToDelete.title);
        $('#delete-task-description').text(taskToDelete.description || 'No description');
        
        // Show enhanced confirmation message
        $('#delete-confirm-message').html(`
            <div class="alert alert-warning">
                <i class="fas fa-exclamation-triangle me-2"></i>
                <strong>Are you sure you want to delete this task?</strong>
                <br><small>This action cannot be undone.</small>
            </div>
        `);
    } else {
        $('#delete-task-title').text('Unknown Task');
        $('#delete-task-description').text('Task details not available');
    }
    
    console.log(`Opening delete confirmation for task ${taskId}: "${taskToDelete ? taskToDelete.title : 'Unknown'}"`);
    
    const deleteModal = new bootstrap.Modal(document.getElementById('delete-confirm-modal'));
    deleteModal.show();
}

// Handle task form submission (Enhanced for Prompt 5)
function handleTaskSubmit(formData = null) {
    console.log('Handling task submission with enhanced CRUD operations...');
    
    // Use provided form data or extract from form
    let taskData;
    if (formData) {
        taskData = formData;
    } else {
        // Get form values from the create-task-form
        const taskId = $('#task-id').val();
        
        // Get selected tag IDs
        const selectedTagIds = [];
        $('#task-tags-container .tag-btn.selected').each(function() {
            selectedTagIds.push(parseInt($(this).data('tag-id')));
        });
        
        taskData = {
            title: $('#task-title').val().trim(),
            description: $('#task-description').val().trim(),
            dueDate: $('#task-due-date').val(),
            priority: $('#task-priority').val(),
            status: $('#task-status').val(),
            tagIds: selectedTagIds
        };
        taskData.isUpdate = !!taskId;
        taskData.taskId = taskId;
    }
    
    // Enhanced validation
    if (!taskData.title || !taskData.dueDate) {
        showToast('error', 'Validation Error', 'Please fill in all required fields (Title and Due Date)');
        return;
    }
    
    if (new Date(taskData.dueDate) < new Date().setHours(0,0,0,0)) {
        const confirmPastDate = confirm('The due date is in the past. Do you want to continue?');
        if (!confirmPastDate) return;
    }
    
    // Hide modal
    const taskModal = bootstrap.Modal.getInstance(document.getElementById('task-modal'));
    if (taskModal) taskModal.hide();
    
    // Show loading state
    showLoadingState('Saving task...');
    
    // Determine operation: CREATE (POST) or UPDATE (PUT)
    if (taskData.isUpdate || taskData.taskId) {
        console.log(`Sending PUT request to update task ${taskData.taskId}`);
        // UPDATE existing task - send PUT request
        updateTask(taskData.taskId, taskData).then(updatedTask => {
            hideLoadingState();
            
            // Show success notification
            showToast('success', 'Task Updated', 
                `Task "${updatedTask.title || taskData.title}" has been updated successfully`);
            
            // Refresh task list using jQuery without page reload
            refreshTaskListWithoutReload();
            
            // Update dashboard if visible
            if ($('#dashboard-container').is(':visible')) {
                loadDashboardData();
            }
            
        }).catch(error => {
            hideLoadingState();
            console.error('Task update failed:', error);
            showToast('error', 'Update Failed', `Failed to update task: ${error.message}`);
        });
    } else {
        console.log('Sending POST request to create new task');
        // CREATE new task - send POST request
        createTask(taskData).then(newTask => {
            hideLoadingState();
            
            // Show success notification
            showToast('success', 'Task Created', 
                `Task "${newTask.title || taskData.title}" has been created successfully`);
            
            // Refresh task list using jQuery without page reload
            refreshTaskListWithoutReload();
            
            // Update dashboard if visible
            if ($('#dashboard-container').is(':visible')) {
                loadDashboardData();
            }
            
            // Refresh current view
            refreshTaskView();
        }).catch(error => {
            showToast('error', 'Creation Failed', 'Failed to create task: ' + error.message);
        });
    }
}

// Helper function to refresh the current task view
function refreshTaskView() {
    if ($('#dashboard-container').is(':visible')) {
        loadDashboardData();
    } else if ($('#task-list-container').is(':visible')) {
        if ($('#shared-tasks-link').hasClass('active')) {
            showSharedTasks();
        } else {
            showMyTasks();
        }
    }
}

// Handle edit task form submission (Enhanced for Prompt 5)
function handleEditTaskSubmit(taskId = null, formData = null) {
    console.log('Handling edit task submission with enhanced PUT operations...');
    
    // Use provided data or extract from form
    let editTaskId = taskId || $('#edit-task-id').val();
    let taskData;
    
    if (formData) {
        taskData = formData;
    } else {
        if (!editTaskId) {
            showToast('error', 'Error', 'Task ID not found');
            return;
        }
        
        // Get selected tag IDs from edit modal
        const selectedTagIds = [];
        $('#edit-task-tags-container .tag-btn.selected').each(function() {
            selectedTagIds.push(parseInt($(this).data('tag-id')));
        });
        
        taskData = {
            title: $('#edit-task-title').val().trim(),
            description: $('#edit-task-description').val().trim(),
            dueDate: $('#edit-task-due-date').val(),
            priority: $('#edit-task-priority').val(),
            status: $('#edit-task-status').val(),
            tagIds: selectedTagIds
        };
    }
    
    // Enhanced validation
    if (!taskData.title || !taskData.dueDate) {
        showToast('error', 'Validation Error', 'Please fill in all required fields (Title and Due Date)');
        return;
    }
    
    if (new Date(taskData.dueDate) < new Date().setHours(0,0,0,0)) {
        const confirmPastDate = confirm('The due date is in the past. Do you want to continue?');
        if (!confirmPastDate) return;
    }
    
    console.log(`Sending PUT request to update task ${editTaskId}:`, taskData);
    
    // Hide modal
    const editModal = bootstrap.Modal.getInstance(document.getElementById('edit-task-modal'));
    if (editModal) editModal.hide();
    
    // Show loading state
    showLoadingState('Updating task...');
    
    // Send PUT request to update task
    updateTask(editTaskId, taskData).then(updatedTask => {
        hideLoadingState();
        
        // Show enhanced success notification
        showToast('success', 'Task Updated Successfully', 
            `Task "${updatedTask.title || taskData.title}" has been updated successfully`);
        
        // Refresh task list using jQuery without page reload
        refreshTaskListWithoutReload();
        
        // Update dashboard if visible
        if ($('#dashboard-container').is(':visible')) {
            loadDashboardData();
        }
        
        // Refresh current view
        refreshTaskView();
    }).catch(error => {
        showToast('error', 'Update Failed', 'Failed to update task: ' + error.message);
    });
}

// Create a new task using API
function createTask(taskData) {
    const apiUrl = 'http://localhost:3000/api/tasks';
    
    // Add user ID and creation timestamp
    taskData.userId = currentUser.id;
    taskData.createdAt = new Date().toISOString();
    
    console.log('Creating new task:', taskData);
    
    // Use authenticated request
    return makeAuthenticatedRequest(apiUrl, {
        method: 'POST',
        body: JSON.stringify(taskData)
    })
    .then(response => {
        console.log('Task created successfully via API:', response);
        // Add to tasks array
        tasks.push(response);
        return response;
    })
    .catch(error => {
        console.log('API unavailable, creating task in offline mode:', error.message);
        
        // Fallback to localStorage if API fails
        taskData.id = Date.now().toString();
        tasks.push(taskData);
        saveTasksToStorage();
        console.log('Task created in offline mode:', taskData);
        return taskData;
    });
}

// Update an existing task using API
function updateTask(taskId, taskData) {
    const apiUrl = `http://localhost:3000/api/tasks/${taskId}`;
    
    console.log(`Sending PUT request to ${apiUrl}`, taskData);
    
    // Use authenticated request
    return makeAuthenticatedRequest(apiUrl, {
        method: 'PUT',
        body: JSON.stringify(taskData)
    })
    .then(response => {
        console.log('Task updated successfully via API:', response);
        
        // Update task in local array
        const taskIndex = tasks.findIndex(t => t.id === taskId);
        if (taskIndex !== -1) {
            tasks[taskIndex] = response;
            
            // Update the task card in the UI
            const taskCard = $(`.task-card[data-task-id="${taskId}"]`);
            if (taskCard.length) {
                // Replace the old card with a new one
                taskCard.replaceWith(createTaskCard(tasks[taskIndex]));
            }
        }
        return response;
    })
    .catch(error => {
        console.log('API unavailable, updating task in offline mode:', error.message);
        
        // Fallback to localStorage if API fails
        const taskIndex = tasks.findIndex(t => t.id === taskId);
        if (taskIndex !== -1) {
            // Update task in memory and localStorage
            tasks[taskIndex] = { ...tasks[taskIndex], ...taskData };
            localStorage.setItem('tasks', JSON.stringify(tasks));
            
            console.log('Task updated in offline mode:', tasks[taskIndex]);
            
            // Update the task card in the UI
            const taskCard = $(`.task-card[data-task-id="${taskId}"]`);
            if (taskCard.length) {
                // Replace the old card with a new one
                taskCard.replaceWith(createTaskCard(tasks[taskIndex]));
            }
            
            return tasks[taskIndex];
        } else {
            throw new Error('Task not found');
        }
    });
}

// Update task status using API
function updateTaskStatus(taskId, newStatus) {
    // API URL
    const apiUrl = `http://localhost:3000/api/tasks/${taskId}/status`;
    
    // Use jQuery's AJAX to update status
    $.ajax({
        url: apiUrl,
        type: 'PATCH',
        headers: {
            'Authorization': `Bearer ${localStorage.getItem('token')}`,
            'Content-Type': 'application/json'
        },
        data: JSON.stringify({ status: newStatus }),
        timeout: 5000,
        success: function(response) {
            console.log('Task status updated via API');
            // Find the task and update it
            const taskIndex = tasks.findIndex(t => t.id === taskId);
            if (taskIndex !== -1) {
                tasks[taskIndex].status = newStatus;
            }
            
            // Update UI
            updateTaskStatusUI(taskId, newStatus);
            
            // Show toast notification
            const statusText = newStatus === 'in-progress' ? 'In Progress' : 
                              newStatus.charAt(0).toUpperCase() + newStatus.slice(1);
            showToast('success', 'Status Updated', `Task status changed to ${statusText}`);
        },
        error: function(xhr, status, error) {
            console.log('API unavailable, updating task status in offline mode');
            
            // Fallback to localStorage if API fails
            const task = tasks.find(t => t.id === taskId);
            if (task) {
                task.status = newStatus;
                localStorage.setItem('tasks', JSON.stringify(tasks));
                
                // Update UI
                updateTaskStatusUI(taskId, newStatus);
                
                const statusText = newStatus === 'in-progress' ? 'In Progress' : 
                                  newStatus.charAt(0).toUpperCase() + newStatus.slice(1);
                showToast('success', 'Status Updated', `Task status changed to ${statusText}`);
            } else {
                showToast('error', 'Error', 'Task not found');
            }
        }
    });
}

// Helper function to update task status in UI
function updateTaskStatusUI(taskId, newStatus) {
    const taskCard = $(`.task-card[data-task-id="${taskId}"]`);
    const statusBadge = taskCard.find('.badge');
    
    // Remove old status classes
    statusBadge.removeClass('status-pending status-in-progress status-completed');
    
    // Add new status class
    statusBadge.addClass(`status-${newStatus}`);
    
    // Update text
    const statusText = newStatus === 'in-progress' ? 'In Progress' : 
                      newStatus.charAt(0).toUpperCase() + newStatus.slice(1);
    statusBadge.text(statusText);
}

// Handle task deletion using API (Enhanced for Prompt 5)
function handleDeleteTask(taskId = null) {
    const deleteTaskId = taskId || currentTaskId;
    
    if (!deleteTaskId) {
        console.error('No task ID provided for deletion');
        showToast('error', 'Error', 'No task ID found for deletion');
        return;
    }
    
    // Find task for better user feedback
    const taskToDelete = tasks.find(t => t.id == deleteTaskId);
    const taskTitle = taskToDelete ? taskToDelete.title : 'Unknown Task';
    
    console.log(`Sending DELETE request for task ${deleteTaskId}: "${taskTitle}"`);
    
    // Show loading state
    showLoadingState('Deleting task...');
    
    // API URL for DELETE request
    const apiUrl = `http://localhost:3000/api/tasks/${deleteTaskId}`;
    
    // Use authenticated request for DELETE
    if (isAuthenticated()) {
        makeAuthenticatedRequest(apiUrl, {
            method: 'DELETE'
        })
        .then(response => {
            console.log('Task deleted successfully via DELETE API:', response);
            hideLoadingState();
            
            // Show success notification with task title
            showToast('success', 'Task Deleted', 
                `Task "${taskTitle}" has been deleted successfully`);
            
            // Complete deletion and refresh UI
            completeTaskDeletionWithRefresh(deleteTaskId);
            
        })
        .catch(error => {
            console.log('API DELETE request failed, using offline mode:', error.message);
            hideLoadingState();
            
            // Fallback to offline deletion
            handleOfflineTaskDeletion(deleteTaskId, taskTitle);
        });
    } else {
        // No authentication, handle offline deletion
        hideLoadingState();
        handleOfflineTaskDeletion(deleteTaskId, taskTitle);
    }
}

// Handle offline task deletion
function handleOfflineTaskDeletion(taskId, taskTitle) {
    console.log('Handling offline task deletion for:', taskId);
    
    // Find and remove from tasks array
    const taskIndex = tasks.findIndex(t => t.id == taskId);
    if (taskIndex !== -1) {
        tasks.splice(taskIndex, 1);
        localStorage.setItem('tasks', JSON.stringify(tasks));
        
        showToast('success', 'Task Deleted (Offline)', 
            `Task "${taskTitle}" has been deleted locally`);
        
        completeTaskDeletionWithRefresh(taskId);
    } else {
        showToast('error', 'Error', 'Task not found for deletion');
        hideDeleteModal();
    }
}

// Complete task deletion with enhanced refresh (Prompt 5)
function completeTaskDeletionWithRefresh(taskId) {
    console.log('Completing task deletion with jQuery refresh for task:', taskId);
    
    // Hide delete confirmation modal
    hideDeleteModal();
    
    // Remove task card from DOM immediately using jQuery
    $(`.task-card[data-task-id="${taskId}"]`).fadeOut(300, function() {
        $(this).remove();
        
        // Check if task list is now empty and update UI
        if ($('#task-list .task-card').length === 0) {
            $('#task-list').html(`
                <div class="text-center p-5">
                    <i class="fas fa-tasks fa-3x text-muted mb-3"></i>
                    <p class="text-muted">No tasks found. Create a new task to get started!</p>
                    <button class="btn btn-primary" onclick="showNewTaskModal()">
                        <i class="fas fa-plus me-1"></i> Create Your First Task
                    </button>
                </div>
            `);
        }
    });
    
    // Refresh task list without page reload
    refreshTaskListWithoutReload();
    
    // Update dashboard if visible
    if ($('#dashboard-container').is(':visible')) {
        loadDashboardData();
    }
    
    // Reset current task ID
    currentTaskId = null;
}

// Helper function to hide delete modal
function hideDeleteModal() {
    const deleteModal = bootstrap.Modal.getInstance(document.getElementById('delete-confirm-modal'));
    if (deleteModal) {
        deleteModal.hide();
    }
}

// Open share task modal (Enhanced for Prompt 6)
function openShareTaskModal(taskId) {
    console.log(`Opening enhanced share modal for task ${taskId}`);
    
    // Find task
    const task = tasks.find(t => t.id == taskId);
    
    if (!task) {
        showToast('error', 'Task Not Found', 'The task you want to share could not be found');
        return;
    }
    
    // Set task info in the modal with enhanced display
    $('#share-task-id').val(taskId);
    $('#share-task-title').text(task.title);
    $('#share-task-description').text(task.description || 'No description provided.');
    
    // Clear and reset form
    $('#shared-users-list').empty();
    $('#share-error').addClass('d-none');
    $('#share-email').val('');
    $('#share-permission').val('edit');
    $('#share-notify').prop('checked', true);
    
    // Add enhanced "No users" message
    $('#shared-users-list').append(`
        <p class="text-muted small mb-0" id="no-shared-users">
            <i class="fas fa-info-circle me-1"></i>No users added yet. Add users above to share this task.
        </p>
    `);
    
    // Load existing shared users if any
    if (task.sharedWith && task.sharedWith.length > 0) {
        $('#no-shared-users').remove();
        task.sharedWith.forEach(user => {
            addSharedUserToList(user, task.sharedPermissions ? task.sharedPermissions[user] : 'edit');
        });
    }
    
    // Show sharing statistics
    const sharedCount = task.sharedWith ? task.sharedWith.length : 0;
    if (sharedCount > 0) {
        $('#share-task-description').append(`<br><small class="text-info">
            <i class="fas fa-users me-1"></i>Currently shared with ${sharedCount} user${sharedCount > 1 ? 's' : ''}
        </small>`);
    }
    
    console.log(`Task "${task.title}" sharing modal opened with ${sharedCount} existing shares`);
    
    // Show modal
    const shareModal = new bootstrap.Modal(document.getElementById('share-task-modal'));
    shareModal.show();
}

// Add a user to the shared users list in the modal (Enhanced for Prompt 6)
function addSharedUserToList(email, permission = 'edit') {
    // Remove "No users" message if present
    $('#no-shared-users').remove();
    
    // Validate email format
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const isEmail = emailRegex.test(email);
    
    // Get permission info
    const permissionInfo = getPermissionInfo(permission);
    
    // Create enhanced user item
    const userItem = $(`
        <div class="shared-user-item d-flex justify-content-between align-items-center p-2 mb-2 border rounded" data-email="${email}" data-permission="${permission}">
            <div class="user-info">
                <div class="d-flex align-items-center">
                    <i class="fas ${isEmail ? 'fa-envelope' : 'fa-user'} me-2 text-primary"></i>
                    <span class="user-email fw-medium">${email}</span>
                    <span class="badge ${permissionInfo.class} ms-2">
                        <i class="${permissionInfo.icon} me-1"></i>${permissionInfo.text}
                    </span>
                </div>
                <small class="text-muted">
                    ${isEmail ? 'Email address' : 'Username'} • ${permissionInfo.description}
                </small>
            </div>
            <button class="btn btn-outline-danger btn-sm shared-user-remove" title="Remove user">
                <i class="fas fa-times"></i>
            </button>
        </div>
    `);
    
    // Add remove functionality
    userItem.find('.shared-user-remove').on('click', function() {
        userItem.fadeOut(200, function() {
            userItem.remove();
            
            // If no users left, show "No users" message
            if ($('#shared-users-list').children('.shared-user-item').length === 0) {
                $('#shared-users-list').append(`
                    <p class="text-muted small mb-0" id="no-shared-users">
                        <i class="fas fa-info-circle me-1"></i>No users added yet. Add users above to share this task.
                    </p>
                `);
            }
        });
    });
    
    // Add to list
    $('#shared-users-list').append(userItem);
}

// Get permission information for display
function getPermissionInfo(permission) {
    const permissions = {
        'view': {
            text: 'View Only',
            description: 'Can view task details',
            icon: 'fas fa-eye',
            class: 'bg-info'
        },
        'edit': {
            text: 'Edit',
            description: 'Can view and modify task',
            icon: 'fas fa-edit',
            class: 'bg-warning'
        },
        'manage': {
            text: 'Manage',
            description: 'Can edit and share with others',
            icon: 'fas fa-crown',
            class: 'bg-danger'
        }
    };
    return permissions[permission] || permissions['edit'];
}

// Share task with users (Enhanced for Prompt 6)
function shareTask(taskId, shareData) {
    console.log(`Sharing task ${taskId} with enhanced data:`, shareData);
    
    // API endpoint as specified in Prompt 6
    const apiUrl = `http://localhost:3000/api/tasks/share`;
    
    // Prepare sharing data according to Prompt 6 requirements
    const requestData = {
        taskId: taskId,
        targetUser: shareData.email || shareData.username,
        permission: shareData.permission || 'edit',
        notify: shareData.notify !== false
    };
    
    console.log(`Sending POST request to /api/tasks/share with:`, requestData);
    
    // Use authenticated request to POST to /api/tasks/share
    return makeAuthenticatedRequest(apiUrl, {
        method: 'POST',
        body: JSON.stringify(requestData)
    })
    .then(response => {
        console.log('Task shared successfully via POST to /api/tasks/share:', response);
        
        // Update task in local array
        const taskIndex = tasks.findIndex(t => t.id == taskId);
        if (taskIndex !== -1) {
            // Initialize sharing arrays if they don't exist
            if (!tasks[taskIndex].sharedWith) tasks[taskIndex].sharedWith = [];
            if (!tasks[taskIndex].sharedPermissions) tasks[taskIndex].sharedPermissions = {};
            
            // Add user if not already shared
            if (!tasks[taskIndex].sharedWith.includes(requestData.targetUser)) {
                tasks[taskIndex].shared = true;
                tasks[taskIndex].sharedWith.push(requestData.targetUser);
                tasks[taskIndex].sharedPermissions[requestData.targetUser] = requestData.permission;
                
                // Update localStorage
                localStorage.setItem('tasks', JSON.stringify(tasks));
                
                // Update the task card in the UI to show shared status
                updateTaskCardSharedStatus(taskId);
            }
        }
        
        return response;
    })
    .catch(error => {
        console.log('API unavailable, sharing task in offline mode:', error.message);
        
        // Fallback to localStorage if API fails
        const taskIndex = tasks.findIndex(t => t.id == taskId);
        if (taskIndex !== -1) {
            // Initialize sharing arrays if they don't exist
            if (!tasks[taskIndex].sharedWith) tasks[taskIndex].sharedWith = [];
            if (!tasks[taskIndex].sharedPermissions) tasks[taskIndex].sharedPermissions = {};
            
            // Add user if not already shared
            if (!tasks[taskIndex].sharedWith.includes(requestData.targetUser)) {
                tasks[taskIndex].shared = true;
                tasks[taskIndex].sharedWith.push(requestData.targetUser);
                tasks[taskIndex].sharedPermissions[requestData.targetUser] = requestData.permission;
                
                localStorage.setItem('tasks', JSON.stringify(tasks));
                
                // Update the task card in the UI
                updateTaskCardSharedStatus(taskId);
            }
            
            return { 
                success: true, 
                message: 'Task shared (offline mode)',
                sharedWith: requestData.targetUser,
                permission: requestData.permission
            };
        } else {
            throw new Error('Task not found');
        }
    });
}

// Update task card to show shared status
function updateTaskCardSharedStatus(taskId) {
    const taskCard = $(`.task-card[data-task-id="${taskId}"]`);
    if (taskCard.length) {
        const task = tasks.find(t => t.id == taskId);
        if (task) {
            // Replace the old card with a new one that shows shared status
            taskCard.replaceWith(createTaskCard(task));
        }
    }
}

// Toggle comment section visibility (Enhanced for Prompt 7)
function toggleCommentSection(card, taskId) {
    console.log(`Toggling comment section for task ${taskId} (Prompt 7 enhancement)`);
    
    const commentSection = card.find('.task-comments');
    const commentBtn = card.find('.comment-btn');
    
    if (commentSection.hasClass('d-none')) {
        // Show comments section with enhanced animation
        commentSection.removeClass('d-none').hide().slideDown(300);
        commentBtn.addClass('active').html('<i class="fas fa-comments"></i> Hide');
        
        // Load comments when showing section (Prompt 7)
        console.log(`Loading comments for task ${taskId} (Prompt 7)`);
        loadTaskComments(taskId, card);
        
        // Focus on comment input for better UX
        setTimeout(() => {
            card.find('.comment-input').focus();
        }, 350);
        
        // Track comment section opened
        console.log(`Comment section opened for task ${taskId} (Prompt 7 tracking)`);
        
    } else {
        // Hide comments section with animation
        commentSection.slideUp(300, function() {
            $(this).addClass('d-none');
        });
        commentBtn.removeClass('active').html('<i class="fas fa-comment"></i>');
        
        // Update button text with comment count if available
        const commentCount = card.find('.comments-list .comment-item').length;
        if (commentCount > 0) {
            commentBtn.html(`<i class="fas fa-comment"></i> ${commentCount}`);
        }
        
        console.log(`Comment section closed for task ${taskId} (Prompt 7 tracking)`);
    }
}

// Load comments for a task (Enhanced for Prompt 7)
function loadTaskComments(taskId, card) {
    console.log(`Loading comments for task ${taskId} (Prompt 7 enhancement)`);
    
    const commentsList = card.find('.comments-list');
    commentsList.empty();
    
    // Show enhanced loading indicator
    commentsList.html(`
        <div class="text-center p-2">
            <div class="spinner-border spinner-border-sm text-primary" role="status"></div>
            <small class="text-muted ms-2">Loading comments...</small>
        </div>
    `);
    
    // API URL as specified in Prompt 7
    const apiUrl = `http://localhost:3000/api/tasks/${taskId}/comments`;
    
    console.log(`Fetching comments from ${apiUrl} (Prompt 7 API endpoint)`);
    
    // Use authenticated request for better consistency
    if (isAuthenticated()) {
        makeAuthenticatedRequest(apiUrl, {
            method: 'GET'
        })
        .then(response => {
            console.log('Comments loaded successfully via authenticated request (Prompt 7):', response);
            renderEnhancedComments(response, commentsList, taskId, card);
        })
        .catch(error => {
            console.log('API unavailable, loading comments from localStorage (Prompt 7 fallback)');
            loadCommentsOffline(taskId, commentsList, card);
        });
    } else {
        // Fallback for non-authenticated users
        loadCommentsOffline(taskId, commentsList, card);
    }
}

// Load comments from offline storage
function loadCommentsOffline(taskId, commentsList, card) {
    try {
        const storedComments = localStorage.getItem('comments');
        if (storedComments) {
            const allComments = JSON.parse(storedComments);
            const taskComments = allComments.filter(c => c.taskId == taskId);
            
            // Sort comments by date (newest first)
            taskComments.sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
            
            renderEnhancedComments(taskComments, commentsList, taskId, card);
        } else {
            renderEmptyCommentsState(commentsList);
        }
    } catch (error) {
        console.error('Error loading offline comments:', error);
        renderEmptyCommentsState(commentsList);
    }
}

// Render comments with enhanced UI (Prompt 7)
function renderEnhancedComments(comments, container, taskId, card) {
    container.empty();
    
    if (!comments || comments.length === 0) {
        renderEmptyCommentsState(container);
        return;
    }
    
    console.log(`Rendering ${comments.length} comments for task ${taskId} (Prompt 7)`);
    
    // Sort comments by date (newest first)
    const sortedComments = [...comments].sort((a, b) => new Date(b.createdAt) - new Date(a.createdAt));
    
    // Create comments HTML with enhanced styling
    sortedComments.forEach(comment => {
        const commentHtml = createCommentHTML(comment);
        container.append(commentHtml);
    });
    
    // Update comment count
    updateCommentCount(taskId, card);
    
    // Add delete functionality for user's own comments
    container.find('.delete-comment-btn').on('click', function(e) {
        e.preventDefault();
        const commentId = $(this).data('comment-id');
        deleteComment(commentId, taskId, card);
    });
    
    // Add scroll to bottom for many comments
    if (comments.length > 3) {
        container.scrollTop(container[0].scrollHeight);
    }
}

// Render empty comments state
function renderEmptyCommentsState(container) {
    container.html(`
        <div class="text-center p-3">
            <i class="fas fa-comments fa-2x text-muted mb-2"></i>
            <p class="text-muted small mb-0">No comments yet</p>
            <small class="text-muted">Be the first to comment!</small>
        </div>
    `);
}

// Delete comment function (Enhanced for Prompt 7)
function deleteComment(commentId, taskId, card) {
    if (!confirm('Are you sure you want to delete this comment?')) {
        return;
    }
    
    console.log(`Deleting comment ${commentId} for task ${taskId} (Prompt 7)`);
    
    // API URL for deleting comment
    const apiUrl = `http://localhost:3000/api/tasks/${taskId}/comments/${commentId}`;
    
    // Show loading state
    const commentElement = card.find(`[data-comment-id="${commentId}"]`);
    commentElement.addClass('opacity-50');
    
    makeAuthenticatedRequest(apiUrl, {
        method: 'DELETE'
    })
    .then(response => {
        console.log('Comment deleted successfully via API (Prompt 7):', response);
        
        // Remove from UI with animation
        commentElement.fadeOut(300, function() {
            $(this).remove();
            updateCommentCount(taskId, card);
            
            // Check if no comments left
            if (card.find('.comments-list .comment-item').length === 0) {
                renderEmptyCommentsState(card.find('.comments-list'));
            }
        });
        
        showToast('success', 'Comment Deleted', 'Comment has been removed successfully.');
    })
    .catch(error => {
        console.log('API unavailable, deleting comment in offline mode:', error.message);
        
        // Remove from localStorage
        try {
            const storedComments = localStorage.getItem('comments');
            if (storedComments) {
                let comments = JSON.parse(storedComments);
                comments = comments.filter(c => c.id !== commentId);
                localStorage.setItem('comments', JSON.stringify(comments));
            }
        } catch (e) {
            console.error('Error removing comment from offline storage:', e);
        }
        
        // Remove from UI
        commentElement.fadeOut(300, function() {
            $(this).remove();
            updateCommentCount(taskId, card);
            
            if (card.find('.comments-list .comment-item').length === 0) {
                renderEmptyCommentsState(card.find('.comments-list'));
            }
        });
        
        showToast('info', 'Comment Deleted Offline', 'Comment removed locally. Will sync when server is available.');
    })
    .finally(() => {
        commentElement.removeClass('opacity-50');
    });
}

// Add a comment to a task (Enhanced for Prompt 7)
function addComment(taskId, commentText, card) {
    console.log(`Adding comment to task ${taskId} (Prompt 7 enhancement)`);
    
    if (!commentText || commentText.trim() === '') {
        showToast('warning', 'Comment Required', 'Please enter a comment before submitting.');
        return;
    }
    
    // Create enhanced comment object
    const comment = {
        taskId: taskId,
        text: commentText.trim(),
        userId: currentUser.id,
        userName: currentUser.name,
        userEmail: currentUser.email,
        createdAt: new Date().toISOString(),
        id: generateCommentId()
    };
    
    console.log('Creating comment:', comment);
    
    // Show loading state on add button
    const addBtn = card.find('.add-comment-btn');
    const originalText = addBtn.html();
    addBtn.prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-1"></i>Adding...');
    
    // Clear input field immediately for better UX
    const commentInput = card.find('.comment-input');
    const inputValue = commentInput.val();
    commentInput.val('');
    
    // API URL as specified in Prompt 7
    const apiUrl = `http://localhost:3000/api/tasks/${taskId}/comments`;
    
    console.log(`Sending POST request to ${apiUrl} (Prompt 7 requirement)`);
    
    // Use authenticated request to POST to /api/tasks/:id/comments (Prompt 7)
    makeAuthenticatedRequest(apiUrl, {
        method: 'POST',
        body: JSON.stringify(comment)
    })
    .then(response => {
        console.log('Comment added successfully via API (Prompt 7):', response);
        
        // Show success feedback
        showToast('success', 'Comment Added', 'Your comment has been posted successfully.');
        
        // Add optimistic UI update before reload
        addCommentToUI(comment, card);
        
        // Reload all comments to ensure consistency
        setTimeout(() => {
            loadTaskComments(taskId, card);
        }, 500);
    })
    .catch(error => {
        console.log('API unavailable, adding comment in offline mode:', error.message);
        
        // Restore input value on error
        commentInput.val(inputValue);
        
        // Fallback to localStorage if API fails
        saveCommentOffline(comment);
        
        // Add to UI immediately in offline mode
        addCommentToUI(comment, card);
        
        // Show offline notification
        showToast('info', 'Comment Saved Offline', 'Comment saved locally. Will sync when server is available.');
    })
    .finally(() => {
        // Reset button state
        addBtn.prop('disabled', false).html(originalText);
    });
}

// Generate unique comment ID
function generateCommentId() {
    return 'comment_' + Date.now() + '_' + Math.random().toString(36).substr(2, 9);
}

// Add comment to UI immediately (optimistic update)
function addCommentToUI(comment, card) {
    const commentsList = card.find('.comments-list');
    
    // Remove "no comments" message if present
    commentsList.find('.text-muted').remove();
    
    // Create comment HTML
    const commentHtml = createCommentHTML(comment);
    
    // Add to top of comments list with animation
    const commentElement = $(commentHtml);
    commentElement.hide().prependTo(commentsList).fadeIn(300);
    
    // Update comment count if visible
    updateCommentCount(comment.taskId, card);
}

// Save comment to localStorage for offline mode
function saveCommentOffline(comment) {
    try {
        const storedComments = localStorage.getItem('comments');
        let comments = [];
        
        if (storedComments) {
            comments = JSON.parse(storedComments);
        }
        
        comments.push(comment);
        localStorage.setItem('comments', JSON.stringify(comments));
        
        console.log('Comment saved offline:', comment);
    } catch (error) {
        console.error('Error saving comment offline:', error);
    }
}

// Create comment HTML with enhanced styling
function createCommentHTML(comment) {
    const timeAgo = getTimeAgo(comment.createdAt);
    const isCurrentUser = comment.userId === currentUser.id;
    
    return `
        <div class="comment-item mb-2 p-2 border rounded ${isCurrentUser ? 'bg-light border-primary' : ''}" data-comment-id="${comment.id}">
            <div class="d-flex justify-content-between align-items-start">
                <div class="comment-header">
                    <small class="fw-bold text-primary">
                        <i class="fas fa-user me-1"></i>${comment.userName}
                        ${isCurrentUser ? '<span class="badge bg-primary ms-1">You</span>' : ''}
                    </small>
                    <small class="text-muted ms-2">
                        <i class="fas fa-clock me-1"></i>${timeAgo}
                    </small>
                </div>
                ${isCurrentUser ? `
                <div class="comment-actions">
                    <button class="btn btn-sm btn-outline-danger delete-comment-btn" data-comment-id="${comment.id}" title="Delete comment">
                        <i class="fas fa-trash-alt"></i>
                    </button>
                </div>` : ''}
            </div>
            <div class="comment-text mt-1">
                ${escapeHtml(comment.text)}
            </div>
        </div>
    `;
}

// Update comment count display
function updateCommentCount(taskId, card) {
    const commentBtn = card.find('.comment-btn');
    const commentsList = card.find('.comments-list .comment-item');
    const count = commentsList.length;
    
    if (count > 0) {
        commentBtn.html(`<i class="fas fa-comment"></i> ${count}`);
    } else {
        commentBtn.html('<i class="fas fa-comment"></i>');
    }
}

// Utility function to escape HTML
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Utility function to get time ago
function getTimeAgo(dateString) {
    const date = new Date(dateString);
    const now = new Date();
    const seconds = Math.floor((now - date) / 1000);
    
    if (seconds < 60) return 'Just now';
    if (seconds < 3600) return `${Math.floor(seconds / 60)}m ago`;
    if (seconds < 86400) return `${Math.floor(seconds / 3600)}h ago`;
    return `${Math.floor(seconds / 86400)}d ago`;
} 