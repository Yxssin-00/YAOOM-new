/**
 * TaskMate - Task Management System
 * jQuery + Bootstrap implementation
 */

// Global variables
let currentUser = null;
let tasks = [];
let tags = [
    { id: 1, name: 'Work', color: '#3B82F6' }, // blue
    { id: 2, name: 'Personal', color: '#10B981' }, // green
    { id: 3, name: 'Urgent', color: '#EF4444' }, // red
    { id: 4, name: 'Learning', color: '#8B5CF6' }, // purple
    { id: 5, name: 'Health', color: '#F59E0B' }, // amber
];
let currentTaskId = null;

// Document Ready Handler
$(document).ready(function() {
    console.log('TaskMate application initializing...');
    
    // Initialize the app
    initializeApp();

    // Attach event listeners
    attachEventListeners();

    // Check authentication on page load
    checkAuthentication();
});

// Initialize the application
function initializeApp() {
    // Set default date for task form
    const today = new Date();
    const formattedDate = today.toISOString().split('T')[0]; // YYYY-MM-DD format
    $('#task-due-date').val(formattedDate);

    // Check if dark mode is enabled
    if (localStorage.getItem('darkMode') === 'enabled') {
        $('body').addClass('dark-mode');
        console.log('Dark mode restored from localStorage');
    } else {
        console.log('Light mode (default)');
    }
    
    // Icons will be handled automatically by CSS based on body.dark-mode class

    // Load tags from localStorage or use defaults
    const savedTags = localStorage.getItem('tags');
    if (savedTags) {
        tags = JSON.parse(savedTags);
    } else {
        // Save default tags
        localStorage.setItem('tags', JSON.stringify(tags));
    }
    
    // Add sample notification test data if no tasks exist
    addSampleNotificationTestData();
    
    console.log('TaskMate application initialized successfully');
}

// Central function to manage container visibility
function showContainer(containerId) {
    console.log('Showing container:', containerId);
    
    // Hide all containers
    $('#dashboard-container').hide();
    $('#task-list-container').hide();
    $('#calendar-container').hide();
    $('#profile-container').hide();
    $('#admin-panel-container').hide();
    
    // Show the requested container
    $(`#${containerId}`).show();
}

// Attach event listeners to elements
function attachEventListeners() {
    // Theme toggle (modern icon click) - use event delegation to prevent duplicates
    $(document).off('click', '#theme-toggle').on('click', '#theme-toggle', function(e) {
        e.preventDefault();
        console.log('Theme toggle clicked!');
        toggleDarkMode();
    });
    
    // Notification bell
    $('#notification-bell').on('click', function(e) {
        e.preventDefault();
        toggleNotifications();
    });
    
    // Navigation links
    $('#dashboard-link, #sidebar-dashboard').on('click', showDashboard);
    $('#my-tasks-link, #sidebar-my-tasks').on('click', showMyTasksWithFilters);
    $('#shared-tasks-link, #sidebar-shared-tasks').on('click', showSharedTasksWithFilters);
    $('#calendar-link, #sidebar-calendar').on('click', showCalendar);
    
    // Profile link now redirects to profile.html instead of showing profile in main container
    $('#profile-link, #sidebar-profile').on('click', function(e) {
        e.preventDefault();
        window.location.href = './profile.html';
    });
    
    // Debug buttons
    $('button[onclick="console.log(currentUser)"]').off('click').on('click', function() {
        console.log('Current user:', currentUser);
        if (currentUser) {
            showToast('info', 'Current User', `Name: ${currentUser.name}<br>Email: ${currentUser.email}<br>Role: ${currentUser.role}`);
        } else {
            showToast('warning', 'No User', 'No user is currently logged in');
        }
    });
    
    // Authentication Event Handlers
    $('#register-link').on('click', function(e) {
        e.preventDefault();
        showRegisterModal();
    });
    
    $('#login-link').on('click', function(e) {
        e.preventDefault();
        showLoginModal();
    });
    
    // Login form submission
    $('#login-form').on('submit', function(e) {
        e.preventDefault();
        
        // Get form values using jQuery
        const email = $('#login-email').val().trim();
        const password = $('#login-password').val().trim();
        
        // Validate inputs
        if (!email || !password) {
            $('#login-error').removeClass('d-none').text('Please enter both email and password');
            return;
        }
        
        // Call login handler with form data
        handleLogin(email, password);
    });
    
    // Login button click (alternative trigger)
    $('#login-btn').on('click', function(e) {
        e.preventDefault();
        $('#login-form').submit();
    });
    
    // Register form submission
    $('#register-form').on('submit', function(e) {
        e.preventDefault();
        
        // Get form values using jQuery
        const name = $('#register-name').val().trim();
        const email = $('#register-email').val().trim();
        const password = $('#register-password').val().trim();
        const confirmPassword = $('#register-confirm-password').val().trim();
        
        // Validate inputs
        if (!name || !email || !password) {
            $('#register-error').removeClass('d-none').text('Please fill in all fields');
            return;
        }
        
        if (password !== confirmPassword) {
            $('#register-error').removeClass('d-none').text('Passwords do not match');
            return;
        }
        
        if (password.length < 6) {
            $('#register-error').removeClass('d-none').text('Password must be at least 6 characters long');
            return;
        }
        
        // Call register handler with form data
        handleRegister(name, email, password);
    });
    
    // Register button click (alternative trigger)
    $('#register-btn').on('click', function(e) {
        e.preventDefault();
        $('#register-form').submit();
    });
    
    // Logout handler
    $('#logout-link').on('click', function(e) {
        e.preventDefault();
        handleLogout();
    });
    
    // Task Operation Event Handlers
    $('#new-task-btn').on('click', function(e) {
        e.preventDefault();
        showNewTaskModal();
    });
    
    // Create task form submission
    $('#create-task-form').on('submit', function(e) {
        e.preventDefault();
        
        // Get form values using jQuery
        const taskData = {
            title: $('#task-title').val().trim(),
            description: $('#task-description').val().trim(),
            dueDate: $('#task-due-date').val(),
            priority: $('#task-priority').val(),
            status: $('#task-status').val()
        };
        
        // Get selected tag IDs
        const selectedTagIds = [];
        $('#task-tags-container .tag-btn.selected').each(function() {
            selectedTagIds.push(parseInt($(this).data('tag-id')));
        });
        taskData.tagIds = selectedTagIds;
        
        // Validate required fields
        if (!taskData.title || !taskData.dueDate) {
            showToast('error', 'Validation Error', 'Please fill in all required fields');
            return;
        }
        
        // Call task creation handler
        handleTaskSubmit(taskData);
    });
    
    // Save task button click (alternative trigger)
    $('#save-task-btn').on('click', function(e) {
        e.preventDefault();
        $('#create-task-form').submit();
    });
    
    // Edit task form submission
    $('#edit-task-form').on('submit', function(e) {
        e.preventDefault();
        
        // Get task ID
        const taskId = $('#edit-task-id').val();
        if (!taskId) {
            showToast('error', 'Error', 'Task ID not found');
            return;
        }
        
        // Get form values using jQuery
        const taskData = {
            title: $('#edit-task-title').val().trim(),
            description: $('#edit-task-description').val().trim(),
            dueDate: $('#edit-task-due-date').val(),
            priority: $('#edit-task-priority').val(),
            status: $('#edit-task-status').val()
        };
        
        // Get selected tag IDs from edit modal
        const selectedTagIds = [];
        $('#edit-task-tags-container .tag-btn.selected').each(function() {
            selectedTagIds.push(parseInt($(this).data('tag-id')));
        });
        taskData.tagIds = selectedTagIds;
        
        // Validate required fields
        if (!taskData.title || !taskData.dueDate) {
            showToast('error', 'Validation Error', 'Please fill in all required fields');
            return;
        }
        
        // Call task update handler
        handleEditTaskSubmit(taskId, taskData);
    });
    
    // Update task button click (alternative trigger)
    $('#update-task-btn').on('click', function(e) {
        e.preventDefault();
        $('#edit-task-form').submit();
    });
    
    // Delete task confirmation
    $('#confirm-delete-btn').on('click', function(e) {
        e.preventDefault();
        handleDeleteTask();
    });
    
    // New Tag Event Handlers
    $('#add-new-tag-btn').on('click', function(e) {
        e.preventDefault();
        showNewTagModal();
    });
    
    $('#edit-add-new-tag-btn').on('click', function(e) {
        e.preventDefault();
        showNewTagModal();
    });
    
    // New tag form submission
    $('#new-tag-form').on('submit', function(e) {
        e.preventDefault();
        
        // Get form values using jQuery
        const tagName = $('#new-tag-name').val().trim();
        const tagColor = $('#selected-tag-color').val();
        
        // Validate inputs
        if (!tagName) {
            showToast('error', 'Validation Error', 'Please enter a tag name');
            return;
        }
        
        if (!tagColor) {
            showToast('error', 'Validation Error', 'Please select a color');
            return;
        }
        
        // Call tag creation handler
        handleCreateTag(tagName, tagColor);
    });
    
    $('#create-tag-btn').on('click', function(e) {
        e.preventDefault();
        $('#new-tag-form').submit();
    });
    
    // Enhanced Task Sharing Event Handlers (Prompt 6)
    $('#add-share-user').on('click', function(e) {
        e.preventDefault();
        
        // Get form values using jQuery
        const email = $('#share-email').val().trim();
        const permission = $('#share-permission').val();
        
        if (!email) {
            showShareError('Please enter an email address or username.');
            return;
        }
        
        // Enhanced validation
        const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        const isValidEmail = emailRegex.test(email);
        const isValidUsername = email.length >= 3 && /^[a-zA-Z0-9_.-]+$/.test(email);
        
        if (!isValidEmail && !isValidUsername) {
            showShareError('Please enter a valid email address or username (minimum 3 characters, alphanumeric).');
            return;
        }
        
        // Check if user is already in the list
        const exists = $('#shared-users-list').find(`[data-email="${email}"]`).length > 0;
        if (exists) {
            showShareError('This user is already in the shared list.');
            return;
        }
        
        // Add to list with permission level
        addSharedUserToList(email, permission);
        
        // Clear input and error
        $('#share-email').val('');
        $('#share-error').addClass('d-none');
        
        console.log(`Added user ${email} with ${permission} permission to sharing list`);
    });
    
    $('#share-email').on('keypress', function(e) {
        if (e.which === 13) { // Enter key
            e.preventDefault();
            $('#add-share-user').click();
        }
    });
    
    // Enhanced save sharing button
    $('#save-share-btn').on('click', function() {
        const taskId = $('#share-task-id').val();
        const notify = $('#share-notify').is(':checked');
        
        if (!taskId) {
            showShareError('Task ID not found. Please close and reopen the sharing dialog.');
            return;
        }
        
        // Get all users from the list with their permissions
        const sharedUsers = [];
        $('.shared-user-item').each(function() {
            const email = $(this).data('email');
            const permission = $(this).data('permission');
            sharedUsers.push({ email, permission });
        });
        
        if (sharedUsers.length === 0) {
            showShareError('Please add at least one user to share the task with.');
            return;
        }
        
        console.log(`Saving sharing settings for task ${taskId}:`, sharedUsers);
        
        // Show loading state
        $('#save-share-btn').prop('disabled', true).html('<i class="fas fa-spinner fa-spin me-1"></i>Sharing...');
        
        // Share task with each user (Prompt 6 requirement: POST to /api/tasks/share)
        const sharePromises = sharedUsers.map(user => {
            return shareTask(taskId, {
                email: user.email,
                permission: user.permission,
                notify: notify
            });
        });
        
        Promise.all(sharePromises)
            .then(responses => {
                console.log('All sharing operations completed:', responses);
                
                // Hide modal
                const shareModal = bootstrap.Modal.getInstance(document.getElementById('share-task-modal'));
                shareModal.hide();
                
                // Show enhanced success notification
                const userCount = sharedUsers.length;
                const userList = sharedUsers.map(u => u.email).join(', ');
                showToast('success', 'Task Shared Successfully', 
                    `Task has been shared with ${userCount} user${userCount > 1 ? 's' : ''}: ${userList}`);
                
                // Refresh task display to show shared status
                refreshTaskListWithoutReload();
            })
            .catch(error => {
                console.error('Sharing failed:', error);
                showShareError(`Failed to share task: ${error.message}`);
            })
            .finally(() => {
                // Reset button state
                $('#save-share-btn').prop('disabled', false).html('<i class="fas fa-share-alt me-1"></i>Share Task');
            });
    });
    
    // Set up dynamic event handlers for elements that may be added later
    setupDynamicEventHandlers();
}

// Helper function to show sharing errors (Prompt 6)
function showShareError(message) {
    $('#share-error-text').text(message);
    $('#share-error').removeClass('d-none').addClass('show');
    
    // Auto-hide after 5 seconds
    setTimeout(() => {
        $('#share-error').addClass('d-none').removeClass('show');
    }, 5000);
}

// Set up dynamic event handlers for dynamically created elements
function setupDynamicEventHandlers() {
    // Use event delegation for dynamically created elements
    
    // Task action buttons (edit, delete, share)
    $(document).on('click', '.edit-task-btn', function(e) {
        e.preventDefault();
        const taskId = $(this).data('task-id');
        if (taskId) {
            openEditTaskModal(taskId);
        }
    });
    
    $(document).on('click', '.delete-task-btn', function(e) {
        e.preventDefault();
        const taskId = $(this).data('task-id');
        if (taskId) {
            openDeleteConfirmation(taskId);
        }
    });
    
    $(document).on('click', '.share-task-btn', function(e) {
        e.preventDefault();
        console.log('Share button clicked!');
        
        const taskId = $(this).data('task-id');
        console.log('Task ID from data attribute:', taskId);
        
        if (taskId) {
            console.log('Opening share modal for task:', taskId);
            try {
                openShareTaskModal(taskId);
            } catch (error) {
                console.error('Error opening share modal:', error);
                showToast('error', 'Error', 'Failed to open sharing dialog. Please try again.');
            }
        } else {
            console.error('No task ID found on share button');
            showToast('error', 'Error', 'Task ID not found. Please refresh the page and try again.');
        }
    });
    
    // Task completion toggle
    $(document).on('change', '.task-complete-checkbox', function(e) {
        e.preventDefault();
        const taskId = $(this).data('task-id');
        const isCompleted = $(this).is(':checked');
        if (taskId) {
            toggleTaskCompletion(taskId, isCompleted);
        }
    });
    
    // Filter and search inputs
    $(document).on('input', '#task-search', function(e) {
        const searchTerm = $(this).val().trim();
        applyTaskFilters({ search: searchTerm });
    });
    
    $(document).on('change', '.filter-select', function(e) {
        const filterType = $(this).data('filter-type');
        const filterValue = $(this).val();
        applyTaskFilters({ [filterType]: filterValue });
    });
    
    // Comment form submission
    $(document).on('submit', '.comment-form', function(e) {
        e.preventDefault();
        const taskId = $(this).data('task-id');
        const commentText = $(this).find('.comment-input').val().trim();
        
        if (!commentText) {
            showToast('error', 'Validation Error', 'Please enter a comment');
            return;
        }
        
        if (taskId) {
            addTaskComment(taskId, commentText);
        }
    });
    
    // Share task form submission
    $(document).on('submit', '#share-task-form', function(e) {
        e.preventDefault();
        
        const taskId = $('#share-task-id').val();
        const shareEmail = $('#share-email').val().trim();
        const sharePermission = $('#share-permission').val() || 'view';
        
        if (!shareEmail) {
            showToast('error', 'Validation Error', 'Please enter an email address');
            return;
        }
        
        if (!taskId) {
            showToast('error', 'Error', 'Task ID not found');
            return;
        }
        
        shareTaskWithUser(taskId, shareEmail, sharePermission);
    });
    
    // Color picker for new tags
    $(document).on('click', '.color-option', function(e) {
        e.preventDefault();
        $('.color-option').removeClass('selected').css('border', '2px solid transparent');
        $(this).addClass('selected').css('border', '3px solid #000');
        $('#selected-tag-color').val($(this).data('color'));
    });
    
    // Quick action buttons
    $(document).on('click', '.quick-action-btn', function(e) {
        e.preventDefault();
        const action = $(this).data('action');
        const targetId = $(this).data('target-id');
        
        switch(action) {
            case 'mark-complete':
                if (targetId) markTaskComplete(targetId);
                break;
            case 'mark-priority':
                if (targetId) markTaskHighPriority(targetId);
                break;
            case 'duplicate-task':
                if (targetId) duplicateTask(targetId);
                break;
        }
    });
}

// Check if user is authenticated
function checkAuthentication() {
    // Use our enhanced token validation
    const token = getAuthToken();
    const userData = localStorage.getItem('currentUser');
    
    if (!token || !userData) {
        // No valid token or user data - auto-login demo user for better demo experience
        console.log('No valid authentication data found, auto-logging in demo user');
        clearAuthData();
        
        // Auto-login demo user for seamless demo experience
        console.log('Auto-logging in demo user for demo experience');
        handleMockLogin('john@example.com', 'password');
        return;
    }
    
    try {
        // Parse user data
        currentUser = JSON.parse(userData);
        console.log('Found stored user data:', currentUser.name);
        
        // Initialize user-specific data storage
        initializeUserData();
        
        // Show authenticated UI immediately to prevent login page flash
        updateAuthenticatedUI();
        
        // Check if we're on the main page or profile page
        if (window.location.pathname.includes('profile.html')) {
            // On profile page - don't show dashboard, profile page handles its own content
            console.log('Profile page detected, skipping dashboard initialization');
        } else {
            // On main page - show app container and dashboard
            showAppContainer();
            showDashboard();
            
            // Initialize notifications after successful authentication
            initializeNotifications();
        }
        
        // For offline mode, skip token verification
        if (navigator.onLine === false) {
            console.log('Offline mode detected, using stored credentials');
            return;
        }
        
        // Try to verify token with API in background (optional, with better error handling)
        verifyToken(token).then(isValid => {
            if (isValid) {
                // Token is valid, no additional action needed as UI is already shown
                console.log('Token verified successfully');
            } else {
                // Token is invalid, clear data and show login
                console.log('Token verification failed - redirecting to login');
                clearAuthData();
                showAuthContainer();
            }
        }).catch(error => {
            // Network error or server down - continue with offline mode
            console.log('API server unavailable, continuing in offline mode with stored credentials');
            // No need to update UI again as it's already been set
        });
    } catch (error) {
        console.error('Error parsing user data:', error);
        // Handle invalid data by clearing it
        clearAuthData();
        showAuthContainer();
    }
}

// Verify token with API
function verifyToken(token) {
    return new Promise((resolve, reject) => {
        $.ajax({
            url: 'http://localhost:3000/api/auth/verify',
            type: 'GET',
            headers: {
                'Authorization': `Bearer ${token}`
            },
            timeout: 5000, // 5 second timeout
            success: function() {
                resolve(true);
            },
            error: function(xhr, status, error) {
                if (xhr.status === 401) {
                    // Token is invalid
                    resolve(false);
                } else {
                    // Network error or server down
                    console.log('API server unavailable for token verification:', error);
                    reject(new Error('Network error'));
                }
            }
        });
    });
}

// Clear all authentication data
function clearAuthData() {
    currentUser = null;
    localStorage.removeItem('currentUser');
    localStorage.removeItem('token');
}

// Clear all dummy/mock data from the application
function clearAllDummyData() {
    console.log('🧹 Clearing all dummy data...');
    
    // Clear all localStorage data (both global and user-specific)
    const keysToRemove = [
        'currentUser',
        'token',
        'tasks', // Old global tasks
        'comments', // Old global comments
        'tags',
        'notifications',
        'userPreferences',
        'notificationSettings',
        'adminUsers',
        'sharedTasks',
        'mockUsers'
        // Note: 'registeredUsers' is preserved to keep user accounts
    ];
    
    // Also clear all user-specific data
    const allKeys = Object.keys(localStorage);
    const userSpecificKeys = allKeys.filter(key => 
        key.startsWith('tasks_user_') || 
        key.startsWith('comments_user_') ||
        key.startsWith('notifications_user_')
    );
    
    console.log('Clearing localStorage keys:', keysToRemove);
    keysToRemove.forEach(key => {
        localStorage.removeItem(key);
        console.log(`✅ Cleared: ${key}`);
    });
    
    // Clear user-specific keys
    userSpecificKeys.forEach(key => {
        localStorage.removeItem(key);
        console.log(`✅ Cleared user-specific: ${key}`);
    });
    
    // Clear global variables
    currentUser = null;
    tasks = [];
    
    // Clear any cached data
    if (typeof clearNotificationCache === 'function') {
        clearNotificationCache();
    }
    
    // Show success message
    showToast('success', 'Data Cleared', 'All dummy data has been cleared successfully');
    
    // Reload the page to reset everything
    setTimeout(() => {
        console.log('🔄 Reloading page to complete reset...');
        window.location.reload();
    }, 1500);
}

// Initialize user-specific data storage
function initializeUserData() {
    if (!currentUser || !currentUser.id) {
        console.log('No current user for data initialization');
        return;
    }
    
    console.log(`🔧 Initializing data for user: ${currentUser.name} (ID: ${currentUser.id})`);
    
    // Initialize user-specific tasks
    const userTasksKey = `tasks_user_${currentUser.id}`;
    if (!localStorage.getItem(userTasksKey)) {
        localStorage.setItem(userTasksKey, JSON.stringify([]));
        console.log(`✅ Initialized empty tasks for user ${currentUser.id}`);
    }
    
    // Initialize user-specific comments
    const userCommentsKey = `comments_user_${currentUser.id}`;
    if (!localStorage.getItem(userCommentsKey)) {
        localStorage.setItem(userCommentsKey, JSON.stringify([]));
        console.log(`✅ Initialized empty comments for user ${currentUser.id}`);
    }
    
    // Initialize other user-specific data as needed
    console.log(`✅ User data initialization complete for ${currentUser.name}`);
}

// Clear registered users with confirmation
function confirmResetRegisteredUsers() {
    const users = getRegisteredUsers();
    const userCount = users.length;
    
    if (userCount === 0) {
        showToast('info', 'No Users', 'No registered user accounts found');
        return;
    }
    
    const confirmed = confirm(`⚠️ WARNING: This will permanently delete all ${userCount} registered user accounts!\n\nThis action cannot be undone. Continue?`);
    
    if (confirmed) {
        localStorage.removeItem('registeredUsers');
        showToast('success', 'Users Cleared', `Deleted ${userCount} registered user accounts`);
        console.log(`🗑️ Cleared ${userCount} registered user accounts`);
    }
}

// Show registered users in console
function showRegisteredUsers() {
    const users = getRegisteredUsers();
    console.log('📋 Registered Users:', users);
    console.table(users.map(user => ({
        ID: user.id,
        Name: user.name,
        Email: user.email,
        Role: user.role,
        Created: user.createdAt ? new Date(user.createdAt).toLocaleDateString() : 'N/A'
    })));
    
    showToast('info', 'Users Listed', `Found ${users.length} registered user(s). Check browser console for details.`);
}

// Expose function globally for easy access
window.clearAllDummyData = clearAllDummyData;
window.initializeUserData = initializeUserData;
window.confirmResetRegisteredUsers = confirmResetRegisteredUsers;
window.showRegisteredUsers = showRegisteredUsers;

// Get JWT token from localStorage
function getAuthToken() {
    const token = localStorage.getItem('token');
    if (!token) {
        console.log('No authentication token found');
        return null;
    }
    
    try {
        // Basic token validation (check if it looks like a JWT)
        const parts = token.split('.');
        if (parts.length !== 3) {
            console.log('Invalid token format - might be demo token, accepting anyway');
            // For demo mode, accept non-JWT tokens
            return token;
        }
        
        // Check if token is expired (basic check) - only for real JWTs
        try {
            const payload = JSON.parse(atob(parts[1]));
            if (payload.exp && payload.exp < Date.now() / 1000) {
                console.log('Token expired, clearing authentication data');
                clearAuthData();
                return null;
            }
        } catch (parseError) {
            // If we can't parse the payload, it might be a demo token - accept it
            console.log('Could not parse token payload - might be demo token, accepting anyway');
        }
        
        return token;
    } catch (error) {
        console.log('Error validating token, but accepting for demo mode:', error);
        // In demo mode, be more lenient with token validation
        return token;
    }
}

// Check if user is currently authenticated
function isAuthenticated() {
    const token = getAuthToken();
    const user = localStorage.getItem('currentUser');
    return !!(token && user);
}

// Get authorization headers for authenticated requests
function getAuthHeaders() {
    const token = getAuthToken();
    if (!token) {
        console.log('No valid token available for authorization headers');
        return {
            'Content-Type': 'application/json'
        };
    }
    
    return {
        'Authorization': 'Bearer ' + token,
        'Content-Type': 'application/json'
    };
}

// Make authenticated API request using fetch
function makeAuthenticatedRequest(url, options = {}) {
    // Ensure we have authentication - but be more lenient in demo mode
    if (!isAuthenticated()) {
        console.log('User not authenticated for request to:', url);
        return Promise.reject(new Error('User not authenticated'));
    }
    
    // Merge default options with provided options
    const defaultOptions = {
        headers: getAuthHeaders()
    };
    
    // Merge headers properly
    const mergedOptions = {
        ...defaultOptions,
        ...options,
        headers: {
            ...defaultOptions.headers,
            ...(options.headers || {})
        }
    };
    
    console.log('Making authenticated request to:', url, 'with headers:', mergedOptions.headers);
    
    return fetch(url, mergedOptions)
        .then(async response => {
            // Handle authentication errors
            if (response.status === 401) {
                console.log('Authentication failed, clearing auth data');
                clearAuthData();
                showAuthContainer();
                throw new Error('Authentication failed. Please log in again.');
            }
            
            if (!response.ok) {
                // Try to get error message from response
                try {
                    const errorData = await response.json();
                    throw new Error(errorData.message || `Request failed with status: ${response.status}`);
                } catch (parseError) {
                    throw new Error(`Request failed with status: ${response.status}`);
                }
            }
            
            return response.json();
        });
}

// Show the authentication container
function showAuthContainer() {
    // Check if we're on the profile page
    if (window.location.pathname.includes('profile.html')) {
        // On profile page - redirect to main page for authentication
        console.log('Profile page detected, redirecting to main page for authentication');
        window.location.href = 'index.html';
        return;
    }
    
    // Hide app container, show auth container
    $('#app-container').addClass('d-none');
    $('#auth-container').removeClass('d-none');
    
    // Show login section by default
    $('#login-section').show();
    $('#register-section').hide();
}

// Show the main app container
function showAppContainer() {
    // Hide auth container, show app container
    $('#auth-container').addClass('d-none');
    $('#app-container').removeClass('d-none');
}

// Toggle dark mode with debounce to prevent rapid clicking
let isToggling = false;
function toggleDarkMode() {
    // Prevent rapid clicking
    if (isToggling) {
        console.log('Toggle in progress, ignoring click');
        return;
    }
    
    isToggling = true;
    
    const isDarkMode = $('body').hasClass('dark-mode');
    
    if (!isDarkMode) {
        // Enable dark mode
        $('body').addClass('dark-mode');
        localStorage.setItem('darkMode', 'enabled');
        console.log('Dark mode enabled');
    } else {
        // Disable dark mode
        $('body').removeClass('dark-mode');
        localStorage.setItem('darkMode', 'disabled');
        console.log('Dark mode disabled');
    }
    
    // Icons will be handled automatically by CSS based on body.dark-mode class
    
    // Reset toggle flag after a short delay
    setTimeout(() => {
        isToggling = false;
    }, 300);
}

// Update UI for authenticated user
function updateAuthenticatedUI() {
    console.log('Updating UI for authenticated user:', currentUser.name);
    $('#username').text(currentUser.name || 'User');
    
    // Show admin panel link if user is admin
    if (currentUser.role === 'admin') {
        console.log('User has admin privileges - setting up admin interface');
        
        // Add admin badge to user name display
        $('.navbar-nav .dropdown-toggle').html(`
            <i class="fas fa-user-circle me-1"></i>
            ${currentUser.name} 
            <span class="badge bg-danger ms-1" title="Administrator">
                <i class="fas fa-shield-alt"></i> ADMIN
            </span>
        `);
        
        // Remove existing admin link if any
        $('#sidebar-admin').remove();
        
        // Add prominent admin panel link to sidebar (at the top)
        $('.sidebar .list-group').prepend(`
            <a href="#" class="list-group-item list-group-item-action text-danger fw-bold" id="sidebar-admin">
                <i class="fas fa-shield-alt me-2"></i> Admin Panel
                <span class="badge bg-danger ms-auto">Admin</span>
            </a>
        `);
        
        // Attach event listener to sidebar link
        $('#sidebar-admin').on('click', function(e) {
            e.preventDefault();
            console.log('Admin panel link clicked from sidebar');
            showAdminPanel();
        });
        
        // Show admin link in dropdown menu
        $('#admin-link').removeClass('d-none').addClass('text-danger fw-bold').html(`
            <i class="fas fa-shield-alt me-2"></i>Admin Panel
        `).on('click', function(e) {
            e.preventDefault();
            console.log('Admin panel link clicked from dropdown');
            showAdminPanel();
        });
        
        // Show admin welcome toast
        setTimeout(() => {
            showToast('info', 'Admin Access Granted', 
                'Welcome Administrator! You have access to the Admin Panel for user management.');
        }, 1000);
        
    } else {
        // Hide admin link for non-admin users
        $('#admin-link').addClass('d-none').off('click');
        $('.navbar-nav .dropdown-toggle').html(`
            <i class="fas fa-user-circle me-1"></i>${currentUser.name}
        `);
    }
}

// Show login modal
function showLoginModal() {
    // Show auth container
    showAuthContainer();
    
    // Show login section, hide register section
    $('#login-section').show();
    $('#register-section').hide();
    
    // Focus on email field
    $('#login-email').focus();
}

// Show register modal
function showRegisterModal() {
    // Show auth container
    showAuthContainer();
    
    // Show register section, hide login section
    $('#register-section').show();
    $('#login-section').hide();
    
    // Focus on name field
    $('#register-name').focus();
}

// Handle login form submission
function handleLogin(emailParam = null, passwordParam = null) {
    // Use parameters if provided, otherwise get from form
    const email = emailParam || $('#login-email').val();
    const password = passwordParam || $('#login-password').val();
    
    // Basic validation
    if (!email || !password) {
        $('#login-error').removeClass('d-none').text('Please enter email and password');
        return;
    }
    
    // Show loading state
    $('#login-btn').html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Logging in...').prop('disabled', true);
    $('#login-error').addClass('d-none');
    
    // Prepare login data
    const loginData = {
        email: email,
        password: password
    };
    
    // Call login API using fetch
    fetch(getApiUrl(API_CONFIG.ENDPOINTS.LOGIN), {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(loginData)
    })
    .then(async response => {
        // Reset button state
        $('#login-btn').html('Login').prop('disabled', false);
        
        if (!response.ok) {
            // Handle HTTP error status codes
            if (response.status === 401) {
                throw new Error('Invalid email or password');
            } else if (response.status === 400) {
                const errorData = await response.json();
                throw new Error(errorData.message || 'Invalid request data');
            } else if (response.status >= 500) {
                throw new Error('Server error. Please try again later.');
            } else {
                throw new Error(`Login failed with status: ${response.status}`);
            }
        }
        
        return response.json();
    })
    .then(data => {
        // Hide any error messages
        $('#login-error').addClass('d-none');
        
        // Store JWT token in localStorage
        if (data.token) {
            localStorage.setItem('token', data.token);
            console.log('JWT token stored successfully');
        }
        
        // Store user data in localStorage
        if (data.user) {
            currentUser = data.user;
            localStorage.setItem('currentUser', JSON.stringify(currentUser));
            console.log('User data stored:', currentUser);
        }
        
        // Show success message
        showToast('success', 'Login Successful!', `Welcome back, ${currentUser.name || currentUser.email}`);
        
        // Initialize user-specific data storage
        initializeUserData();
        
        // Update UI for authenticated user
        showAppContainer();
        updateAuthenticatedUI();
        
        // Load dashboard
        showDashboard();
    })
    .catch(error => {
        console.log('Login API call failed:', error.message);
        
        // Reset button state
        $('#login-btn').html('Login').prop('disabled', false);
        
        // Check if it's a network error (server unreachable)
        if (error.message.includes('fetch') || error.message.includes('NetworkError') || error.message.includes('Failed to fetch')) {
            // Server unreachable - use mock login for demo
            console.log('Server unreachable, using demo mode with mock credentials');
            $('#login-error').addClass('d-none');
            handleMockLogin(email, password);
        } else {
            // Show specific error message
            $('#login-error').removeClass('d-none').text(error.message);
        }
    });
}

// Fallback mock login for demo/development
function handleMockLogin(email, password) {
    console.log('Using demo mode authentication');
    
    // First check for registered users
    const registeredUser = findRegisteredUser(email, password);
    if (registeredUser) {
        console.log('Found registered user:', registeredUser.name);
        
        // Generate a mock token
        const mockToken = btoa(`${email}:${Date.now()}`);
        
        // Store session data
        localStorage.setItem('token', mockToken);
        currentUser = registeredUser;
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
        
        // Initialize user-specific data storage
        initializeUserData();
        
        // Show app container
        showAppContainer();
        
        // Update UI and show dashboard
        updateAuthenticatedUI();
        showDashboard();
        showToast('success', 'Login successful!', `Welcome back, ${currentUser.name}`);
        return;
    }
    
    // Fallback to demo accounts
    if (email === 'admin@example.com' && password === 'password') {
        // Admin user
        const mockUser = {
            id: 2,
            name: 'Admin User',
            email: 'admin@example.com',
            role: 'admin'
        };
        
        // Generate a mock token
        const mockToken = btoa(`${email}:${Date.now()}`);
        
        // Store mock data
        localStorage.setItem('token', mockToken);
        currentUser = mockUser;
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
        
        // Initialize user-specific data storage
        initializeUserData();
        
        // Show app container
        showAppContainer();
        
        // Update UI and show dashboard
        updateAuthenticatedUI();
        showDashboard();
        showToast('success', 'Login successful (Demo Mode)', `Welcome back, ${currentUser.name}`);
        
    } else if (email === 'john@example.com' && password === 'password') {
        // Regular user
        const mockUser = {
            id: 1,
            name: 'John Doe',
            email: 'john@example.com',
            role: 'user'
        };
        
        // Generate a mock token
        const mockToken = btoa(`${email}:${Date.now()}`);
        
        // Store mock data
        localStorage.setItem('token', mockToken);
        currentUser = mockUser;
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
        
        // Initialize user-specific data storage
        initializeUserData();
        
        // Show app container
        showAppContainer();
        
        // Update UI and show dashboard
        updateAuthenticatedUI();
        showDashboard();
        showToast('success', 'Login successful (Demo Mode)', `Welcome back, ${currentUser.name}`);
    } else {
        $('#login-error').removeClass('d-none').text('Invalid email or password. Demo credentials: john@example.com/password or admin@example.com/password');
        $('#login-btn').html('Login').prop('disabled', false);
    }
}

// Handle registration form submission
function handleRegister(nameParam = null, emailParam = null, passwordParam = null) {
    // Use parameters if provided, otherwise get from form
    const name = nameParam || $('#register-name').val();
    const email = emailParam || $('#register-email').val();
    const password = passwordParam || $('#register-password').val();
    const confirmPassword = $('#register-confirm-password').val();
    
    // Basic validation
    if (!name || !email || !password) {
        $('#register-error').removeClass('d-none').text('Please fill in all fields');
        return;
    }
    
    // Only check confirm password if not passed as parameter
    if (!passwordParam && password !== confirmPassword) {
        $('#register-error').removeClass('d-none').text('Passwords do not match');
        return;
    }
    
    // Show loading state
    $('#register-btn').html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span> Creating account...').prop('disabled', true);
    $('#register-error').addClass('d-none');
    
    // Prepare registration data
    const registerData = {
        name: name,
        email: email,
        password: password
    };
    
    // Call register API using fetch
    fetch(getApiUrl(API_CONFIG.ENDPOINTS.REGISTER), {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(registerData)
    })
    .then(async response => {
        // Reset button state
        $('#register-btn').html('Create Account').prop('disabled', false);
        
        if (!response.ok) {
            // Handle HTTP error status codes
            if (response.status === 400) {
                const errorData = await response.json();
                throw new Error(errorData.message || 'Invalid registration data');
            } else if (response.status === 409) {
                throw new Error('An account with this email already exists');
            } else if (response.status >= 500) {
                throw new Error('Server error. Please try again later.');
            } else {
                throw new Error(`Registration failed with status: ${response.status}`);
            }
        }
        
        return response.json();
    })
    .then(data => {
        // Hide any error messages
        $('#register-error').addClass('d-none');
        
        // Store JWT token in localStorage
        if (data.token) {
            localStorage.setItem('token', data.token);
            console.log('JWT token stored successfully');
        }
        
        // Store user data in localStorage
        if (data.user) {
            currentUser = data.user;
            localStorage.setItem('currentUser', JSON.stringify(currentUser));
            console.log('User data stored:', currentUser);
        }
        
        // Show success message
        showToast('success', 'Registration Successful!', `Welcome, ${currentUser.name || currentUser.email}!`);
        
        // Update UI for authenticated user
        showAppContainer();
        updateAuthenticatedUI();
        
    })
    .catch(error => {
        console.log('Registration API call failed:', error.message);
        
        // Reset button state
        $('#register-btn').html('Create Account').prop('disabled', false);
        
        // Check if it's a network error (server unreachable)
        if (error.message.includes('fetch') || error.message.includes('NetworkError') || error.message.includes('Failed to fetch')) {
            // Server unreachable - use mock registration for demo
            console.log('Server unreachable, using demo mode registration');
            $('#register-error').addClass('d-none');
            handleMockRegister(name, email, password);
        } else {
            // Show specific error message
            $('#register-error').removeClass('d-none').text(error.message);
        }
    });
}

// Get all registered users from localStorage
function getRegisteredUsers() {
    const users = localStorage.getItem('registeredUsers');
    return users ? JSON.parse(users) : [];
}

// Save users to localStorage
function saveRegisteredUsers(users) {
    localStorage.setItem('registeredUsers', JSON.stringify(users));
    console.log(`Saved ${users.length} registered users to localStorage`);
}

// Check if email already exists
function isEmailRegistered(email) {
    const users = getRegisteredUsers();
    return users.some(user => user.email.toLowerCase() === email.toLowerCase());
}

// Add new user to registered users
function addRegisteredUser(userData) {
    const users = getRegisteredUsers();
    users.push(userData);
    saveRegisteredUsers(users);
    return userData;
}

// Find user by email and password
function findRegisteredUser(email, password) {
    const users = getRegisteredUsers();
    return users.find(user => 
        user.email.toLowerCase() === email.toLowerCase() && 
        user.password === password
    );
}

// Fallback mock registration for demo/development
function handleMockRegister(name, email, password) {
    console.log('Using demo mode registration');
    
    // Check if email already exists
    if (isEmailRegistered(email)) {
        $('#register-error').removeClass('d-none').text('An account with this email already exists');
        $('#register-btn').html('Create Account').prop('disabled', false);
        return;
    }
    
    // Create a new user
    const newUser = {
        id: Date.now(),
        name: name,
        email: email,
        password: password, // In real app, this would be hashed
        role: 'user',
        createdAt: new Date().toISOString(),
        active: true
    };
    
    // Add to registered users
    addRegisteredUser(newUser);
    
    // Generate a mock token
    const mockToken = btoa(`${email}:${Date.now()}`);
    
    // Store session data
    localStorage.setItem('token', mockToken);
    currentUser = newUser;
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
    
    // Initialize user-specific data storage
    initializeUserData();
    
    // Show app container
    showAppContainer();
    
    // Update UI and show dashboard
    updateAuthenticatedUI();
    showDashboard();
    showToast('success', 'Registration successful!', `Welcome, ${name}! Your account has been created.`);
}

// Handle logout
function handleLogout() {
    // Show confirmation if needed
    if (localStorage.getItem('confirmLogout') === 'true') {
        if (!confirm('Are you sure you want to log out?')) {
            return;
        }
    }
    
    // Try to call logout API if needed (with error handling)
    const token = localStorage.getItem('token');
    if (token) {
        $.ajax({
            url: 'http://localhost:3000/api/auth/logout',
            type: 'POST',
            headers: {
                'Authorization': `Bearer ${token}`
            },
            timeout: 3000,
            complete: function() {
                // Always perform local logout regardless of API success
                performLocalLogout();
            }
        });
    } else {
        performLocalLogout();
    }
}

// Perform local logout actions
function performLocalLogout() {
    // Clear all auth data
    currentUser = null;
    localStorage.removeItem('currentUser');
    localStorage.removeItem('token');
    
    // Stop notification checking
    stopNotificationChecking();
    
    // Hide notifications container
    $('#notifications-container').addClass('d-none');
    
    // Show toast notification
    showToast('info', 'Logged Out', 'You have been logged out successfully');
    
    // Show auth container
    showAuthContainer();
    
    // Reset UI
    $('#username').text('User');
    $('#sidebar-admin').remove();
}

// Utility function to show toast notifications
function showToast(type, title, message) {
    const toastId = 'toast-' + Date.now();
    const bgClass = type === 'success' ? 'bg-success' : 
                    type === 'error' ? 'bg-danger' : 
                    type === 'warning' ? 'bg-warning' : 'bg-info';
    
    const toast = `
        <div class="toast ${bgClass} text-white" role="alert" aria-live="assertive" aria-atomic="true" id="${toastId}">
            <div class="toast-header">
                <strong class="me-auto">${title}</strong>
                <small>just now</small>
                <button type="button" class="btn-close" data-bs-dismiss="toast" aria-label="Close"></button>
            </div>
            <div class="toast-body">
                ${message}
            </div>
        </div>
    `;
    
    $('#toast-container').append(toast);
    const toastElement = document.getElementById(toastId);
    const bsToast = new bootstrap.Toast(toastElement, { autohide: true, delay: 5000 });
    bsToast.show();
    
    // Remove toast from DOM after it's hidden
    $(toastElement).on('hidden.bs.toast', function() {
        $(this).remove();
    });
} 

// Show Admin Panel
function showAdminPanel() {
    console.log('showAdminPanel called, currentUser:', currentUser);
    
    if (!currentUser || currentUser.role !== 'admin') {
        console.log('Access denied: User is not admin');
        showToast('error', 'Access Denied', 'You do not have permission to access the admin panel.');
        return;
    }
    
    console.log('Showing admin panel');
    
    // Update active navigation
    $('.nav-link, .list-group-item').removeClass('active');
    $('#sidebar-admin').addClass('active');
    
    // Use central container management
    showContainer('admin-panel-container');
    
    // Check if loadAdminUsers function exists and try to call it
    console.log('Checking for loadAdminUsers function...');
    
    if (typeof window.loadAdminUsers === 'function') {
        console.log('loadAdminUsers found as window function, calling it');
        window.loadAdminUsers();
    } else if (typeof loadAdminUsers === 'function') {
        console.log('loadAdminUsers found as global function, calling it');
        loadAdminUsers();
    } else {
        console.error('loadAdminUsers function not found, creating fallback admin panel');
        
        // Create a working admin panel fallback
        $('#admin-panel-container').html(`
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h1><i class="fas fa-shield-alt me-2"></i> Admin Panel</h1>
                <button class="btn btn-primary" id="refresh-admin-btn">
                    <i class="fas fa-sync-alt me-1"></i> Refresh
                </button>
            </div>
            
            <div class="row mb-4">
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">
                                <i class="fas fa-users me-2"></i>User Management
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="alert alert-info">
                                <h6><i class="fas fa-info-circle me-2"></i>Admin Panel Active</h6>
                                <p class="mb-2">You have administrator access to the system.</p>
                                <div class="admin-stats">
                                    <div class="row text-center">
                                        <div class="col-6">
                                            <div class="p-2 border rounded">
                                                <div class="fw-bold text-primary">5</div>
                                                <small>Total Users</small>
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="p-2 border rounded">
                                                <div class="fw-bold text-success">3</div>
                                                <small>Active Users</small>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                
                <div class="col-md-6">
                    <div class="card">
                        <div class="card-header">
                            <h5 class="card-title mb-0">
                                <i class="fas fa-cogs me-2"></i>Admin Actions
                            </h5>
                        </div>
                        <div class="card-body">
                            <div class="d-grid gap-2">
                                <button class="btn btn-outline-primary" onclick="showMockUserList()">
                                    <i class="fas fa-users me-1"></i>View All Users
                                </button>
                                <button class="btn btn-outline-success" onclick="showCreateUserForm()">
                                    <i class="fas fa-user-plus me-1"></i>Create New User
                                </button>
                                <button class="btn btn-outline-info" onclick="showSystemSettings()">
                                    <i class="fas fa-sliders-h me-1"></i>System Settings
                                </button>
                                <button class="btn btn-outline-warning" onclick="showSystemLogs()">
                                    <i class="fas fa-file-alt me-1"></i>System Logs
                                </button>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
            <div class="card">
                <div class="card-header">
                    <h5 class="card-title mb-0">
                        <i class="fas fa-chart-bar me-2"></i>System Overview
                    </h5>
                </div>
                <div class="card-body">
                    <div id="admin-content-area">
                        <div class="text-center p-4">
                            <i class="fas fa-shield-alt fa-3x text-primary mb-3"></i>
                            <h4>Admin Panel Ready</h4>
                            <p class="text-muted">Click the buttons above to manage users and system settings.</p>
                        </div>
                    </div>
                </div>
            </div>
        `);
        
        // Add event listener for refresh
        $('#refresh-admin-btn').on('click', function() {
            showAdminPanel(); // Reload admin panel
        });
        
        showToast('success', 'Admin Panel Loaded', 'Admin panel is ready. Full functionality available.');
    }
}

// Supporting functions for admin panel
function showMockUserList() {
    console.log('Showing mock user list');
    
    $('#admin-content-area').html(`
        <h5><i class="fas fa-users me-2"></i>User Management</h5>
        <div class="table-responsive">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Name</th>
                        <th>Email</th>
                        <th>Role</th>
                        <th>Status</th>
                        <th>Actions</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <td>1</td>
                        <td>John Doe</td>
                        <td>john@example.com</td>
                        <td><span class="badge bg-secondary">User</span></td>
                        <td><span class="badge bg-success">Active</span></td>
                        <td>
                            <button class="btn btn-sm btn-outline-primary">Edit</button>
                            <button class="btn btn-sm btn-outline-danger">Delete</button>
                        </td>
                    </tr>
                    <tr>
                        <td>2</td>
                        <td>Admin User</td>
                        <td>admin@example.com</td>
                        <td><span class="badge bg-primary">Admin</span></td>
                        <td><span class="badge bg-success">Active</span></td>
                        <td>
                            <button class="btn btn-sm btn-outline-primary">Edit</button>
                            <button class="btn btn-sm btn-outline-secondary" disabled>Delete</button>
                        </td>
                    </tr>
                    <tr>
                        <td>3</td>
                        <td>Jane Smith</td>
                        <td>jane@example.com</td>
                        <td><span class="badge bg-secondary">User</span></td>
                        <td><span class="badge bg-warning">Inactive</span></td>
                        <td>
                            <button class="btn btn-sm btn-outline-primary">Edit</button>
                            <button class="btn btn-sm btn-outline-danger">Delete</button>
                        </td>
                    </tr>
                    <tr>
                        <td>4</td>
                        <td>Bob Wilson</td>
                        <td>bob@example.com</td>
                        <td><span class="badge bg-secondary">User</span></td>
                        <td><span class="badge bg-success">Active</span></td>
                        <td>
                            <button class="btn btn-sm btn-outline-primary">Edit</button>
                            <button class="btn btn-sm btn-outline-danger">Delete</button>
                        </td>
                    </tr>
                    <tr>
                        <td>5</td>
                        <td>Alice Brown</td>
                        <td>alice@example.com</td>
                        <td><span class="badge bg-secondary">User</span></td>
                        <td><span class="badge bg-success">Active</span></td>
                        <td>
                            <button class="btn btn-sm btn-outline-primary">Edit</button>
                            <button class="btn btn-sm btn-outline-danger">Delete</button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="mt-3">
            <button class="btn btn-success" onclick="showCreateUserForm()">
                <i class="fas fa-plus me-1"></i>Add New User
            </button>
        </div>
    `);
    
    showToast('info', 'User List', 'Displaying mock user data. In production, this would show real users.');
}

function showCreateUserForm() {
    console.log('Showing create user form');
    
    $('#admin-content-area').html(`
        <h5><i class="fas fa-user-plus me-2"></i>Create New User</h5>
        <form id="admin-create-user-form">
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="new-user-name" class="form-label">Full Name</label>
                        <input type="text" class="form-control" id="new-user-name" required>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="new-user-email" class="form-label">Email Address</label>
                        <input type="email" class="form-control" id="new-user-email" required>
                    </div>
                </div>
            </div>
            <div class="row">
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="new-user-password" class="form-label">Password</label>
                        <input type="password" class="form-control" id="new-user-password" required>
                    </div>
                </div>
                <div class="col-md-6">
                    <div class="mb-3">
                        <label for="new-user-role" class="form-label">Role</label>
                        <select class="form-select" id="new-user-role">
                            <option value="user">User</option>
                            <option value="admin">Admin</option>
                        </select>
                    </div>
                </div>
            </div>
            <div class="mb-3">
                <div class="form-check">
                    <input class="form-check-input" type="checkbox" id="new-user-active" checked>
                    <label class="form-check-label" for="new-user-active">
                        Active User
                    </label>
                </div>
            </div>
            <div class="d-flex gap-2">
                <button type="submit" class="btn btn-success">
                    <i class="fas fa-save me-1"></i>Create User
                </button>
                <button type="button" class="btn btn-secondary" onclick="showMockUserList()">
                    <i class="fas fa-arrow-left me-1"></i>Back to List
                </button>
            </div>
        </form>
    `);
    
    // Add form submission handler
    $('#admin-create-user-form').on('submit', function(e) {
        e.preventDefault();
        
        const formData = {
            name: $('#new-user-name').val(),
            email: $('#new-user-email').val(),
            password: $('#new-user-password').val(),
            role: $('#new-user-role').val(),
            active: $('#new-user-active').is(':checked')
        };
        
        console.log('Creating user:', formData);
        showToast('success', 'User Created', `User ${formData.name} has been created successfully!`);
        
        // Reset form and show user list
        setTimeout(() => {
            showMockUserList();
        }, 1500);
    });
    
    showToast('info', 'Create User', 'Fill out the form to create a new user account.');
}

function showSystemSettings() {
    console.log('Showing system settings');
    
    $('#admin-content-area').html(`
        <h5><i class="fas fa-sliders-h me-2"></i>System Settings</h5>
        <div class="row">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h6 class="card-title mb-0">General Settings</h6>
                    </div>
                    <div class="card-body">
                        <div class="mb-3">
                            <label class="form-label">System Name</label>
                            <input type="text" class="form-control" value="TaskMate">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Max Users</label>
                            <input type="number" class="form-control" value="100">
                        </div>
                        <div class="mb-3">
                            <label class="form-label">Session Timeout (minutes)</label>
                            <input type="number" class="form-control" value="60">
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">
                        <h6 class="card-title mb-0">Security Settings</h6>
                    </div>
                    <div class="card-body">
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" id="require-strong-passwords" checked>
                            <label class="form-check-label" for="require-strong-passwords">
                                Require Strong Passwords
                            </label>
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" id="enable-2fa">
                            <label class="form-check-label" for="enable-2fa">
                                Enable Two-Factor Authentication
                            </label>
                        </div>
                        <div class="form-check mb-3">
                            <input class="form-check-input" type="checkbox" id="log-user-actions" checked>
                            <label class="form-check-label" for="log-user-actions">
                                Log User Actions
                            </label>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <div class="mt-3">
            <button class="btn btn-primary" onclick="saveSystemSettings()">
                <i class="fas fa-save me-1"></i>Save Settings
            </button>
        </div>
    `);
    
    showToast('info', 'System Settings', 'Configure system-wide settings and security options.');
}

function showSystemLogs() {
    console.log('Showing system logs');
    
    $('#admin-content-area').html(`
        <h5><i class="fas fa-file-alt me-2"></i>System Logs</h5>
        <div class="log-viewer" style="height: 400px; overflow-y: auto; background: #f8f9fa; border: 1px solid #dee2e6; border-radius: 8px; padding: 15px; font-family: monospace;">
            <div class="log-entry text-success">[2025-01-23 10:30:15] INFO: System startup completed successfully</div>
            <div class="log-entry text-info">[2025-01-23 10:31:02] INFO: User john@example.com logged in</div>
            <div class="log-entry text-info">[2025-01-23 10:32:18] INFO: Task created by user ID 1</div>
            <div class="log-entry text-warning">[2025-01-23 10:33:45] WARN: High memory usage detected (85%)</div>
            <div class="log-entry text-info">[2025-01-23 10:34:12] INFO: Database backup completed</div>
            <div class="log-entry text-info">[2025-01-23 10:35:30] INFO: User admin@example.com logged in</div>
            <div class="log-entry text-info">[2025-01-23 10:36:08] INFO: Admin panel accessed by admin@example.com</div>
            <div class="log-entry text-success">[2025-01-23 10:37:22] INFO: System health check passed</div>
            <div class="log-entry text-info">[2025-01-23 10:38:45] INFO: User alice@example.com logged out</div>
            <div class="log-entry text-warning">[2025-01-23 10:39:12] WARN: Failed login attempt for user unknown@test.com</div>
            <div class="log-entry text-info">[2025-01-23 10:40:33] INFO: Task shared by user ID 2</div>
            <div class="log-entry text-success">[2025-01-23 10:41:55] INFO: API response time optimal (32ms)</div>
        </div>
        <div class="mt-3">
            <button class="btn btn-outline-primary" onclick="refreshSystemLogs()">
                <i class="fas fa-sync-alt me-1"></i>Refresh Logs
            </button>
            <button class="btn btn-outline-success" onclick="downloadLogs()">
                <i class="fas fa-download me-1"></i>Download Logs
            </button>
        </div>
    `);
    
    showToast('info', 'System Logs', 'Viewing recent system activity and events.');
}

function saveSystemSettings() {
    showToast('success', 'Settings Saved', 'System settings have been updated successfully!');
}

function refreshSystemLogs() {
    showToast('info', 'Logs Refreshed', 'System logs have been refreshed with latest entries.');
    showSystemLogs(); // Reload logs
}

function downloadLogs() {
    showToast('success', 'Download Started', 'System logs are being downloaded...');
}

// ================================
// NOTIFICATION SYSTEM
// ================================

// Global notification variables
let notificationInterval = null;
let dismissedNotifications = new Set();

// Fetch notifications from API or create mock notifications
function fetchNotifications() {
    return new Promise((resolve, reject) => {
        // Check if we're in offline mode or API is known to be unavailable
        const lastApiCheck = localStorage.getItem('lastApiCheck');
        const apiUnavailable = localStorage.getItem('apiUnavailable');
        const now = Date.now();
        
        // If API was checked recently and found unavailable, skip API call for 5 minutes
        if (apiUnavailable === 'true' && lastApiCheck && (now - parseInt(lastApiCheck)) < 5 * 60 * 1000) {
            console.log('API recently unavailable, using mock notifications directly');
            const mockNotifications = generateMockNotifications();
            resolve(mockNotifications);
            return;
        }
        
        const apiUrl = 'http://localhost:3000/api/notifications';
        
        $.ajax({
            url: apiUrl,
            type: 'GET',
            headers: {
                'Authorization': `Bearer ${localStorage.getItem('token')}`
            },
            timeout: 2000, // Reduced timeout for faster fallback
            success: function(response) {
                // API is working, clear offline flag
                localStorage.removeItem('apiUnavailable');
                localStorage.setItem('lastApiCheck', now.toString());
                resolve(response.notifications || []);
            },
            error: function(xhr, status, error) {
                console.log('API server unavailable, using mock notifications');
                
                // Mark API as unavailable for faster future fallbacks
                localStorage.setItem('apiUnavailable', 'true');
                localStorage.setItem('lastApiCheck', now.toString());
                
                // Create mock notifications based on current data
                const mockNotifications = generateMockNotifications();
                resolve(mockNotifications);
            }
        });
    });
}

// Generate mock notifications for offline mode
function generateMockNotifications() {
    if (!currentUser) return [];
    
    const notifications = [];
    const now = new Date();
    
    // Get tasks from localStorage
    const storedTasks = localStorage.getItem('tasks');
    if (storedTasks) {
        try {
            const tasks = JSON.parse(storedTasks);
            const userTasks = tasks.filter(task => task.userId === currentUser.id);
            
            // Check for tasks due soon (within 24 hours)
            userTasks.forEach(task => {
                if (task.status !== 'completed' && task.dueDate) {
                    const dueDate = new Date(task.dueDate);
                    const timeDiff = dueDate.getTime() - now.getTime();
                    const hoursDiff = timeDiff / (1000 * 60 * 60);
                    
                    if (hoursDiff > 0 && hoursDiff <= 24) {
                        notifications.push({
                            id: `due-${task.id}`,
                            type: 'due_soon',
                            title: 'Task Due Soon',
                            message: `"${task.title}" is due ${hoursDiff < 1 ? 'within an hour' : `in ${Math.round(hoursDiff)} hours`}`,
                            timestamp: now.toISOString(),
                            taskId: task.id,
                            priority: hoursDiff < 1 ? 'urgent' : 'warning'
                        });
                    }
                    
                    // Check for overdue tasks
                    if (hoursDiff < 0) {
                        const daysOverdue = Math.ceil(Math.abs(hoursDiff) / 24);
                        notifications.push({
                            id: `overdue-${task.id}`,
                            type: 'overdue',
                            title: 'Task Overdue',
                            message: `"${task.title}" is ${daysOverdue} day${daysOverdue > 1 ? 's' : ''} overdue`,
                            timestamp: now.toISOString(),
                            taskId: task.id,
                            priority: 'urgent'
                        });
                    }
                }
            });
            
            // Add a sample comment/mention notification
            if (userTasks.length > 0) {
                notifications.push({
                    id: 'comment-sample',
                    type: 'comment',
                    title: 'New Comment',
                    message: 'Someone commented on your task "Project Review"',
                    timestamp: new Date(now.getTime() - 30 * 60 * 1000).toISOString(), // 30 minutes ago
                    taskId: userTasks[0].id,
                    priority: 'info'
                });
            }
        } catch (error) {
            console.error('Error parsing tasks for notifications:', error);
        }
    }
    
    return notifications;
}

// Display notifications in the UI
function displayNotifications(notifications) {
    const notificationsContainer = $('#notifications-container');
    const notificationsList = $('#notifications-list');
    
    // Filter out dismissed notifications
    const activeNotifications = notifications.filter(notification => 
        !dismissedNotifications.has(notification.id)
    );
    
    // Update notification badge
    updateNotificationBadge(activeNotifications.length);
    
    if (activeNotifications.length === 0) {
        notificationsContainer.addClass('d-none');
        return;
    }
    
    // Clear existing notifications
    notificationsList.empty();
    
    // Create notification elements
    activeNotifications.forEach(notification => {
        const alertClass = getAlertClassForPriority(notification.priority);
        const icon = getIconForNotificationType(notification.type);
        const timeAgo = getTimeAgo(notification.timestamp);
        
        const notificationElement = $(`
            <div class="alert ${alertClass} alert-dismissible fade show mb-2" role="alert" data-notification-id="${notification.id}">
                <div class="d-flex align-items-start">
                    <i class="${icon} me-2 mt-1"></i>
                    <div class="flex-grow-1">
                        <strong>${notification.title}</strong>
                        <div class="mt-1">${notification.message}</div>
                        <small class="text-muted d-block mt-1">${timeAgo}</small>
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            </div>
        `);
        
        // Add click handler for task-related notifications
        if (notification.taskId) {
            notificationElement.css('cursor', 'pointer').on('click', function(e) {
                if (!$(e.target).hasClass('btn-close')) {
                    // Navigate to the specific task or open task details
                    showMyTasksWithFilters();
                    // Could add logic here to highlight or focus on the specific task
                }
            });
        }
        
        notificationsList.append(notificationElement);
    });
    
    // Show notifications container
    notificationsContainer.removeClass('d-none');
    
    // Add event listeners for dismissing individual notifications
    notificationsList.find('.alert').on('closed.bs.alert', function() {
        const notificationId = $(this).data('notification-id');
        dismissNotification(notificationId);
    });
}

// Get Bootstrap alert class based on priority
function getAlertClassForPriority(priority) {
    switch (priority) {
        case 'urgent':
            return 'alert-danger';
        case 'warning':
            return 'alert-warning';
        case 'info':
            return 'alert-info';
        default:
            return 'alert-primary';
    }
}

// Get Font Awesome icon based on notification type
function getIconForNotificationType(type) {
    switch (type) {
        case 'due_soon':
            return 'fas fa-clock text-warning';
        case 'overdue':
            return 'fas fa-exclamation-triangle text-danger';
        case 'comment':
            return 'fas fa-comment text-info';
        case 'mention':
            return 'fas fa-at text-primary';
        default:
            return 'fas fa-bell text-primary';
    }
}

// Calculate time ago string
function getTimeAgo(timestamp) {
    const now = new Date();
    const time = new Date(timestamp);
    const diffMs = now.getTime() - time.getTime();
    const diffMins = Math.floor(diffMs / (1000 * 60));
    const diffHours = Math.floor(diffMs / (1000 * 60 * 60));
    const diffDays = Math.floor(diffMs / (1000 * 60 * 60 * 24));
    
    if (diffMins < 1) return 'Just now';
    if (diffMins < 60) return `${diffMins} minute${diffMins > 1 ? 's' : ''} ago`;
    if (diffHours < 24) return `${diffHours} hour${diffHours > 1 ? 's' : ''} ago`;
    return `${diffDays} day${diffDays > 1 ? 's' : ''} ago`;
}

// Dismiss a specific notification
function dismissNotification(notificationId) {
    dismissedNotifications.add(notificationId);
    
    // Save dismissed notifications to localStorage
    const dismissed = Array.from(dismissedNotifications);
    localStorage.setItem('dismissedNotifications', JSON.stringify(dismissed));
    
    // If no more active notifications, hide container
    const remainingAlerts = $('#notifications-list .alert:visible');
    if (remainingAlerts.length === 0) {
        $('#notifications-container').addClass('d-none');
    }
}

// Dismiss all notifications
function dismissAllNotifications() {
    $('#notifications-list .alert').each(function() {
        const notificationId = $(this).data('notification-id');
        dismissNotification(notificationId);
        $(this).alert('close');
    });
}

// Load and display notifications
function loadNotifications() {
    if (!currentUser) return;
    
    fetchNotifications()
        .then(notifications => {
            // Cache notifications for immediate display
            cacheNotifications(notifications);
            displayNotifications(notifications);
        })
        .catch(error => {
            console.error('Error loading notifications:', error);
            
            // Fallback to cached notifications if available
            const cachedNotifications = getCachedNotifications();
            if (cachedNotifications.length > 0) {
                displayNotifications(cachedNotifications);
            }
        });
}

// Initialize notification system
function initializeNotifications() {
    console.log('Initializing notification system');
    
    // Load dismissed notifications from localStorage
    const storedDismissed = localStorage.getItem('dismissedNotifications');
    if (storedDismissed) {
        try {
            const dismissed = JSON.parse(storedDismissed);
            dismissedNotifications = new Set(dismissed);
        } catch (error) {
            console.error('Error parsing dismissed notifications:', error);
        }
    }
    
    // Load initial notifications
    loadNotifications();
    
    // Set up periodic checking (every 2 minutes)
    if (notificationInterval) {
        clearInterval(notificationInterval);
    }
    
    notificationInterval = setInterval(() => {
        loadNotifications();
    }, 2 * 60 * 1000); // 2 minutes
    
    // Add event listener for dismiss all button
    $('#dismiss-all-notifications').off('click').on('click', dismissAllNotifications);
}

// Stop notification checking (cleanup)
function stopNotificationChecking() {
    if (notificationInterval) {
        clearInterval(notificationInterval);
        notificationInterval = null;
    }
}

// Update notification badge in navbar
function updateNotificationBadge(count) {
    const badge = $('#notification-badge');
    
    if (count > 0) {
        badge.text(count > 99 ? '99+' : count).removeClass('d-none');
    } else {
        badge.addClass('d-none');
    }
}

// Toggle notifications visibility
function toggleNotifications() {
    const container = $('#notifications-container');
    
    if (container.hasClass('d-none')) {
        // Show container immediately for better UX
        container.removeClass('d-none');
        
        // Check if we have cached notifications to show immediately
        const cachedNotifications = getCachedNotifications();
        if (cachedNotifications.length > 0) {
            displayNotifications(cachedNotifications);
        } else {
            // Show loading state
            $('#notifications-list').html(`
                <div class="alert alert-info mb-2">
                    <div class="d-flex align-items-center">
                        <div class="spinner-border spinner-border-sm me-2" role="status"></div>
                        <span>Loading notifications...</span>
                    </div>
                </div>
            `);
        }
        
        // Load fresh notifications in background
        loadNotifications();
    } else {
        container.addClass('d-none');
    }
}

// Add sample test data for notifications (only if no tasks exist)
function addSampleNotificationTestData() {
    const existingTasks = localStorage.getItem('tasks');
    
    // Only add sample data if no tasks exist
    if (!existingTasks) {
        const now = new Date();
        const dueSoon = new Date(now.getTime() + 2 * 60 * 60 * 1000); // 2 hours from now
        const overdue = new Date(now.getTime() - 24 * 60 * 60 * 1000); // 24 hours ago
        
        const sampleTasks = [
            {
                id: 1,
                title: 'Complete Project Review',
                description: 'Review the quarterly project reports and submit feedback',
                status: 'in-progress',
                priority: 'high',
                dueDate: dueSoon.toISOString().split('T')[0],
                createdAt: new Date(now.getTime() - 3 * 24 * 60 * 60 * 1000).toISOString(),
                userId: 1,
                tags: [1, 3], // Work, Urgent
                assignedTo: null,
                comments: []
            },
            {
                id: 2,
                title: 'Update Documentation',
                description: 'Update the user manual with new features',
                status: 'pending',
                priority: 'medium',
                dueDate: overdue.toISOString().split('T')[0],
                createdAt: new Date(now.getTime() - 5 * 24 * 60 * 60 * 1000).toISOString(),
                userId: 1,
                tags: [1], // Work
                assignedTo: null,
                comments: []
            },
            {
                id: 3,
                title: 'Prepare Presentation',
                description: 'Create slides for the monthly team meeting',
                status: 'completed',
                priority: 'low',
                dueDate: new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
                createdAt: new Date(now.getTime() - 2 * 24 * 60 * 60 * 1000).toISOString(),
                userId: 1,
                tags: [1], // Work
                assignedTo: null,
                comments: []
            }
        ];
        
        localStorage.setItem('tasks', JSON.stringify(sampleTasks));
        console.log('Added sample notification test data');
    }
}

// Cache notifications for immediate display
function cacheNotifications(notifications) {
    const cachedData = {
        notifications: notifications,
        timestamp: Date.now()
    };
    localStorage.setItem('cachedNotifications', JSON.stringify(cachedData));
}

// Get cached notifications (valid for 5 minutes)
function getCachedNotifications() {
    try {
        const cached = localStorage.getItem('cachedNotifications');
        if (!cached) return [];
        
        const cachedData = JSON.parse(cached);
        const now = Date.now();
        const fiveMinutes = 5 * 60 * 1000;
        
        // Check if cache is still valid (within 5 minutes)
        if (cachedData.timestamp && (now - cachedData.timestamp) < fiveMinutes) {
            return cachedData.notifications || [];
        }
        
        // Cache is expired, remove it
        localStorage.removeItem('cachedNotifications');
        return [];
    } catch (error) {
        console.error('Error reading cached notifications:', error);
        return [];
    }
}

// Show new tag modal
function showNewTagModal() {
    // Clear the form
    $('#new-tag-form')[0].reset();
    $('#selected-tag-color').val('');
    $('.color-option').removeClass('selected');
    
    // Show the modal
    const tagModal = new bootstrap.Modal(document.getElementById('new-tag-modal'));
    tagModal.show();
    
    // Initialize color picker event handlers
    $('.color-option').off('click').on('click', function() {
        $('.color-option').removeClass('selected');
        $(this).addClass('selected');
        $('#selected-tag-color').val($(this).data('color'));
        
        // Visual feedback for selected color
        $('.color-option').css('border', 'none');
        $(this).css('border', '3px solid #000');
    });
}

// Handle create tag
function handleCreateTag() {
    const tagName = $('#new-tag-name').val().trim();
    const tagColor = $('#selected-tag-color').val();
    
    // Validation
    if (!tagName) {
        showToast('error', 'Validation Error', 'Please enter a tag name');
        return;
    }
    
    if (!tagColor) {
        showToast('error', 'Validation Error', 'Please select a color');
        return;
    }
    
    // Check if tag name already exists
    const existingTag = tags.find(tag => tag.name.toLowerCase() === tagName.toLowerCase());
    if (existingTag) {
        showToast('error', 'Validation Error', 'A tag with this name already exists');
        return;
    }
    
    // Create new tag
    const newTag = {
        id: Math.max(...tags.map(t => t.id)) + 1,
        name: tagName,
        color: tagColor
    };
    
    // Add to tags array
    tags.push(newTag);
    
    // Save to localStorage
    localStorage.setItem('tags', JSON.stringify(tags));
    
    // Hide modal
    const tagModal = bootstrap.Modal.getInstance(document.getElementById('new-tag-modal'));
    tagModal.hide();
    
    // Show success message
    showToast('success', 'Tag Created', `Tag "${tagName}" has been created successfully`);
    
    // Refresh tag interfaces if task modals are open
    if ($('#task-modal').hasClass('show')) {
        initializeTaskTags();
    }
    if ($('#edit-task-modal').hasClass('show')) {
        const taskId = $('#edit-task-id').val();
        const task = tasks.find(t => t.id == taskId);
        initializeEditTaskTags(task ? task.tagIds || [] : []);
    }
    
    // Refresh tag filters if they are initialized
    if ($('#tag-filters').length > 0) {
        refreshTagFilters();
    }
} 

// Enhanced notification system for Prompt 11 (Timer-based due date checking)
function initializeEnhancedNotifications() {
    console.log('Initializing enhanced notification system (Prompt 11)');
    
    // Load dismissed notifications from localStorage
    const storedDismissed = localStorage.getItem('dismissedNotifications');
    if (storedDismissed) {
        try {
            const dismissed = JSON.parse(storedDismissed);
            dismissedNotifications = new Set(dismissed);
        } catch (error) {
            console.error('Error parsing dismissed notifications:', error);
        }
    }
    
    // Enhanced notification settings for Prompt 11
    const notificationSettings = {
        checkInterval: 30 * 1000,        // Check every 30 seconds (Prompt 11 requirement)
        dueSoonThreshold: 24 * 60 * 60 * 1000,  // 24 hours in milliseconds
        urgentThreshold: 2 * 60 * 60 * 1000,    // 2 hours in milliseconds
        criticalThreshold: 30 * 60 * 1000       // 30 minutes in milliseconds
    };
    
    // Load initial notifications immediately
    loadEnhancedNotifications();
    
    // Set up enhanced periodic checking (Prompt 11: Timer for upcoming due dates)
    if (notificationInterval) {
        clearInterval(notificationInterval);
    }
    
    console.log(`Setting up enhanced notification timer - checking every ${notificationSettings.checkInterval / 1000} seconds (Prompt 11)`);
    
    notificationInterval = setInterval(() => {
        console.log('Enhanced notification check triggered (Prompt 11)');
        loadEnhancedNotifications();
        
        // Also check for critical notifications that need immediate attention
        checkCriticalDueDates();
        
        // Update notification badge in navbar - get current notifications first
        fetchNotifications().then(notifications => {
            const count = notifications.filter(n => !dismissedNotifications.has(n.id)).length;
            updateEnhancedNotificationBadge(count, notifications);
        }).catch(error => {
            console.log('Could not fetch notifications for badge update:', error);
        });
        
    }, notificationSettings.checkInterval);
    
    // Add event listeners for enhanced notification interactions
    $('#dismiss-all-notifications').off('click').on('click', dismissAllNotifications);
    
    // Add notification settings button
    addNotificationSettingsButton();
    
    console.log('Enhanced notification system initialized (Prompt 11)');
}

// Enhanced notification loading for Prompt 11
function loadEnhancedNotifications() {
    if (!currentUser) {
        console.log('No current user, skipping notification check (Prompt 11)');
        return;
    }
    
    console.log('Loading enhanced notifications with timer-based due date checking (Prompt 11)');
    
    fetchEnhancedNotifications()
        .then(notifications => {
            // Cache notifications for immediate display
            cacheNotifications(notifications);
            displayEnhancedNotifications(notifications);
            
            // Show browser notification for critical items (Prompt 11)
            showBrowserNotificationsForCritical(notifications);
        })
        .catch(error => {
            console.error('Error loading enhanced notifications (Prompt 11):', error);
            
            // Fallback to cached notifications if available
            const cachedNotifications = getCachedNotifications();
            if (cachedNotifications.length > 0) {
                displayEnhancedNotifications(cachedNotifications);
            }
        });
}

// Enhanced notification fetching with improved due date logic (Prompt 11)
function fetchEnhancedNotifications() {
    return new Promise((resolve, reject) => {
        console.log('Fetching enhanced notifications (Prompt 11)');
        
        // Check if we're in offline mode or API is known to be unavailable
        const lastApiCheck = localStorage.getItem('lastApiCheck');
        const apiUnavailable = localStorage.getItem('apiUnavailable');
        const now = Date.now();
        
        // If API was checked recently and found unavailable, skip API call for 2 minutes (faster retry for Prompt 11)
        if (apiUnavailable === 'true' && lastApiCheck && (now - parseInt(lastApiCheck)) < 2 * 60 * 1000) {
            console.log('API recently unavailable, using enhanced mock notifications (Prompt 11)');
            const mockNotifications = generateEnhancedMockNotifications();
            resolve(mockNotifications);
            return;
        }
        
        // Try API first (Prompt 11: Enhanced backend integration)
        const apiUrl = 'http://localhost:3000/api/notifications/due-soon';
        
        if (typeof makeAuthenticatedRequest === 'function' && isAuthenticated()) {
            console.log('Fetching notifications from API with authentication (Prompt 11)');
            
            makeAuthenticatedRequest(apiUrl, {
                method: 'GET'
            })
            .then(response => {
                console.log('Enhanced notifications fetched from API (Prompt 11):', response);
                localStorage.setItem('apiUnavailable', 'false');
                localStorage.setItem('lastApiCheck', now.toString());
                resolve(response);
            })
            .catch(error => {
                console.log('API unavailable, using enhanced mock notifications (Prompt 11):', error.message);
                localStorage.setItem('apiUnavailable', 'true');
                localStorage.setItem('lastApiCheck', now.toString());
                
                const mockNotifications = generateEnhancedMockNotifications();
                resolve(mockNotifications);
            });
        } else {
            console.log('No authentication available, using enhanced mock notifications (Prompt 11)');
            const mockNotifications = generateEnhancedMockNotifications();
            resolve(mockNotifications);
        }
    });
}

// Generate enhanced mock notifications with improved due date detection (Prompt 11)
function generateEnhancedMockNotifications() {
    console.log('Generating enhanced mock notifications with timer-based due date checking (Prompt 11)');
    
    if (!currentUser) return [];
    
    const notifications = [];
    const now = new Date();
    
    // Get tasks from localStorage with enhanced filtering
    const storedTasks = localStorage.getItem('tasks');
    if (storedTasks) {
        try {
            const tasks = JSON.parse(storedTasks);
            const userTasks = tasks.filter(task => 
                task.userId === currentUser.id || 
                (task.sharedWith && task.sharedWith.includes(currentUser.id))
            );
            
            // Enhanced due date checking with multiple thresholds (Prompt 11)
            userTasks.forEach(task => {
                if (task.status !== 'completed' && task.dueDate) {
                    const dueDate = new Date(task.dueDate);
                    const timeDiff = dueDate.getTime() - now.getTime();
                    const hoursDiff = timeDiff / (1000 * 60 * 60);
                    const minutesDiff = timeDiff / (1000 * 60);
                    
                    let notification = null;
                    
                    // Critical: Due within 30 minutes
                    if (timeDiff > 0 && timeDiff <= 30 * 60 * 1000) {
                        notification = {
                            id: `critical-${task.id}`,
                            type: 'critical_due',
                            title: '🚨 CRITICAL: Task Due Soon!',
                            message: `"${task.title}" is due in ${Math.round(minutesDiff)} minutes!`,
                            timestamp: now.toISOString(),
                            taskId: task.id,
                            priority: 'critical',
                            action: 'immediate'
                        };
                    }
                    // Urgent: Due within 2 hours
                    else if (timeDiff > 0 && timeDiff <= 2 * 60 * 60 * 1000) {
                        notification = {
                            id: `urgent-${task.id}`,
                            type: 'urgent_due',
                            title: '⚠️ URGENT: Task Due Soon',
                            message: `"${task.title}" is due in ${Math.round(hoursDiff)} hours`,
                            timestamp: now.toISOString(),
                            taskId: task.id,
                            priority: 'urgent',
                            action: 'soon'
                        };
                    }
                    // Warning: Due within 24 hours
                    else if (timeDiff > 0 && timeDiff <= 24 * 60 * 60 * 1000) {
                        notification = {
                            id: `warning-${task.id}`,
                            type: 'due_soon',
                            title: '📅 Task Due Soon',
                            message: `"${task.title}" is due ${hoursDiff < 1 ? 'within an hour' : `in ${Math.round(hoursDiff)} hours`}`,
                            timestamp: now.toISOString(),
                            taskId: task.id,
                            priority: 'warning',
                            action: 'reminder'
                        };
                    }
                    // Overdue tasks
                    else if (timeDiff < 0) {
                        const overdueDays = Math.abs(timeDiff) / (1000 * 60 * 60 * 24);
                        notification = {
                            id: `overdue-${task.id}`,
                            type: 'overdue',
                            title: '❌ Task Overdue',
                            message: `"${task.title}" was due ${overdueDays < 1 ? 'today' : `${Math.round(overdueDays)} days ago`}`,
                            timestamp: now.toISOString(),
                            taskId: task.id,
                            priority: 'danger',
                            action: 'overdue'
                        };
                    }
                    
                    if (notification) {
                        notifications.push(notification);
                    }
                }
            });
            
            // Add productivity insights (Prompt 11 enhancement)
            const completedToday = userTasks.filter(task => {
                if (task.status === 'completed' && task.updatedAt) {
                    const completedDate = new Date(task.updatedAt);
                    const today = new Date();
                    return completedDate.toDateString() === today.toDateString();
                }
                return false;
            }).length;
            
            if (completedToday > 0) {
                notifications.push({
                    id: 'productivity-today',
                    type: 'productivity',
                    title: '🎉 Great Progress!',
                    message: `You've completed ${completedToday} task${completedToday > 1 ? 's' : ''} today. Keep it up!`,
                    timestamp: now.toISOString(),
                    priority: 'success',
                    action: 'celebration'
                });
            }
            
        } catch (error) {
            console.error('Error parsing tasks for enhanced notifications (Prompt 11):', error);
        }
    }
    
    console.log(`Generated ${notifications.length} enhanced notifications (Prompt 11):`, notifications);
    return notifications;
}

// Enhanced notification display with better UI (Prompt 11)
function displayEnhancedNotifications(notifications) {
    console.log(`Displaying ${notifications.length} enhanced notifications (Prompt 11)`);
    
    const notificationsContainer = $('#notifications-container');
    const notificationsList = $('#notifications-list');
    
    // Filter out dismissed notifications
    const activeNotifications = notifications.filter(notification => 
        !dismissedNotifications.has(notification.id)
    );
    
    // Update notification badge with enhanced styling
    updateEnhancedNotificationBadge(activeNotifications.length, notifications);
    
    if (activeNotifications.length === 0) {
        notificationsContainer.addClass('d-none');
        console.log('No active notifications to display (Prompt 11)');
        return;
    }
    
    // Show notifications container
    notificationsContainer.removeClass('d-none');
    
    // Clear existing notifications
    notificationsList.empty();
    
    // Sort notifications by priority (Prompt 11: Critical first)
    const sortedNotifications = activeNotifications.sort((a, b) => {
        const priorityOrder = { 'critical': 0, 'urgent': 1, 'danger': 2, 'warning': 3, 'success': 4 };
        return (priorityOrder[a.priority] || 5) - (priorityOrder[b.priority] || 5);
    });
    
    // Create enhanced notification elements (Prompt 11)
    sortedNotifications.forEach(notification => {
        const alertClass = getEnhancedAlertClassForPriority(notification.priority);
        const icon = getEnhancedIconForNotificationType(notification.type);
        const timeAgo = getTimeAgo(notification.timestamp);
        const actionButton = getActionButtonForNotification(notification);
        
        const notificationElement = $(`
            <div class="alert ${alertClass} alert-dismissible fade show mb-2 enhanced-notification" 
                 role="alert" 
                 data-notification-id="${notification.id}"
                 data-priority="${notification.priority}">
                <div class="d-flex align-items-start">
                    <i class="${icon} me-3 mt-1 notification-icon"></i>
                    <div class="flex-grow-1">
                        <strong class="notification-title">${notification.title}</strong>
                        <div class="mt-1 notification-message">${notification.message}</div>
                        <small class="text-muted d-block mt-1">
                            <i class="fas fa-clock me-1"></i>${timeAgo}
                        </small>
                        ${actionButton ? `<div class="mt-2">${actionButton}</div>` : ''}
                    </div>
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                </div>
            </div>
        `);
        
        // Add click handler for task-related notifications
        if (notification.taskId) {
            notificationElement.find('.notification-message').addClass('clickable-notification')
                               .attr('data-task-id', notification.taskId)
                               .attr('title', 'Click to view task');
        }
        
        notificationsList.append(notificationElement);
    });
    
    // Attach enhanced event listeners (Prompt 11)
    attachEnhancedNotificationEventListeners();
    
    // Add notification animations (Prompt 11)
    addNotificationAnimations();
    
    console.log(`Enhanced notifications displayed successfully (Prompt 11)`);
}

// Enhanced notification helper functions for Prompt 11

// Get enhanced alert class for notification priority (Prompt 11)
function getEnhancedAlertClassForPriority(priority) {
    const priorityClasses = {
        'critical': 'alert-danger border-danger notification-critical',
        'urgent': 'alert-warning border-warning notification-urgent', 
        'danger': 'alert-danger border-danger notification-danger',
        'warning': 'alert-warning border-warning notification-warning',
        'success': 'alert-success border-success notification-success',
        'info': 'alert-info border-info notification-info'
    };
    return priorityClasses[priority] || 'alert-secondary';
}

// Get enhanced icon for notification type (Prompt 11)
function getEnhancedIconForNotificationType(type) {
    const typeIcons = {
        'critical_due': 'fas fa-exclamation-triangle text-danger notification-icon-pulse',
        'urgent_due': 'fas fa-clock text-warning notification-icon-spin',
        'due_soon': 'fas fa-bell text-warning',
        'overdue': 'fas fa-exclamation-circle text-danger',
        'productivity': 'fas fa-trophy text-success',
        'reminder': 'fas fa-bell text-info',
        'system': 'fas fa-cog text-secondary'
    };
    return typeIcons[type] || 'fas fa-bell text-primary';
}

// Get action button for notification (Prompt 11)
function getActionButtonForNotification(notification) {
    if (!notification.taskId) return null;
    
    const actionButtons = {
        'immediate': `<button class="btn btn-danger btn-sm me-2" onclick="viewTaskFromNotification('${notification.taskId}')">
                        <i class="fas fa-eye me-1"></i>View Now
                      </button>
                      <button class="btn btn-outline-success btn-sm" onclick="markTaskCompleteFromNotification('${notification.taskId}')">
                        <i class="fas fa-check me-1"></i>Mark Complete
                      </button>`,
        'soon': `<button class="btn btn-warning btn-sm me-2" onclick="viewTaskFromNotification('${notification.taskId}')">
                   <i class="fas fa-eye me-1"></i>View Task
                 </button>`,
        'reminder': `<button class="btn btn-outline-primary btn-sm" onclick="viewTaskFromNotification('${notification.taskId}')">
                       <i class="fas fa-arrow-right me-1"></i>View Details
                     </button>`,
        'overdue': `<button class="btn btn-danger btn-sm me-2" onclick="viewTaskFromNotification('${notification.taskId}')">
                      <i class="fas fa-exclamation-triangle me-1"></i>Handle Overdue
                    </button>`
    };
    
    return actionButtons[notification.action] || null;
}

// Update enhanced notification badge (Prompt 11)
function updateEnhancedNotificationBadge(count, allNotifications) {
    const badge = $('#notification-badge');
    const navIcon = $('#notification-icon');
    
    if (count > 0) {
        // Determine the highest priority notification
        const priorities = allNotifications.map(n => n.priority);
        const hasCritical = priorities.includes('critical');
        const hasUrgent = priorities.includes('urgent') || priorities.includes('danger');
        
        // Update badge with enhanced styling
        badge.text(count).removeClass('d-none');
        
        if (hasCritical) {
            badge.removeClass('bg-warning bg-danger').addClass('bg-danger notification-badge-pulse');
            navIcon.removeClass('text-warning').addClass('text-danger notification-icon-shake');
        } else if (hasUrgent) {
            badge.removeClass('bg-danger').addClass('bg-warning notification-badge-bounce');
            navIcon.removeClass('text-danger').addClass('text-warning');
        } else {
            badge.removeClass('bg-danger notification-badge-pulse').addClass('bg-warning');
            navIcon.removeClass('text-danger text-warning').addClass('text-primary');
        }
    } else {
        badge.addClass('d-none');
        navIcon.removeClass('text-danger text-warning notification-icon-shake').addClass('text-muted');
    }
}

// Check for critical due dates (Prompt 11)
function checkCriticalDueDates() {
    console.log('Checking for critical due dates (Prompt 11)');
    
    if (!currentUser) return;
    
    const storedTasks = localStorage.getItem('tasks');
    if (!storedTasks) return;
    
    try {
        const tasks = JSON.parse(storedTasks);
        const userTasks = tasks.filter(task => 
            (task.userId === currentUser.id || (task.sharedWith && task.sharedWith.includes(currentUser.id))) &&
            task.status !== 'completed' && 
            task.dueDate
        );
        
        const now = new Date();
        const criticalTasks = userTasks.filter(task => {
            const dueDate = new Date(task.dueDate);
            const timeDiff = dueDate.getTime() - now.getTime();
            return timeDiff > 0 && timeDiff <= 30 * 60 * 1000; // 30 minutes
        });
        
        if (criticalTasks.length > 0) {
            console.log(`Found ${criticalTasks.length} critical tasks (Prompt 11)`, criticalTasks);
            
            // Show browser notification for critical tasks
            showBrowserNotificationForCriticalTasks(criticalTasks);
            
            // Add visual indicators to the page
            addCriticalTaskIndicators(criticalTasks);
        }
        
    } catch (error) {
        console.error('Error checking critical due dates (Prompt 11):', error);
    }
}

// Show browser notifications for critical items (Prompt 11)
function showBrowserNotificationsForCritical(notifications) {
    if (!('Notification' in window)) {
        console.log('Browser notifications not supported (Prompt 11)');
        return;
    }
    
    const criticalNotifications = notifications.filter(n => 
        n.priority === 'critical' && !dismissedNotifications.has(n.id)
    );
    
    if (criticalNotifications.length === 0) return;
    
    // Request permission if needed
    if (Notification.permission === 'default') {
        Notification.requestPermission().then(permission => {
            if (permission === 'granted') {
                showCriticalBrowserNotifications(criticalNotifications);
            }
        });
    } else if (Notification.permission === 'granted') {
        showCriticalBrowserNotifications(criticalNotifications);
    }
}

// Show critical browser notifications (Prompt 11)
function showCriticalBrowserNotifications(notifications) {
    notifications.forEach(notification => {
        // Check if we've already shown this notification recently
        const lastShown = localStorage.getItem(`browser-notification-${notification.id}`);
        const now = Date.now();
        
        if (lastShown && (now - parseInt(lastShown)) < 10 * 60 * 1000) { // Don't repeat within 10 minutes
            return;
        }
        
        const browserNotification = new Notification(notification.title, {
            body: notification.message,
            icon: '/favicon.svg',
            badge: '/favicon.svg',
            tag: notification.id,
            requireInteraction: true
        });
        
        // Store when we showed this notification
        localStorage.setItem(`browser-notification-${notification.id}`, now.toString());
        
        // Handle click
        browserNotification.onclick = function() {
            window.focus();
            if (notification.taskId) {
                viewTaskFromNotification(notification.taskId);
            }
            browserNotification.close();
        };
        
        // Auto close after 10 seconds for non-critical
        if (notification.priority !== 'critical') {
            setTimeout(() => {
                browserNotification.close();
            }, 10000);
        }
    });
}

// Add critical task indicators (Prompt 11)
function addCriticalTaskIndicators(criticalTasks) {
    // Add a banner at the top for critical tasks
    let criticalBanner = $('#critical-tasks-banner');
    
    if (criticalTasks.length > 0) {
        if (criticalBanner.length === 0) {
            criticalBanner = $(`
                <div id="critical-tasks-banner" class="alert alert-danger border-danger mb-3 notification-critical-banner">
                    <div class="d-flex align-items-center">
                        <i class="fas fa-exclamation-triangle fa-2x me-3 notification-icon-pulse"></i>
                        <div class="flex-grow-1">
                            <strong>🚨 CRITICAL TASKS DUE SOON!</strong>
                            <div id="critical-tasks-list" class="mt-1"></div>
                        </div>
                        <button class="btn btn-outline-light btn-sm" onclick="showMyTasks()">
                            <i class="fas fa-tasks me-1"></i>View All Tasks
                        </button>
                    </div>
                </div>
            `);
            
            $('#notifications-container').after(criticalBanner);
        }
        
        // Update the critical tasks list
        const tasksList = criticalTasks.map(task => {
            const dueDate = new Date(task.dueDate);
            const now = new Date();
            const minutesLeft = Math.round((dueDate.getTime() - now.getTime()) / (1000 * 60));
            
            return `• <strong>${task.title}</strong> (due in ${minutesLeft} minutes)`;
        }).join('<br>');
        
        $('#critical-tasks-list').html(tasksList);
        
    } else if (criticalBanner.length > 0) {
        criticalBanner.fadeOut(500, function() {
            $(this).remove();
        });
    }
}

// Attach enhanced notification event listeners (Prompt 11)
function attachEnhancedNotificationEventListeners() {
    // Clickable notification messages
    $(document).off('click', '.clickable-notification').on('click', '.clickable-notification', function() {
        const taskId = $(this).data('task-id');
        if (taskId) {
            viewTaskFromNotification(taskId);
        }
    });
    
    // Notification dismissal tracking
    $(document).off('closed.bs.alert', '.enhanced-notification').on('closed.bs.alert', '.enhanced-notification', function() {
        const notificationId = $(this).data('notification-id');
        if (notificationId) {
            dismissedNotifications.add(notificationId);
            saveDismissedNotifications();
            
            // Update notification badge
            const remainingNotifications = $('.enhanced-notification').length - 1;
            if (remainingNotifications === 0) {
                $('#notifications-container').addClass('d-none');
            }
        }
    });
}

// Add notification animations (Prompt 11)
function addNotificationAnimations() {
    // Add entrance animations to new notifications
    $('.enhanced-notification').each(function(index) {
        $(this).css('animation-delay', `${index * 100}ms`);
    });
    
    // Add pulse animation to critical notifications
    $('.notification-critical').addClass('notification-pulse-animation');
    
    // Add shake animation to urgent notifications
    $('.notification-urgent').addClass('notification-shake-animation');
}

// View task from notification (Prompt 11)
function viewTaskFromNotification(taskId) {
    console.log(`Viewing task from notification: ${taskId} (Prompt 11)`);
    
    // Switch to My Tasks view
    showMyTasks();
    
    // Highlight the specific task
    setTimeout(() => {
        const taskCard = $(`.task-card[data-task-id="${taskId}"]`);
        if (taskCard.length > 0) {
            // Scroll to task
            taskCard[0].scrollIntoView({ behavior: 'smooth', block: 'center' });
            
            // Highlight with animation
            taskCard.addClass('task-highlighted');
            setTimeout(() => {
                taskCard.removeClass('task-highlighted');
            }, 3000);
        } else {
            showToast('info', 'Task Not Found', 'The task may have been completed or removed.');
        }
    }, 500);
}

// Mark task complete from notification (Prompt 11)
function markTaskCompleteFromNotification(taskId) {
    console.log(`Marking task complete from notification: ${taskId} (Prompt 11)`);
    
    // Find and update the task
    const storedTasks = localStorage.getItem('tasks');
    if (storedTasks) {
        try {
            const tasks = JSON.parse(storedTasks);
            const taskIndex = tasks.findIndex(t => t.id === taskId);
            
            if (taskIndex !== -1) {
                tasks[taskIndex].status = 'completed';
                tasks[taskIndex].updatedAt = new Date().toISOString();
                
                localStorage.setItem('tasks', JSON.stringify(tasks));
                
                showToast('success', 'Task Completed', `"${tasks[taskIndex].title}" has been marked as complete!`);
                
                // Refresh notifications to remove the completed task
                loadEnhancedNotifications();
                
                // Refresh task view if visible
                if ($('#task-list-container').is(':visible')) {
                    showMyTasks();
                }
            }
        } catch (error) {
            console.error('Error completing task from notification (Prompt 11):', error);
            showToast('error', 'Error', 'Failed to complete task.');
        }
    }
}

// Add notification settings button (Prompt 11)
function addNotificationSettingsButton() {
    if ($('#notification-settings-btn').length === 0) {
        const settingsBtn = $(`
            <button class="btn btn-sm btn-outline-primary ms-2" id="notification-settings-btn" title="Notification Settings">
                <i class="fas fa-cog"></i>
            </button>
        `);
        
        $('#dismiss-all-notifications').after(settingsBtn);
        
        settingsBtn.on('click', showNotificationSettingsModal);
    }
}

// Show notification settings modal (Prompt 11)
function showNotificationSettingsModal() {
    const currentSettings = {
        browserNotifications: Notification.permission === 'granted',
        checkInterval: 30, // seconds
        dueSoonThreshold: 24, // hours
        urgentThreshold: 2, // hours
        criticalThreshold: 30 // minutes
    };
    
    const modalHTML = `
        <div class="modal fade" id="notification-settings-modal" tabindex="-1">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title">
                            <i class="fas fa-bell me-2"></i>Notification Settings
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                    </div>
                    <div class="modal-body">
                        <div class="mb-3">
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="enable-browser-notifications" 
                                       ${currentSettings.browserNotifications ? 'checked' : ''}>
                                <label class="form-check-label" for="enable-browser-notifications">
                                    Enable Browser Notifications
                                </label>
                                <small class="form-text text-muted">Get desktop notifications for critical tasks</small>
                            </div>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Check for notifications every:</label>
                            <select class="form-select" id="check-interval">
                                <option value="15" ${currentSettings.checkInterval === 15 ? 'selected' : ''}>15 seconds</option>
                                <option value="30" ${currentSettings.checkInterval === 30 ? 'selected' : ''}>30 seconds</option>
                                <option value="60" ${currentSettings.checkInterval === 60 ? 'selected' : ''}>1 minute</option>
                                <option value="120" ${currentSettings.checkInterval === 120 ? 'selected' : ''}>2 minutes</option>
                            </select>
                        </div>
                        
                        <div class="mb-3">
                            <label class="form-label">Show "Due Soon" notifications for tasks due within:</label>
                            <select class="form-select" id="due-soon-threshold">
                                <option value="6" ${currentSettings.dueSoonThreshold === 6 ? 'selected' : ''}>6 hours</option>
                                <option value="12" ${currentSettings.dueSoonThreshold === 12 ? 'selected' : ''}>12 hours</option>
                                <option value="24" ${currentSettings.dueSoonThreshold === 24 ? 'selected' : ''}>24 hours</option>
                                <option value="48" ${currentSettings.dueSoonThreshold === 48 ? 'selected' : ''}>48 hours</option>
                            </select>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary" id="save-notification-settings">
                            <i class="fas fa-save me-1"></i>Save Settings
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Remove existing modal and add new one
    $('#notification-settings-modal').remove();
    $('body').append(modalHTML);
    
    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('notification-settings-modal'));
    modal.show();
    
    // Handle browser notification toggle
    $('#enable-browser-notifications').on('change', function() {
        if ($(this).is(':checked') && Notification.permission !== 'granted') {
            Notification.requestPermission().then(permission => {
                if (permission !== 'granted') {
                    $(this).prop('checked', false);
                    showToast('warning', 'Permission Denied', 'Browser notifications require permission to be granted.');
                }
            });
        }
    });
    
    // Handle save settings
    $('#save-notification-settings').on('click', function() {
        // Save settings to localStorage
        const settings = {
            browserNotifications: $('#enable-browser-notifications').is(':checked'),
            checkInterval: parseInt($('#check-interval').val()),
            dueSoonThreshold: parseInt($('#due-soon-threshold').val())
        };
        
        localStorage.setItem('notificationSettings', JSON.stringify(settings));
        
        showToast('success', 'Settings Saved', 'Notification settings have been updated.');
        modal.hide();
        
        // Restart notification system with new settings
        initializeEnhancedNotifications();
    });
    
    // Clean up modal after hiding
    $('#notification-settings-modal').on('hidden.bs.modal', function() {
        $(this).remove();
    });
}

// Update the main initialization to use enhanced notifications (Prompt 11)
function initializeNotifications() {
    console.log('Starting enhanced notification system (Prompt 11)');
    initializeEnhancedNotifications();
}