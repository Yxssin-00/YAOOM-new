/**
 * TaskMate - API Configuration
 * Central configuration for all API endpoints
 */

// API Configuration
const API_CONFIG = {
    BASE_URL: 'http://localhost:3000',  // Updated to match actual backend port
    ENDPOINTS: {
        // Auth endpoints (mounted on /api/auth)
        LOGIN: '/api/auth/login',
        REGISTER: '/api/auth/register',
        LOGOUT: '/api/auth/logout',
        VERIFY: '/api/auth/verify',
        
        // Task endpoints (mounted on /api/task)
        TASKS: '/api/task/tasks',
        TASK_BY_ID: (id) => `/api/task/tasks/${id}`,
        TASK_STATUS: (id) => `/api/task/tasks/${id}/status`,
        TASK_SHARE: '/api/task/tasks/share',
        TASK_COMMENTS: (id) => `/api/task/tasks/${id}/comments`,
        TASK_COMMENT_BY_ID: (taskId, commentId) => `/api/task/tasks/${taskId}/comments/${commentId}`,
        
        // User endpoints (mounted on /api/user)
        USERS: '/api/user/users',
        USER_BY_ID: (id) => `/api/user/users/${id}`,
        USER_PREFERENCES: (id) => `/api/user/users/${id}/preferences`,
        USER_PASSWORD: (id) => `/api/user/users/${id}/password`,
        
        // Admin endpoints
        ADMIN_USERS: '/api/admin/users',
        ADMIN_USER_BY_ID: (id) => `/api/admin/users/${id}`,
        ADMIN_USER_ACTION: (id, action) => `/api/admin/users/${id}/${action}`,
        
        // Notification endpoints
        NOTIFICATIONS: '/api/notifications',
        NOTIFICATIONS_DUE_SOON: '/api/notifications/due-soon',
        
        // Health check
        HEALTH: '/api/health'
    }
};

// Helper function to build full API URL
function getApiUrl(endpoint) {
    return `${API_CONFIG.BASE_URL}${endpoint}`;
}

// Helper function to get endpoint by name
function getEndpoint(name, ...params) {
    const endpoint = API_CONFIG.ENDPOINTS[name];
    if (typeof endpoint === 'function') {
        return endpoint(...params);
    }
    return endpoint;
}

// Test API connectivity
async function testApiConnection() {
    try {
        console.log('🔍 Testing API connection...');
        const response = await fetch(getApiUrl(API_CONFIG.ENDPOINTS.HEALTH));
        if (response.ok) {
            const data = await response.json();
            console.log('✅ API Health Check Passed:', data);
            return true;
        } else {
            console.log('❌ API Health Check Failed:', response.status);
            return false;
        }
    } catch (error) {
        console.log('❌ API Connection Error:', error.message);
        return false;
    }
}

// Export for global use
window.API_CONFIG = API_CONFIG;
window.getApiUrl = getApiUrl;
window.getEndpoint = getEndpoint;
window.testApiConnection = testApiConnection;

console.log('📡 API Configuration loaded:', API_CONFIG.BASE_URL);

// Auto-test connection on load
setTimeout(() => {
    testApiConnection();
}, 1000); 