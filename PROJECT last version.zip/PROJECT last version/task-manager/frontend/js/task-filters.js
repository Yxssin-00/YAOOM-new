/**
 * TaskMate - Task Management System
 * Task Filtering Functions
 */

// Default task filters
const defaultTaskFilters = {
    status: 'all',
    priority: 'all',
    sortBy: 'dueDate',
    sortOrder: 'asc',
    search: '',
    tagIds: [],
    dueDate: 'all', // New due date filter
    filterMode: 'and' // New filter mode
};

// Current task filters
let taskFilters = { ...defaultTaskFilters };

// Initialize task filters UI
function initializeTaskFilters() {
    // Create filter UI if it doesn't exist
    if ($('.task-filters').children().length === 0) {
        createFilterUI();
    }
    
    // Reset filters to default
    resetFilters();
    
    // Attach event listeners
    attachFilterEventListeners();
}

// Create filter UI elements
function createFilterUI() {
    const filterContainer = $('.task-filters');
    
    // Create filter HTML with enhanced UI
    const filterHTML = `
        <div class="card mb-3">
            <div class="card-header bg-light d-flex justify-content-between align-items-center">
                <h5 class="mb-0">
                    <i class="fas fa-filter me-2"></i> Filter & Sort Tasks
                </h5>
                <span class="badge bg-primary">
                    Showing <span id="filtered-task-count">0</span> of <span id="total-task-count">0</span> tasks
                </span>
            </div>
            <div class="card-body">
                <div class="row g-3">
                    <!-- Search -->
                    <div class="col-md-4">
                        <label for="task-search" class="form-label">Search</label>
                        <div class="input-group">
                            <span class="input-group-text"><i class="fas fa-search"></i></span>
                            <input type="text" class="form-control" id="task-search" placeholder="Search tasks...">
                        </div>
                    </div>
                    
                    <!-- Status filter -->
                    <div class="col-md-4">
                        <label for="status-filter" class="form-label">Status</label>
                        <select class="form-select" id="status-filter">
                            <option value="all">All Status</option>
                            <option value="pending">Pending</option>
                            <option value="in-progress">In Progress</option>
                            <option value="completed">Completed</option>
                        </select>
                    </div>
                    
                    <!-- Priority filter -->
                    <div class="col-md-4">
                        <label for="priority-filter" class="form-label">Priority</label>
                        <select class="form-select" id="priority-filter">
                            <option value="all">All Priority</option>
                            <option value="low">Low</option>
                            <option value="medium">Medium</option>
                            <option value="high">High</option>
                        </select>
                    </div>
                    
                    <!-- Due date filter -->
                    <div class="col-md-4">
                        <label for="due-date-filter" class="form-label">Due Date</label>
                        <select class="form-select" id="due-date-filter">
                            <option value="all">All Due Dates</option>
                            <option value="today">Due Today</option>
                            <option value="tomorrow">Due Tomorrow</option>
                            <option value="week">Due This Week</option>
                            <option value="overdue">Overdue</option>
                        </select>
                    </div>
                    
                    <!-- Sort by (Enhanced for Prompt 8) -->
                    <div class="col-md-4">
                        <label for="sort-by" class="form-label">
                            <i class="fas fa-sort me-1"></i>Sort By
                        </label>
                        <select class="form-select" id="sort-by">
                            <option value="dueDate">Due Date</option>
                            <option value="createdAt">Date Created</option>
                            <option value="priority">Priority</option>
                            <option value="title">Title (A-Z)</option>
                            <option value="status">Status</option>
                            <option value="lastModified">Last Modified</option>
                        </select>
                    </div>
                    
                    <!-- Sort order (Enhanced for Prompt 8) -->
                    <div class="col-md-4">
                        <label for="sort-order" class="form-label">
                            <i class="fas fa-sort-amount-down me-1"></i>Sort Order
                        </label>
                        <select class="form-select" id="sort-order">
                            <option value="asc">Ascending (↑)</option>
                            <option value="desc">Descending (↓)</option>
                        </select>
                    </div>
                    
                    <!-- Filter Combination Mode (New for Prompt 8) -->
                    <div class="col-md-4">
                        <label for="filter-mode" class="form-label">
                            <i class="fas fa-layer-group me-1"></i>Filter Mode
                        </label>
                        <select class="form-select" id="filter-mode">
                            <option value="and">Match All (AND)</option>
                            <option value="or">Match Any (OR)</option>
                        </select>
                    </div>
                </div>
                
                <!-- Tags -->
                <div class="mt-3">
                    <label class="form-label">Tags</label>
                    <div class="d-flex flex-wrap gap-2" id="tag-filters">
                        <!-- Tag filters will be added here -->
                    </div>
                </div>
                
                <!-- Reset button -->
                <div class="mt-3 text-end">
                    <button class="btn btn-secondary" id="reset-filters">
                        <i class="fas fa-undo me-1"></i> Reset Filters
                    </button>
                </div>

                <!-- Quick filters (Enhanced for Prompt 8) -->
                <div class="mt-3">
                    <label class="form-label">
                        <i class="fas fa-zap me-1"></i>Quick Filters
                    </label>
                    <div class="d-flex flex-wrap gap-2">
                        <button class="btn btn-sm btn-outline-primary quick-filter" data-filter="today">
                            <i class="fas fa-calendar-day me-1"></i> Due Today
                        </button>
                        <button class="btn btn-sm btn-outline-warning quick-filter" data-filter="overdue">
                            <i class="fas fa-exclamation-circle me-1"></i> Overdue
                        </button>
                        <button class="btn btn-sm btn-outline-danger quick-filter" data-filter="high-priority">
                            <i class="fas fa-arrow-up me-1"></i> High Priority
                        </button>
                        <button class="btn btn-sm btn-outline-success quick-filter" data-filter="completed">
                            <i class="fas fa-check-circle me-1"></i> Completed
                        </button>
                        <button class="btn btn-sm btn-outline-info quick-filter" data-filter="in-progress">
                            <i class="fas fa-spinner me-1"></i> In Progress
                        </button>
                        <button class="btn btn-sm btn-outline-secondary quick-filter" data-filter="no-due-date">
                            <i class="fas fa-calendar-times me-1"></i> No Due Date
                        </button>
                    </div>
                </div>
                
                <!-- Filter Presets (New for Prompt 8) -->
                <div class="mt-3">
                    <label class="form-label">
                        <i class="fas fa-bookmark me-1"></i>Filter Presets
                    </label>
                    <div class="d-flex flex-wrap gap-2">
                        <button class="btn btn-sm btn-outline-dark preset-filter" data-preset="urgent">
                            <i class="fas fa-fire me-1"></i> Urgent Tasks
                        </button>
                        <button class="btn btn-sm btn-outline-dark preset-filter" data-preset="this-week">
                            <i class="fas fa-calendar-week me-1"></i> This Week
                        </button>
                        <button class="btn btn-sm btn-outline-dark preset-filter" data-preset="my-priorities">
                            <i class="fas fa-star me-1"></i> My Priorities
                        </button>
                        <button class="btn btn-sm btn-outline-dark preset-filter" data-preset="recent">
                            <i class="fas fa-clock me-1"></i> Recently Created
                        </button>
                    </div>
                </div>
                
                <!-- Advanced Options (New for Prompt 8) -->
                <div class="mt-3">
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="show-completed">
                        <label class="form-check-label" for="show-completed">
                            <i class="fas fa-eye me-1"></i>Include completed tasks in results
                        </label>
                    </div>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" id="group-by-priority">
                        <label class="form-check-label" for="group-by-priority">
                            <i class="fas fa-layer-group me-1"></i>Group results by priority
                        </label>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Add filter HTML to container
    filterContainer.html(filterHTML);
    
    // Add tag filters
    const tagFiltersContainer = $('#tag-filters');
    tags.forEach(tag => {
        const tagButton = $(`
            <button class="btn btn-sm tag-filter" data-tag-id="${tag.id}" style="background-color: ${tag.color}; color: white;">
                ${tag.name}
                <i class="fas fa-check ms-1 d-none"></i>
            </button>
        `);
        
        // Add click handler to each tag button
        tagButton.on('click', function() {
            const tagId = parseInt($(this).data('tag-id'));
            const tagIndex = taskFilters.tagIds.indexOf(tagId);
            
            if (tagIndex === -1) {
                // Add tag to filter
                taskFilters.tagIds.push(tagId);
                $(this).find('.fa-check').removeClass('d-none');
            } else {
                // Remove tag from filter
                taskFilters.tagIds.splice(tagIndex, 1);
                $(this).find('.fa-check').addClass('d-none');
            }
            
            applyFilters();
        });
        
        tagFiltersContainer.append(tagButton);
    });
}

// Attach event listeners to filter elements
function attachFilterEventListeners() {
    // Search input
    $('#task-search').on('input', function() {
        taskFilters.search = $(this).val().toLowerCase();
        applyFilters();
    });
    
    // Status filter
    $('#status-filter').on('change', function() {
        taskFilters.status = $(this).val();
        applyFilters();
    });
    
    // Priority filter
    $('#priority-filter').on('change', function() {
        taskFilters.priority = $(this).val();
        applyFilters();
    });
    
    // Due date filter
    $('#due-date-filter').on('change', function() {
        taskFilters.dueDate = $(this).val();
        applyFilters();
    });
    
    // Sort by
    $('#sort-by').on('change', function() {
        taskFilters.sortBy = $(this).val();
        applyFilters();
    });
    
    // Sort order
    $('#sort-order').on('change', function() {
        taskFilters.sortOrder = $(this).val();
        applyFilters();
    });
    
    // Filter mode
    $('#filter-mode').on('change', function() {
        taskFilters.filterMode = $(this).val();
        applyFilters();
    });
    
    // Tag filters (event handlers are now attached individually when buttons are created)
    
    // Reset filters
    $('#reset-filters').on('click', resetFilters);
    
    // Quick filters (Enhanced for Prompt 8)
    $('.quick-filter').on('click', function(e) {
        e.preventDefault();
        const filterType = $(this).data('filter');
        
        console.log(`Quick filter applied: ${filterType} (Prompt 8)`);
        
        // Reset filters first
        resetFilters();
        
        // Apply specific quick filter
        switch(filterType) {
            case 'today':
                taskFilters.dueDate = 'today';
                $('#due-date-filter').val('today');
                break;
            case 'overdue':
                taskFilters.dueDate = 'overdue';
                $('#due-date-filter').val('overdue');
                break;
            case 'high-priority':
                taskFilters.priority = 'high';
                $('#priority-filter').val('high');
                break;
            case 'completed':
                taskFilters.status = 'completed';
                $('#status-filter').val('completed');
                break;
            case 'in-progress':
                taskFilters.status = 'in-progress';
                $('#status-filter').val('in-progress');
                break;
            case 'no-due-date':
                // Custom filter for tasks without due dates
                taskFilters.dueDate = 'none';
                $('#due-date-filter').val('none');
                break;
        }
        
        // Highlight the active quick filter
        $('.quick-filter').removeClass('active');
        $(this).addClass('active');
        
        // Apply filters
        applyFilters();
    });
    
    // Filter Presets (New for Prompt 8)
    $('.preset-filter').on('click', function(e) {
        e.preventDefault();
        const presetType = $(this).data('preset');
        
        console.log(`Filter preset applied: ${presetType} (Prompt 8)`);
        
        // Reset filters first
        resetFilters();
        
        // Apply specific preset
        switch(presetType) {
            case 'urgent':
                // High priority + overdue or due today
                taskFilters.priority = 'high';
                taskFilters.dueDate = 'today';
                taskFilters.filterMode = 'or'; // Either high priority OR due today
                $('#priority-filter').val('high');
                $('#due-date-filter').val('today');
                $('#filter-mode').val('or');
                break;
                
            case 'this-week':
                // Due this week + not completed
                taskFilters.dueDate = 'week';
                taskFilters.status = 'in-progress';
                taskFilters.filterMode = 'and';
                $('#due-date-filter').val('week');
                $('#status-filter').val('in-progress');
                $('#filter-mode').val('and');
                break;
                
            case 'my-priorities':
                // High and medium priority + not completed
                taskFilters.priority = 'high';
                taskFilters.status = 'pending';
                taskFilters.filterMode = 'or';
                $('#priority-filter').val('high');
                $('#status-filter').val('pending');
                $('#filter-mode').val('or');
                break;
                
            case 'recent':
                // Sort by creation date (newest first)
                taskFilters.sortBy = 'createdAt';
                taskFilters.sortOrder = 'desc';
                $('#sort-by').val('createdAt');
                $('#sort-order').val('desc');
                break;
        }
        
        // Highlight the active preset
        $('.preset-filter').removeClass('active');
        $(this).addClass('active');
        
        // Apply filters
        applyFilters();
    });
    
    // Advanced Options (New for Prompt 8)
    $('#show-completed').on('change', function() {
        taskFilters.showCompleted = $(this).is(':checked');
        applyFilters();
    });
    
    $('#group-by-priority').on('change', function() {
        taskFilters.groupByPriority = $(this).is(':checked');
        applyFilters();
    });
}

// Reset filters to default
function resetFilters() {
    // Reset filter object
    taskFilters = { ...defaultTaskFilters };
    
    // Reset UI
    $('#task-search').val('');
    $('#status-filter').val('all');
    $('#priority-filter').val('all');
    $('#due-date-filter').val('all');
    $('#sort-by').val('dueDate');
    $('#sort-order').val('asc');
    $('#filter-mode').val('and'); // Reset filter mode
    $('.tag-filter .fa-check').addClass('d-none');
    
    // Apply filters
    applyFilters();
}

// Apply filters to tasks (Enhanced for Prompt 8)
function applyFilters() {
    console.log('Applying enhanced filters (Prompt 8):', taskFilters);
    
    // Start with all tasks
    let currentTasks = [...tasks];
    
    // Enhanced filtering with support for filter mode (Prompt 8)
    const filters = [];
    
    // Status filter
    if (taskFilters.status !== 'all') {
        filters.push(task => task.status === taskFilters.status);
    }
    
    // Priority filter
    if (taskFilters.priority !== 'all') {
        filters.push(task => task.priority === taskFilters.priority);
    }
    
    // Due date filter (Enhanced for Prompt 8)
    if (taskFilters.dueDate !== 'all') {
        const today = new Date();
        today.setHours(0, 0, 0, 0);
        
        const tomorrow = new Date(today);
        tomorrow.setDate(tomorrow.getDate() + 1);
        
        const nextWeek = new Date(today);
        nextWeek.setDate(nextWeek.getDate() + 7);
        
        filters.push(task => {
            if (!task.dueDate) return taskFilters.dueDate === 'overdue'; // No due date = not overdue
            
            const dueDate = new Date(task.dueDate);
            dueDate.setHours(0, 0, 0, 0);
            
            switch (taskFilters.dueDate) {
                case 'today':
                    return dueDate.getTime() === today.getTime();
                case 'tomorrow':
                    return dueDate.getTime() === tomorrow.getTime();
                case 'week':
                    return dueDate >= today && dueDate <= nextWeek;
                case 'overdue':
                    return dueDate < today;
                default:
                    return true;
            }
        });
    }
    
    // Tags filter
    if (taskFilters.tagIds.length > 0) {
        filters.push(task => {
            if (!task.tagIds || task.tagIds.length === 0) return false;
            return taskFilters.tagIds.some(tagId => task.tagIds.includes(tagId));
        });
    }
    
    // Search filter
    if (taskFilters.search) {
        filters.push(task => {
            const searchLower = taskFilters.search.toLowerCase();
            return task.title.toLowerCase().includes(searchLower) ||
                   (task.description && task.description.toLowerCase().includes(searchLower));
        });
    }
    
    // Apply filters based on mode (Prompt 8 enhancement)
    if (filters.length > 0) {
        if (taskFilters.filterMode === 'and') {
            // Match ALL filters (default behavior)
            currentTasks = currentTasks.filter(task => 
                filters.every(filterFn => filterFn(task))
            );
        } else {
            // Match ANY filter (OR mode)
            currentTasks = currentTasks.filter(task => 
                filters.some(filterFn => filterFn(task))
            );
        }
    }
    
    // Enhanced sorting with new options (Prompt 8)
    currentTasks = sortTasksEnhanced(currentTasks, taskFilters.sortBy, taskFilters.sortOrder);
    
    // Update counters with animation
    const filteredCount = currentTasks.length;
    const totalCount = tasks.length;
    
    $('#filtered-task-count').text(filteredCount);
    $('#total-task-count').text(totalCount);
    
    // Add visual feedback for active filters
    updateFilterIndicators(filteredCount, totalCount);
    
    // Render filtered tasks using jQuery without reload (Prompt 8)
    renderFilteredTasksWithAnimation(currentTasks);
    
    console.log(`Filtered ${filteredCount} of ${totalCount} tasks (Prompt 8)`);
}

// Enhanced sorting function for Prompt 8
function sortTasksEnhanced(taskList, sortBy, sortOrder) {
    console.log(`Sorting tasks by ${sortBy} (${sortOrder}) - Prompt 8 enhancement`);
    
    return taskList.sort((a, b) => {
        let valueA, valueB;
        
        switch (sortBy) {
            case 'dueDate':
                valueA = a.dueDate ? new Date(a.dueDate) : new Date('9999-12-31');
                valueB = b.dueDate ? new Date(b.dueDate) : new Date('9999-12-31');
                break;
                
            case 'createdAt': // New for Prompt 8
                valueA = new Date(a.createdAt || a.id);
                valueB = new Date(b.createdAt || b.id);
                break;
                
            case 'lastModified': // New for Prompt 8
                valueA = new Date(a.lastModified || a.createdAt || a.id);
                valueB = new Date(b.lastModified || b.createdAt || b.id);
                break;
                
            case 'priority':
                const priorityValues = { high: 3, medium: 2, low: 1 };
                valueA = priorityValues[a.priority] || 0;
                valueB = priorityValues[b.priority] || 0;
                break;
                
            case 'title':
                valueA = a.title.toLowerCase();
                valueB = b.title.toLowerCase();
                break;
                
            case 'status':
                const statusValues = { pending: 1, 'in-progress': 2, completed: 3 };
                valueA = statusValues[a.status] || 0;
                valueB = statusValues[b.status] || 0;
                break;
                
            default:
                return 0;
        }
        
        // Handle comparison based on data type
        let comparison = 0;
        if (valueA instanceof Date && valueB instanceof Date) {
            comparison = valueA.getTime() - valueB.getTime();
        } else if (typeof valueA === 'string' && typeof valueB === 'string') {
            comparison = valueA.localeCompare(valueB);
        } else {
            comparison = valueA - valueB;
        }
        
        return sortOrder === 'asc' ? comparison : -comparison;
    });
}

// Update filter indicators (Prompt 8 enhancement)
function updateFilterIndicators(filteredCount, totalCount) {
    const badge = $('.card-header .badge');
    const isFiltered = filteredCount !== totalCount;
    
    if (isFiltered) {
        badge.removeClass('bg-primary').addClass('bg-warning');
        badge.find('#filtered-task-count').addClass('fw-bold');
        
        // Add filter indicator
        if (!$('.filter-active-indicator').length) {
            $('.card-header h5').append(`
                <span class="filter-active-indicator ms-2">
                    <i class="fas fa-filter text-warning"></i>
                </span>
            `);
        }
    } else {
        badge.removeClass('bg-warning').addClass('bg-primary');
        badge.find('#filtered-task-count').removeClass('fw-bold');
        $('.filter-active-indicator').remove();
    }
}

// Render filtered tasks with animation (Prompt 8)
function renderFilteredTasksWithAnimation(filteredTasks) {
    console.log('Rendering filtered tasks with jQuery animation (Prompt 8)');
    
    // Check if we're using tabbed interface
    if ($('#taskTabs').length > 0) {
        // Using tabbed interface - fade out tab content and update
        $('.tab-content').fadeOut(200, function() {
            // Update content using tabbed rendering
            renderTasks(filteredTasks);
            
            // Fade back in with new content
            $('.tab-content').fadeIn(300);
            
            // Add stagger animation to task cards in active tab
            $('.tab-pane.show.active .task-card').hide().each(function(index) {
                $(this).delay(index * 100).fadeIn(400);
            });
        });
    } else {
        // Using legacy interface
        const taskContainer = $('#task-list');
        
        // Fade out existing tasks
        taskContainer.fadeOut(200, function() {
            // Update content
            renderTasks(filteredTasks);
            
            // Fade back in with new content
            taskContainer.fadeIn(300);
            
            // Add stagger animation to task cards
            $('.task-card').hide().each(function(index) {
                $(this).delay(index * 100).fadeIn(400);
            });
        });
    }
}

// Update URL with current filters (Prompt 8)
function updateURLWithFilters() {
    if (window.history && window.history.pushState) {
        const params = new URLSearchParams();
        
        if (taskFilters.status !== 'all') params.set('status', taskFilters.status);
        if (taskFilters.priority !== 'all') params.set('priority', taskFilters.priority);
        if (taskFilters.dueDate !== 'all') params.set('dueDate', taskFilters.dueDate);
        if (taskFilters.sortBy !== 'dueDate') params.set('sortBy', taskFilters.sortBy);
        if (taskFilters.sortOrder !== 'asc') params.set('sortOrder', taskFilters.sortOrder);
        if (taskFilters.search) params.set('search', taskFilters.search);
        if (taskFilters.filterMode !== 'and') params.set('filterMode', taskFilters.filterMode);
        
        const newURL = params.toString() ? `${window.location.pathname}?${params}` : window.location.pathname;
        window.history.pushState({}, '', newURL);
    }
}

// Enhanced task rendering for My Tasks view with filters
function showMyTasksWithFilters() {
    // Normal My Tasks logic
    if (!currentUser) return;
    
    // Update active navigation
    $('.nav-link, .list-group-item').removeClass('active');
    $('#my-tasks-link, #sidebar-my-tasks').addClass('active');
    
    // Use central container management
    showContainer('task-list-container');
    
    // Update heading
    $('#task-list-container h1').text('My Tasks');
    
    // Initialize filters
    initializeTaskFilters();
    
    // Fetch and display tasks
    fetchTasks().then(() => {
        applyFilters();
    });
}

// Enhanced shared tasks view with filters
function showSharedTasksWithFilters() {
    // Normal Shared Tasks logic
    if (!currentUser) return;
    
    // Update active navigation
    $('.nav-link, .list-group-item').removeClass('active');
    $('#shared-tasks-link, #sidebar-shared-tasks').addClass('active');
    
    // Use central container management
    showContainer('task-list-container');
    
    // Update heading
    $('#task-list-container h1').text('Shared Tasks');
    
    // Initialize filters
    initializeTaskFilters();
    
    // Fetch and display shared tasks
    fetchTasks().then(() => {
        applyFilters();
    });
}

// Refresh tag filters when new tags are added
function refreshTagFilters() {
    const tagFiltersContainer = $('#tag-filters');
    if (tagFiltersContainer.length === 0) return;
    
    // Clear existing tag filters
    tagFiltersContainer.empty();
    
    // Add updated tag filters
    tags.forEach(tag => {
        const isSelected = taskFilters.tagIds.includes(tag.id);
        const tagButton = $(`
            <button class="btn btn-sm tag-filter ${isSelected ? 'active' : ''}" 
                    data-tag-id="${tag.id}" 
                    style="background-color: ${tag.color}; color: white;">
                ${tag.name}
                <i class="fas fa-check ms-1 ${isSelected ? '' : 'd-none'}"></i>
            </button>
        `);
        
        // Add click handler
        tagButton.on('click', function() {
            const tagId = parseInt($(this).data('tag-id'));
            const tagIndex = taskFilters.tagIds.indexOf(tagId);
            
            if (tagIndex === -1) {
                // Add tag to filter
                taskFilters.tagIds.push(tagId);
                $(this).find('.fa-check').removeClass('d-none');
                $(this).addClass('active');
            } else {
                // Remove tag from filter
                taskFilters.tagIds.splice(tagIndex, 1);
                $(this).find('.fa-check').addClass('d-none');
                $(this).removeClass('active');
            }
            
            applyFilters();
        });
        
        tagFiltersContainer.append(tagButton);
    });
} 