/**
 * TaskMate - Task Management System
 * Profile Management Functions
 */

console.log('Profile.js loaded successfully!');

// Show profile page
function showProfile() {
    console.log('Showing profile page');
    
    // Update active navigation
    $('.nav-link, .list-group-item').removeClass('active');
    $('#profile-link, #sidebar-profile').addClass('active');
    
    // Create profile container if it doesn't exist
    if ($('#profile-container').length === 0) {
        const profileContainer = $(`
            <div id="profile-container">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h1><i class="fas fa-user me-2"></i> My Profile</h1>
                    <button class="btn btn-primary" id="edit-profile-btn">
                        <i class="fas fa-edit me-1"></i> Edit Profile
                    </button>
                </div>
                <div class="row">
                    <div class="col-md-4 mb-4">
                        <div class="card">
                            <div class="card-body text-center">
                                <div class="avatar-placeholder mb-3">
                                    <i class="fas fa-user fa-5x"></i>
                                </div>
                                <h4 id="profile-name"></h4>
                                <p class="text-muted" id="profile-role"></p>
                                <div class="mt-3">
                                    <button class="btn btn-outline-secondary btn-sm" id="change-avatar-btn">
                                        <i class="fas fa-camera me-1"></i> Change Avatar
                                    </button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-8">
                        <div class="card">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Profile Information</h5>
                            </div>
                            <div class="card-body">
                                <div id="profile-info">
                                    <!-- Profile info will be loaded here -->
                                </div>
                            </div>
                        </div>
                        
                        <div class="card mt-4">
                            <div class="card-header">
                                <h5 class="card-title mb-0">Account Statistics</h5>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-4 text-center mb-3">
                                        <h2 id="stats-total-tasks">0</h2>
                                        <p class="text-muted">Total Tasks</p>
                                    </div>
                                    <div class="col-md-4 text-center mb-3">
                                        <h2 id="stats-completed-tasks">0</h2>
                                        <p class="text-muted">Completed</p>
                                    </div>
                                    <div class="col-md-4 text-center mb-3">
                                        <h2 id="stats-pending-tasks">0</h2>
                                        <p class="text-muted">Pending</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        `);
        
        // Append to main content
        $('#main-content').append(profileContainer);
        
        // Add event listeners
        $('#edit-profile-btn').on('click', showEditProfileModal);
        $('#change-avatar-btn').on('click', function() {
            showToast('info', 'Feature Coming Soon', 'Avatar upload will be available in a future update.');
        });
    }
    
    // Use central container management
    showContainer('profile-container');
    
    // Load profile data
    loadProfileData();
}

// Load profile data (Enhanced for Prompt 9)
function loadProfileData() {
    console.log('Loading profile data with API integration (Prompt 9)');
    
    if (!currentUser) {
        showToast('error', 'Error', 'User data not available');
        return;
    }
    
    // Show loading state
    const profileInfo = $('#profile-info');
    profileInfo.html(`
        <div class="text-center p-4">
            <div class="spinner-border text-primary" role="status"></div>
            <div class="mt-2">Loading profile information...</div>
        </div>
    `);
    
    // Fetch fresh user data from API (Prompt 9 requirement)
    const apiUrl = `http://localhost:3000/api/users/${currentUser.id}`;
    
    console.log(`Fetching user profile from ${apiUrl} (Prompt 9 API integration)`);
    
    // Use makeAuthenticatedRequest for proper API integration
    if (typeof makeAuthenticatedRequest === 'function' && isAuthenticated()) {
        makeAuthenticatedRequest(apiUrl, {
            method: 'GET'
        })
        .then(userData => {
            console.log('Profile data fetched successfully from API (Prompt 9):', userData);
            
            // Update current user with fresh data
            currentUser = { ...currentUser, ...userData };
            localStorage.setItem('currentUser', JSON.stringify(currentUser));
            
            // Render enhanced profile data
            renderEnhancedProfileData(userData);
            
            showToast('success', 'Profile Loaded', 'Your profile information has been refreshed.');
        })
        .catch(error => {
            console.log('API unavailable, using stored profile data (Prompt 9 fallback):', error.message);
            
            // Fallback to stored user data
            renderEnhancedProfileData(currentUser);
            
            showToast('info', 'Offline Mode', 'Showing cached profile data. Some information may not be current.');
        });
    } else {
        // Direct fallback for offline mode
        console.log('Using stored profile data (Prompt 9 offline mode)');
        renderEnhancedProfileData(currentUser);
    }
    
    // Load additional profile statistics
    loadUserStatistics();
}

// Render enhanced profile data (Prompt 9)
function renderEnhancedProfileData(userData) {
    console.log('Rendering enhanced profile data (Prompt 9):', userData);
    
    // Update profile header
    $('#profile-name').text(userData.name || 'Unknown User');
    $('#profile-role').text((userData.role || 'user').charAt(0).toUpperCase() + (userData.role || 'user').slice(1));
    
    // Get additional profile information
    const memberSince = userData.createdAt ? new Date(userData.createdAt).toLocaleDateString() : 'Unknown';
    const lastLogin = userData.lastLogin ? new Date(userData.lastLogin).toLocaleString() : 'Never';
    const emailVerified = userData.emailVerified !== false;
    const profileCompletion = calculateProfileCompletion(userData);
    
    // Update profile details with enhanced information
    const profileInfo = $('#profile-info');
    profileInfo.html(`
        <!-- Basic Information -->
        <div class="row mb-3 align-items-center">
            <div class="col-md-3 fw-bold">Name</div>
            <div class="col-md-9">
                <div class="d-flex align-items-center">
                    <span>${userData.name || 'Not provided'}</span>
                    ${userData.name ? '<i class="fas fa-check-circle text-success ms-2" title="Verified"></i>' : '<i class="fas fa-exclamation-triangle text-warning ms-2" title="Missing"></i>'}
                </div>
            </div>
        </div>
        
        <div class="row mb-3 align-items-center">
            <div class="col-md-3 fw-bold">Email</div>
            <div class="col-md-9">
                <div class="d-flex align-items-center">
                    <span>${userData.email || 'Not provided'}</span>
                    ${emailVerified ? '<i class="fas fa-check-circle text-success ms-2" title="Verified"></i>' : '<i class="fas fa-exclamation-triangle text-warning ms-2" title="Not verified"></i>'}
                </div>
            </div>
        </div>
        
        <div class="row mb-3">
            <div class="col-md-3 fw-bold">Role</div>
            <div class="col-md-9">
                <span class="badge bg-${userData.role === 'admin' ? 'danger' : 'primary'} me-2">
                    ${(userData.role || 'user').charAt(0).toUpperCase() + (userData.role || 'user').slice(1)}
                </span>
                ${userData.role === 'admin' ? '<i class="fas fa-crown text-warning ms-1" title="Administrator"></i>' : ''}
            </div>
        </div>
        
        <!-- Account Information -->
        <hr class="my-4">
        <h6 class="text-muted mb-3">
            <i class="fas fa-info-circle me-1"></i>Account Information
        </h6>
        
        <div class="row mb-3">
            <div class="col-md-3 fw-bold">Account ID</div>
            <div class="col-md-9">
                <code class="text-muted">${userData.id}</code>
            </div>
        </div>
        
        <div class="row mb-3">
            <div class="col-md-3 fw-bold">Member Since</div>
            <div class="col-md-9">${memberSince}</div>
        </div>
        
        <div class="row mb-3">
            <div class="col-md-3 fw-bold">Last Login</div>
            <div class="col-md-9">${lastLogin}</div>
        </div>
        
        <div class="row mb-3">
            <div class="col-md-3 fw-bold">Profile Completion</div>
            <div class="col-md-9">
                <div class="progress mb-1" style="height: 20px;">
                    <div class="progress-bar bg-${profileCompletion >= 80 ? 'success' : profileCompletion >= 50 ? 'warning' : 'danger'}" 
                         role="progressbar" 
                         style="width: ${profileCompletion}%"
                         aria-valuenow="${profileCompletion}" 
                         aria-valuemin="0" 
                         aria-valuemax="100">
                        ${profileCompletion}%
                    </div>
                </div>
                <small class="text-muted">
                    ${profileCompletion >= 80 ? 'Complete profile' : 'Consider adding more information'}
                </small>
            </div>
        </div>
        
        <!-- User Preferences -->
        <hr class="my-4">
        <h6 class="text-muted mb-3">
            <i class="fas fa-cog me-1"></i>Preferences
        </h6>
        
        <div class="row mb-3">
            <div class="col-md-3 fw-bold">Theme</div>
            <div class="col-md-9">
                <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" id="theme-switch" ${$('body').hasClass('dark-mode') ? 'checked' : ''}>
                    <label class="form-check-label" for="theme-switch">
                        <i class="fas fa-moon me-1"></i>Dark Mode
                    </label>
                </div>
            </div>
        </div>
        
        <div class="row mb-3">
            <div class="col-md-3 fw-bold">Notifications</div>
            <div class="col-md-9">
                <div class="form-check form-switch">
                    <input class="form-check-input" type="checkbox" id="notifications-switch" ${userData.notificationsEnabled !== false ? 'checked' : ''}>
                    <label class="form-check-label" for="notifications-switch">
                        <i class="fas fa-bell me-1"></i>Email Notifications
                    </label>
                </div>
            </div>
        </div>
        
        <!-- Quick Actions -->
        <hr class="my-4">
        <h6 class="text-muted mb-3">
            <i class="fas fa-bolt me-1"></i>Quick Actions
        </h6>
        
        <div class="d-flex flex-wrap gap-2">
            <button class="btn btn-outline-primary btn-sm" id="refresh-profile-btn">
                <i class="fas fa-sync-alt me-1"></i>Refresh Data
            </button>
            <button class="btn btn-outline-warning btn-sm" id="change-password-btn">
                <i class="fas fa-key me-1"></i>Change Password
            </button>
            <button class="btn btn-outline-info btn-sm" id="export-data-btn">
                <i class="fas fa-download me-1"></i>Export Data
            </button>
            <button class="btn btn-outline-danger btn-sm" id="enhanced-logout-btn">
                <i class="fas fa-sign-out-alt me-1"></i>Logout
            </button>
        </div>
    `);
    
    // Add event listeners for enhanced functionality
    attachEnhancedProfileEventListeners();
}

// Calculate profile completion percentage (Prompt 9)
function calculateProfileCompletion(userData) {
    let completion = 0;
    const fields = ['name', 'email', 'role'];
    
    fields.forEach(field => {
        if (userData[field] && userData[field].trim()) {
            completion += 100 / fields.length;
        }
    });
    
    // Bonus points for additional information
    if (userData.emailVerified) completion += 10;
    if (userData.lastLogin) completion += 5;
    
    return Math.min(Math.round(completion), 100);
}

// Attach enhanced profile event listeners (Prompt 9)
function attachEnhancedProfileEventListeners() {
    console.log('Attaching enhanced profile event listeners (Prompt 9)');
    
    // Theme switch
    $('#theme-switch').off('change').on('change', function() {
        toggleDarkMode();
        updateUserPreference('theme', $(this).is(':checked') ? 'dark' : 'light');
    });
    
    // Notifications switch
    $('#notifications-switch').off('change').on('change', function() {
        const enabled = $(this).is(':checked');
        updateUserPreference('notificationsEnabled', enabled);
        showToast('info', 'Notifications', `Email notifications ${enabled ? 'enabled' : 'disabled'}.`);
    });
    
    // Refresh profile button
    $('#refresh-profile-btn').off('click').on('click', function() {
        const btn = $(this);
        const originalHtml = btn.html();
        btn.html('<i class="fas fa-spinner fa-spin me-1"></i>Refreshing...').prop('disabled', true);
        
        setTimeout(() => {
            loadProfileData();
            btn.html(originalHtml).prop('disabled', false);
        }, 1000);
    });
    
    // Change password button
    $('#change-password-btn').off('click').on('click', function() {
        showChangePasswordModal();
    });
    
    // Export data button
    $('#export-data-btn').off('click').on('click', function() {
        exportUserData();
    });
    
    // Enhanced logout button
    $('#enhanced-logout-btn').off('click').on('click', function() {
        showEnhancedLogoutModal();
    });
}

// Update user preference (Prompt 9)
function updateUserPreference(key, value) {
    if (!currentUser) return;
    
    // Update locally
    currentUser[key] = value;
    localStorage.setItem('currentUser', JSON.stringify(currentUser));
    
    // Try to update on server
    if (typeof makeAuthenticatedRequest === 'function' && isAuthenticated()) {
        const apiUrl = `http://localhost:3000/api/users/${currentUser.id}/preferences`;
        
        makeAuthenticatedRequest(apiUrl, {
            method: 'PUT',
            body: JSON.stringify({ [key]: value })
        })
        .then(() => {
            console.log(`User preference ${key} updated successfully`);
        })
        .catch(error => {
            console.log(`Failed to update preference ${key} on server:`, error.message);
        });
    }
}

// Load user statistics
function loadUserStatistics() {
    // Fetch tasks
    fetchTasks().then(tasks => {
        // Filter user's tasks
        const userTasks = tasks.filter(task => task.userId === currentUser.id);
        
        // Calculate statistics
        const totalTasks = userTasks.length;
        const completedTasks = userTasks.filter(task => task.status === 'completed').length;
        const pendingTasks = totalTasks - completedTasks;
        
        // Update UI
        $('#stats-total-tasks').text(totalTasks);
        $('#stats-completed-tasks').text(completedTasks);
        $('#stats-pending-tasks').text(pendingTasks);
    });
}

// Show edit profile modal
function showEditProfileModal() {
    // Create modal if it doesn't exist
    if ($('#edit-profile-modal').length === 0) {
        const modalHTML = `
            <div class="modal fade" id="edit-profile-modal" tabindex="-1">
                <div class="modal-dialog">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title">Edit Profile</h5>
                            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                        </div>
                        <div class="modal-body">
                            <form id="edit-profile-form">
                                <div class="mb-3">
                                    <label for="edit-profile-name" class="form-label">Name</label>
                                    <input type="text" class="form-control" id="edit-profile-name" required>
                                </div>
                                <div class="mb-3">
                                    <label for="edit-profile-email" class="form-label">Email</label>
                                    <input type="email" class="form-control" id="edit-profile-email" required>
                                </div>
                                <div class="mb-3">
                                    <label for="edit-profile-password" class="form-label">New Password (leave blank to keep current)</label>
                                    <input type="password" class="form-control" id="edit-profile-password">
                                </div>
                                <div class="mb-3">
                                    <label for="edit-profile-confirm-password" class="form-label">Confirm New Password</label>
                                    <input type="password" class="form-control" id="edit-profile-confirm-password">
                                </div>
                                <div class="alert alert-danger d-none" id="edit-profile-error"></div>
                            </form>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                            <button type="button" class="btn btn-primary" id="save-profile-btn">Save Changes</button>
                        </div>
                    </div>
                </div>
            </div>
        `;
        
        $('body').append(modalHTML);
        
        // Add event listener for save button
        $('#save-profile-btn').on('click', saveProfileChanges);
    }
    
    // Fill form with current user data
    $('#edit-profile-name').val(currentUser.name);
    $('#edit-profile-email').val(currentUser.email);
    $('#edit-profile-password').val('');
    $('#edit-profile-confirm-password').val('');
    $('#edit-profile-error').addClass('d-none');
    
    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('edit-profile-modal'));
    modal.show();
}

// Save profile changes (Enhanced for Prompt 9)
function saveProfileChanges() {
    console.log('Saving profile changes with enhanced PUT request (Prompt 9)');
    
    // Get form values
    const name = $('#edit-profile-name').val().trim();
    const email = $('#edit-profile-email').val().trim();
    const password = $('#edit-profile-password').val();
    const confirmPassword = $('#edit-profile-confirm-password').val();
    
    // Enhanced validation (Prompt 9)
    const validationErrors = [];
    
    if (!name) {
        validationErrors.push('Name is required');
    } else if (name.length < 2) {
        validationErrors.push('Name must be at least 2 characters');
    } else if (name.length > 50) {
        validationErrors.push('Name must be less than 50 characters');
    }
    
    if (!email) {
        validationErrors.push('Email is required');
    } else if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) {
        validationErrors.push('Please enter a valid email address');
    }
    
    if (password) {
        if (password.length < 6) {
            validationErrors.push('Password must be at least 6 characters');
        }
        if (password !== confirmPassword) {
            validationErrors.push('Passwords do not match');
        }
    }
    
    // Show validation errors
    if (validationErrors.length > 0) {
        $('#edit-profile-error').removeClass('d-none').html(
            '<ul class="mb-0">' + 
            validationErrors.map(error => `<li>${error}</li>`).join('') + 
            '</ul>'
        );
        return;
    }
    
    // Hide any previous errors
    $('#edit-profile-error').addClass('d-none');
    
    // Prepare enhanced update data (Prompt 9)
    const updateData = {
        name: name,
        email: email,
        updatedAt: new Date().toISOString()
    };
    
    if (password) {
        updateData.password = password;
    }
    
    console.log('Preparing PUT request with data (Prompt 9):', { ...updateData, password: password ? '[REDACTED]' : undefined });
    
    // API URL for PUT request (Prompt 9 requirement)
    const apiUrl = `http://localhost:3000/api/users/${currentUser.id}`;
    
    // Show enhanced loading state
    const saveBtn = $('#save-profile-btn');
    const originalBtnHtml = saveBtn.html();
    saveBtn.html('<i class="fas fa-spinner fa-spin me-1"></i>Saving changes...').prop('disabled', true);
    
    // Disable form inputs during save
    $('#edit-profile-form input').prop('disabled', true);
    
    console.log(`Sending PUT request to ${apiUrl} (Prompt 9 requirement)`);
    
    // Use makeAuthenticatedRequest for proper PUT request (Prompt 9)
    if (typeof makeAuthenticatedRequest === 'function' && isAuthenticated()) {
        makeAuthenticatedRequest(apiUrl, {
            method: 'PUT',
            body: JSON.stringify(updateData)
        })
        .then(response => {
            console.log('Profile updated successfully via PUT request (Prompt 9):', response);
            
            // Update current user with server response
            currentUser = { ...currentUser, ...response };
            localStorage.setItem('currentUser', JSON.stringify(currentUser));
            
            // Hide modal
            const modal = bootstrap.Modal.getInstance(document.getElementById('edit-profile-modal'));
            modal.hide();
            
            // Show enhanced success notification
            showToast('success', 'Profile Updated', 'Your profile has been updated successfully!');
            
            // Reload profile data to reflect changes
            loadProfileData();
            
            // Track successful update
            console.log('Profile update completed successfully (Prompt 9)');
        })
        .catch(error => {
            console.log('PUT request failed, handling error (Prompt 9):', error.message);
            
            // Enhanced error handling
            let errorMessage = 'Failed to update profile. Please try again.';
            
            if (error.message.includes('409') || error.message.includes('conflict')) {
                errorMessage = 'Email address is already in use by another account.';
            } else if (error.message.includes('400') || error.message.includes('validation')) {
                errorMessage = 'Invalid data provided. Please check your input.';
            } else if (error.message.includes('401') || error.message.includes('unauthorized')) {
                errorMessage = 'Session expired. Please log in again.';
            } else if (error.message.includes('Failed to fetch') || error.message.includes('network')) {
                // Fallback to offline mode for network issues
                handleOfflineProfileUpdate(updateData, name, email);
                return;
            }
            
            // Show error message
            $('#edit-profile-error').removeClass('d-none').text(errorMessage);
            
            // Reset form state
            $('#edit-profile-form input').prop('disabled', false);
            saveBtn.html(originalBtnHtml).prop('disabled', false);
        });
    } else {
        // Fallback to offline mode
        console.log('API not available, using offline profile update (Prompt 9 fallback)');
        handleOfflineProfileUpdate(updateData, name, email);
    }
}

// Handle offline profile update (Prompt 9)
function handleOfflineProfileUpdate(updateData, name, email) {
    console.log('Handling offline profile update (Prompt 9)');
    
    // Simulate API delay
    setTimeout(() => {
        // Update user data locally
        currentUser.name = name;
        currentUser.email = email;
        currentUser.updatedAt = updateData.updatedAt;
        localStorage.setItem('currentUser', JSON.stringify(currentUser));
        
        // Hide modal
        const modal = bootstrap.Modal.getInstance(document.getElementById('edit-profile-modal'));
        modal.hide();
        
        // Show offline success notification
        showToast('info', 'Profile Updated (Offline)', 'Your profile has been updated locally and will sync when connection is restored.');
        
        // Reload profile data
        loadProfileData();
        
        console.log('Offline profile update completed (Prompt 9)');
    }, 1000);
}

// Show enhanced logout modal (Prompt 9)
function showEnhancedLogoutModal() {
    console.log('Showing enhanced logout modal (Prompt 9)');
    
    const modalHTML = `
        <div class="modal fade" id="enhanced-logout-modal" tabindex="-1" aria-labelledby="enhancedLogoutModalLabel" aria-hidden="true">
            <div class="modal-dialog modal-dialog-centered">
                <div class="modal-content">
                    <div class="modal-header bg-warning text-dark">
                        <h5 class="modal-title" id="enhancedLogoutModalLabel">
                            <i class="fas fa-sign-out-alt me-2"></i>Confirm Logout
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <div class="text-center mb-3">
                            <i class="fas fa-exclamation-triangle text-warning fa-3x mb-3"></i>
                            <h6>Are you sure you want to logout?</h6>
                            <p class="text-muted">This will clear your session and return you to the login page.</p>
                        </div>
                        
                        <div class="alert alert-info">
                            <i class="fas fa-info-circle me-2"></i>
                            <strong>What will happen:</strong>
                            <ul class="mb-0 mt-2">
                                <li>Your session will be terminated</li>
                                <li>Local data will be cleared</li>
                                <li>You'll be redirected to the login page</li>
                                <li>Any unsaved changes will be lost</li>
                            </ul>
                        </div>
                        
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="remember-logout-choice">
                            <label class="form-check-label" for="remember-logout-choice">
                                Remember my choice and don't ask again
                            </label>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">
                            <i class="fas fa-times me-1"></i>Cancel
                        </button>
                        <button type="button" class="btn btn-warning" id="confirm-logout-btn">
                            <i class="fas fa-sign-out-alt me-1"></i>Yes, Logout
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Remove existing modal if any
    $('#enhanced-logout-modal').remove();
    
    // Add modal to body
    $('body').append(modalHTML);
    
    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('enhanced-logout-modal'));
    modal.show();
    
    // Add event listener for confirm button
    $('#confirm-logout-btn').on('click', function() {
        const rememberChoice = $('#remember-logout-choice').is(':checked');
        
        if (rememberChoice) {
            localStorage.setItem('skipLogoutConfirmation', 'true');
        }
        
        modal.hide();
        performEnhancedLogout();
    });
    
    // Clean up modal after hiding
    $('#enhanced-logout-modal').on('hidden.bs.modal', function() {
        $(this).remove();
    });
}

// Perform enhanced logout (Prompt 9)
function performEnhancedLogout() {
    console.log('Performing enhanced logout (Prompt 9)');
    
    // Show logout progress
    showToast('info', 'Logging Out', 'Clearing session data...');
    
    // Try to call logout API (Prompt 9 requirement)
    const token = localStorage.getItem('token');
    if (token && typeof makeAuthenticatedRequest === 'function') {
        console.log('Calling logout API (Prompt 9)');
        
        makeAuthenticatedRequest('http://localhost:3000/api/auth/logout', {
            method: 'POST'
        })
        .then(() => {
            console.log('Server logout successful (Prompt 9)');
            completeLogoutProcess();
        })
        .catch(error => {
            console.log('Server logout failed, proceeding with local logout (Prompt 9):', error.message);
            completeLogoutProcess();
        });
    } else {
        console.log('No token or API available, performing local logout (Prompt 9)');
        completeLogoutProcess();
    }
}

// Complete logout process (Prompt 9)
function completeLogoutProcess() {
    console.log('Completing logout process (Prompt 9)');
    
    // Clear all localStorage data (Prompt 9 requirement)
    const keysToRemove = [
        'currentUser',
        'token', 
        'tasks',
        'comments',
        'tags',
        'notifications',
        'userPreferences'
    ];
    
    console.log('Clearing localStorage keys (Prompt 9):', keysToRemove);
    
    keysToRemove.forEach(key => {
        localStorage.removeItem(key);
    });
    
    // Clear global variables
    if (typeof clearAuthData === 'function') {
        clearAuthData();
    }
    
    // Reset current user
    currentUser = null;
    
    // Show logout success message
    showToast('success', 'Logged Out', 'You have been logged out successfully');
    
    // Redirect to login (Prompt 9 requirement)
    setTimeout(() => {
        console.log('Redirecting to login page (Prompt 9)');
        
        if (window.location.pathname.includes('profile.html')) {
            // If on profile page, redirect to main index
            window.location.href = 'index.html';
        } else {
            // If on main page, show auth container
            if (typeof showAuthContainer === 'function') {
                showAuthContainer();
            } else {
                window.location.reload();
            }
        }
    }, 1500);
}

// Show change password modal (Prompt 9)
function showChangePasswordModal() {
    console.log('Showing change password modal (Prompt 9)');
    
    const modalHTML = `
        <div class="modal fade" id="change-password-modal" tabindex="-1" aria-labelledby="changePasswordModalLabel" aria-hidden="true">
            <div class="modal-dialog">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="changePasswordModalLabel">
                            <i class="fas fa-key me-2"></i>Change Password
                        </h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                    </div>
                    <div class="modal-body">
                        <form id="change-password-form">
                            <div class="alert alert-danger d-none" id="change-password-error"></div>
                            
                            <div class="mb-3">
                                <label for="current-password" class="form-label">Current Password</label>
                                <input type="password" class="form-control" id="current-password" required>
                            </div>
                            
                            <div class="mb-3">
                                <label for="new-password" class="form-label">New Password</label>
                                <input type="password" class="form-control" id="new-password" required minlength="6">
                                <div class="form-text">Password must be at least 6 characters long</div>
                            </div>
                            
                            <div class="mb-3">
                                <label for="confirm-new-password" class="form-label">Confirm New Password</label>
                                <input type="password" class="form-control" id="confirm-new-password" required>
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Cancel</button>
                        <button type="button" class="btn btn-primary" id="save-new-password-btn">
                            <i class="fas fa-save me-1"></i>Change Password
                        </button>
                    </div>
                </div>
            </div>
        </div>
    `;
    
    // Remove existing modal if any
    $('#change-password-modal').remove();
    
    // Add modal to body
    $('body').append(modalHTML);
    
    // Show modal
    const modal = new bootstrap.Modal(document.getElementById('change-password-modal'));
    modal.show();
    
    // Add event listener for save button
    $('#save-new-password-btn').on('click', handlePasswordChange);
    
    // Clean up modal after hiding
    $('#change-password-modal').on('hidden.bs.modal', function() {
        $(this).remove();
    });
}

// Handle password change (Prompt 9)
function handlePasswordChange() {
    const currentPassword = $('#current-password').val();
    const newPassword = $('#new-password').val();
    const confirmPassword = $('#confirm-new-password').val();
    
    // Validation
    if (!currentPassword || !newPassword || !confirmPassword) {
        $('#change-password-error').removeClass('d-none').text('All fields are required');
        return;
    }
    
    if (newPassword !== confirmPassword) {
        $('#change-password-error').removeClass('d-none').text('New passwords do not match');
        return;
    }
    
    if (newPassword.length < 6) {
        $('#change-password-error').removeClass('d-none').text('New password must be at least 6 characters');
        return;
    }
    
    // Show loading state
    const btn = $('#save-new-password-btn');
    const originalHtml = btn.html();
    btn.html('<i class="fas fa-spinner fa-spin me-1"></i>Changing...').prop('disabled', true);
    
    // API call to change password
    const apiUrl = `http://localhost:3000/api/users/${currentUser.id}/password`;
    
    if (typeof makeAuthenticatedRequest === 'function' && isAuthenticated()) {
        makeAuthenticatedRequest(apiUrl, {
            method: 'PUT',
            body: JSON.stringify({
                currentPassword: currentPassword,
                newPassword: newPassword
            })
        })
        .then(() => {
            // Success
            const modal = bootstrap.Modal.getInstance(document.getElementById('change-password-modal'));
            modal.hide();
            
            showToast('success', 'Password Changed', 'Your password has been updated successfully');
        })
        .catch(error => {
            btn.html(originalHtml).prop('disabled', false);
            
            let errorMessage = 'Failed to change password';
            if (error.message.includes('401') || error.message.includes('current password')) {
                errorMessage = 'Current password is incorrect';
            }
            
            $('#change-password-error').removeClass('d-none').text(errorMessage);
        });
    } else {
        // Offline mode - simulate success
        setTimeout(() => {
            const modal = bootstrap.Modal.getInstance(document.getElementById('change-password-modal'));
            modal.hide();
            
            showToast('info', 'Password Changed (Offline)', 'Password change will be processed when connection is restored');
        }, 1000);
    }
}

// Export user data (Prompt 9)
function exportUserData() {
    console.log('Exporting user data (Prompt 9)');
    
    showToast('info', 'Exporting Data', 'Preparing your data for download...');
    
    // Collect user data
    const exportData = {
        user: currentUser,
        tasks: JSON.parse(localStorage.getItem('tasks') || '[]'),
        comments: JSON.parse(localStorage.getItem('comments') || '[]'),
        tags: JSON.parse(localStorage.getItem('tags') || '[]'),
        exportDate: new Date().toISOString(),
        version: '1.0'
    };
    
    // Create downloadable file
    const dataStr = JSON.stringify(exportData, null, 2);
    const dataBlob = new Blob([dataStr], { type: 'application/json' });
    
    // Create download link
    const downloadLink = document.createElement('a');
    downloadLink.href = URL.createObjectURL(dataBlob);
    downloadLink.download = `taskmate-data-${currentUser.name}-${new Date().toISOString().split('T')[0]}.json`;
    
    // Trigger download
    document.body.appendChild(downloadLink);
    downloadLink.click();
    document.body.removeChild(downloadLink);
    
    showToast('success', 'Data Exported', 'Your data has been downloaded successfully');
}

// Initialize profile when document is ready
$(document).ready(function() {
    console.log('Profile.js document ready handler running');
    
    // Initialize theme toggle for profile page
    initializeProfileThemeToggle();
});

// Initialize theme toggle specifically for profile page
function initializeProfileThemeToggle() {
    // Theme toggle handler is managed globally in main.js using event delegation
    // Just initialize the theme state here
    
    // Set correct theme based on localStorage
    if (localStorage.getItem('darkMode') === 'enabled') {
        $('body').addClass('dark-mode');
        console.log('Dark mode restored in profile page');
    } else {
        console.log('Light mode in profile page');
    }
    
    // Icons will be handled automatically by CSS based on body.dark-mode class
} 