-- Database schema for Task Management System

-- Enable UUID extension
CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- User Role Enum
CREATE TYPE user_role AS ENUM ('USER', 'ADMIN');

-- Task Status Enum
CREATE TYPE task_status AS ENUM ('PENDING', 'IN_PROGRESS', 'COMPLETED');

-- Task Priority Enum
CREATE TYPE task_priority AS ENUM ('LOW', 'MEDIUM', 'HIGH');

-- Permission Enum
CREATE TYPE permission AS ENUM ('VIEW', 'EDIT');

-- Users Table
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  username VARCHAR(255) NOT NULL UNIQUE,
  email VARCHAR(255) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role user_role NOT NULL DEFAULT 'USER',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

-- Tasks Table
CREATE TABLE tasks (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  title VARCHAR(255) NOT NULL,
  description TEXT,
  due_date DATE,
  status task_status NOT NULL DEFAULT 'PENDING',
  priority task_priority NOT NULL DEFAULT 'MEDIUM',
  owner_id UUID NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  deleted_at TIMESTAMP,
  CONSTRAINT fk_owner FOREIGN KEY (owner_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Index for soft-deleted tasks
CREATE INDEX idx_tasks_deleted_at ON tasks(deleted_at);

-- Shared Tasks Table
CREATE TABLE shared_tasks (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  task_id UUID NOT NULL,
  shared_with_id UUID NOT NULL,
  permission permission NOT NULL DEFAULT 'VIEW',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_task FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE,
  CONSTRAINT fk_shared_with FOREIGN KEY (shared_with_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT unique_task_user UNIQUE (task_id, shared_with_id)
);

-- Trigger function to prevent self-sharing (since we can't use a subquery in check constraint)
CREATE OR REPLACE FUNCTION prevent_self_sharing()
RETURNS TRIGGER AS $$
DECLARE
  owner_id UUID;
BEGIN
  SELECT tasks.owner_id INTO owner_id
  FROM tasks
  WHERE tasks.id = NEW.task_id;
  
  IF NEW.shared_with_id = owner_id THEN
    RAISE EXCEPTION 'Cannot share task with its owner';
  END IF;
  
  RETURN NEW;
END;
$$ language 'plpgsql';

-- Trigger to enforce no self-sharing
CREATE TRIGGER check_no_self_sharing
  BEFORE INSERT OR UPDATE ON shared_tasks
  FOR EACH ROW
  EXECUTE FUNCTION prevent_self_sharing();

-- Task Comments Table
CREATE TABLE task_comments (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  task_id UUID NOT NULL,
  author_id UUID NOT NULL,
  comment TEXT NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_task FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE,
  CONSTRAINT fk_author FOREIGN KEY (author_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Index for ordering comments by creation date
CREATE INDEX idx_task_comments_created_at ON task_comments(created_at);

-- Notifications Table
CREATE TABLE notifications (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL,
  task_id UUID NOT NULL,
  message TEXT NOT NULL,
  is_read BOOLEAN NOT NULL DEFAULT FALSE,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
  CONSTRAINT fk_task FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE
);

-- Indexes for notifications
CREATE INDEX idx_notifications_user_id ON notifications(user_id);
CREATE INDEX idx_notifications_is_read ON notifications(is_read);

-- Password Reset Tokens Table
CREATE TABLE password_reset_tokens (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL,
  token VARCHAR(255) NOT NULL UNIQUE,
  expires_at TIMESTAMP NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_user FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
);

-- Indexes for password reset tokens
CREATE INDEX idx_password_reset_tokens_token ON password_reset_tokens(token);
CREATE INDEX idx_password_reset_tokens_expires_at ON password_reset_tokens(expires_at);

-- Categories Table
CREATE TABLE categories (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  name VARCHAR(255) NOT NULL UNIQUE,
  color VARCHAR(50)
);

-- Task Categories (Many-to-Many) Table
CREATE TABLE task_categories (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  task_id UUID NOT NULL,
  category_id UUID NOT NULL,
  CONSTRAINT fk_task FOREIGN KEY (task_id) REFERENCES tasks(id) ON DELETE CASCADE,
  CONSTRAINT fk_category FOREIGN KEY (category_id) REFERENCES categories(id) ON DELETE CASCADE,
  CONSTRAINT unique_task_category UNIQUE (task_id, category_id)
);

-- Indexes for task categories
CREATE INDEX idx_task_categories_task_id ON task_categories(task_id);
CREATE INDEX idx_task_categories_category_id ON task_categories(category_id);

-- Create views for active (non-deleted) tasks
CREATE OR REPLACE VIEW active_tasks AS
  SELECT * FROM tasks
  WHERE deleted_at IS NULL;

-- Trigger function to update the updated_at column
CREATE OR REPLACE FUNCTION update_modified_column()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ language 'plpgsql';

-- Triggers for automatically updating updated_at
CREATE TRIGGER update_users_modtime
    BEFORE UPDATE ON users
    FOR EACH ROW
    EXECUTE FUNCTION update_modified_column();

CREATE TRIGGER update_tasks_modtime
    BEFORE UPDATE ON tasks
    FOR EACH ROW
    EXECUTE FUNCTION update_modified_column();

-- Trigger function to delete expired tokens
CREATE OR REPLACE FUNCTION delete_expired_tokens()
RETURNS TRIGGER AS $$
BEGIN
    DELETE FROM password_reset_tokens WHERE expires_at < NOW();
    RETURN NULL;
END;
$$ language 'plpgsql';

-- Trigger to automatically clean up expired tokens
CREATE TRIGGER cleanup_expired_tokens
    AFTER INSERT ON password_reset_tokens
    EXECUTE FUNCTION delete_expired_tokens(); 